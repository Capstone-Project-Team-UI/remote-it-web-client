# @veneer/assets

> The assets package contains the definitions and content of Veneer assets, like icons, fonts, logos, flags, etc.

## Installation

The `@veneer/assets` package is available in a private NPM registry under the `@veneer` scope. For more details check the [documentation page](https://veneer.hp.com/platforms/web/get-started/develop-with-veneer-web/) to get started.

```bash
npm install --save @veneer/assets
```

or

```bash
yarn add @veneer/assets
```

## Icons

This package provides entry points as well as svg files for all Veneer icons in round/lined shapes, line/filled styles, multiple sizes (12, 16, 20, 24), and ltr/rtl directions.

By looping through the icons, you can access each icon content.

```
import { icons } from "@veneer/assets";

for (const [name, icon] of Object.entries(icons)) {
  console.log(name);          // e.g) tools
  console.log(icon.content);  // e.g) iconContent
}
```

Icon content is structured the following way. For all icons, size '24' is default. Other sizes are optional.

```
type IconContent = {
  [shape: string]: {    // 'round' and 'sharp'
    [style: string]: {  // 'lined' and 'filled'
      [size: string]: { // '12', '16', '20', and '24'
        rtl_state: 'distinct' | 'mirrored' | 'same';
        ltr: string;    // icon svg path
        rtl: string;    // icon svg path
      };
    };
  };
};
```

For example, `icons['tools'].content.round.filled[24].rtl` will give icon svg path, such as `icons/round/filled/24/tools.11ca913.svg`. Use these paths to access icon svg files.

For importing this icon SVG you must do like this: `import toolsSVG from "@veneer/assets/icons/round/filled/24/tools.11ca913.svg";`


## Fonts

@veneer/assets provides FormaDJRUI and FormaDJRUIItalic font files in ttf, woff, woff2 format. All the font files are also located in `@veneer/assets/fonts`. So you can import them using the full path `@veneer/assets/fonts/FormaDJRUI.ttf`

```
const fonts: Record<string, FontAsset> = {
  FormaDJRUI: {
    name: 'Forma DJR UI',
    content: {
      italic: {
        ttf: 'fonts/FormaDJRUIItalic.ttf',
        woff: 'fonts/FormaDJRUIItalic.woff',
        woff2: 'fonts/FormaDJRUIItalic.woff2',
      },
      normal: {
        ttf: 'fonts/FormaDJRUI.ttf',
        woff: 'fonts/FormaDJRUI.woff',
        woff2: 'fonts/FormaDJRUI.woff2',
      },
    },
  },
};

```

## Documentation

If you're looking for more information about Veneer, check this out:

- [Veneer Website](https://veneer.hp.com/)
