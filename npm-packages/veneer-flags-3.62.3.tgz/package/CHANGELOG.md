# @veneer/flags

## 3.62.3

### Patch Changes

- Updated dependencies [[`f3bf166`](https://github.azc.ext.hp.com/veneer/veneer/commit/f3bf166dff615e06e7514a1fd816c5b9d3ef8e61), [`58ea6d8`](https://github.azc.ext.hp.com/veneer/veneer/commit/58ea6d864e51af1bb0556a5e07dc314fac9d1c82), [`dc378eb`](https://github.azc.ext.hp.com/veneer/veneer/commit/dc378eb376bf82f7e71e321edc23b500059161da), [`64ade0f`](https://github.azc.ext.hp.com/veneer/veneer/commit/64ade0f6fb61fc32d81f557e691379a3f43e509e), [`83e66a5`](https://github.azc.ext.hp.com/veneer/veneer/commit/83e66a5c45a723bb4bc708433addb4dceada436a), [`8696106`](https://github.azc.ext.hp.com/veneer/veneer/commit/8696106e345abb1eb7ee4f373311018d66c340fa), [`27e451b`](https://github.azc.ext.hp.com/veneer/veneer/commit/27e451b37128d29f385a8516ca84c34976f78678), [`26161e8`](https://github.azc.ext.hp.com/veneer/veneer/commit/26161e8fafbd699a2f66d6f1371a64adfd2b3087), [`d17ddda`](https://github.azc.ext.hp.com/veneer/veneer/commit/d17ddda3ed6ce9fa5e7ae37f054966fef7ff19af)]:
  - @veneer/core@3.113.0

## 3.62.2

### Patch Changes

- [#6994](https://github.azc.ext.hp.com/veneer/veneer/pull/6994) [`21bbbe7`](https://github.azc.ext.hp.com/veneer/veneer/commit/21bbbe7cb586b75429040ca456ffa6bad5295806) Thanks [@joao-flores-de-leao](https://github.azc.ext.hp.com/joao-flores-de-leao)! - [Foundation] Update foundation packages.

- Updated dependencies [[`21bbbe7`](https://github.azc.ext.hp.com/veneer/veneer/commit/21bbbe7cb586b75429040ca456ffa6bad5295806)]:
  - @veneer/core@3.112.1

## 3.62.1

### Patch Changes

- Updated dependencies [[`f66d37a`](https://github.azc.ext.hp.com/veneer/veneer/commit/f66d37a8009f92cad000c86d44653ae1efaa2391), [`eef1052`](https://github.azc.ext.hp.com/veneer/veneer/commit/eef1052f16d902f7f2046d622b1b30ae662dedd3), [`0930bda`](https://github.azc.ext.hp.com/veneer/veneer/commit/0930bda8d8c1e2115cd20264dc0b6b1da0cedb1a), [`9f353af`](https://github.azc.ext.hp.com/veneer/veneer/commit/9f353af6b90bd2e13cc3364dfddc1ef2da890bbc), [`d578284`](https://github.azc.ext.hp.com/veneer/veneer/commit/d57828456aeba1c86d52fd7b14ffad4bf5348446), [`fabf984`](https://github.azc.ext.hp.com/veneer/veneer/commit/fabf984873e410caeee437ddf8cd2b468826c8d5), [`d7e3d87`](https://github.azc.ext.hp.com/veneer/veneer/commit/d7e3d8726610cbbe6d36f47dcf2b28f2b6da1639), [`131ec74`](https://github.azc.ext.hp.com/veneer/veneer/commit/131ec744400baee3611e79753b8b95019bfebb3a), [`6cd18c0`](https://github.azc.ext.hp.com/veneer/veneer/commit/6cd18c006ef4a6f07ddc915de71d1dbdea28adc6), [`f70bd5b`](https://github.azc.ext.hp.com/veneer/veneer/commit/f70bd5bc79086351e16dda588d375baa6a84f268), [`78d4247`](https://github.azc.ext.hp.com/veneer/veneer/commit/78d424799ae68556e92984862821d1fe5e946e71), [`c846a5a`](https://github.azc.ext.hp.com/veneer/veneer/commit/c846a5a15dff9421317a5bb6ea95416aef02abd5), [`47bbfac`](https://github.azc.ext.hp.com/veneer/veneer/commit/47bbfacd35ecce2355f1cae656e881efa9d45aa9)]:
  - @veneer/core@3.112.0

## 3.62.0

### Minor Changes

- [#6350](https://github.azc.ext.hp.com/veneer/veneer/pull/6350) [`d89d31f`](https://github.azc.ext.hp.com/veneer/veneer/commit/d89d31f0dd76cc0ae9695f700742eeae66153f0b) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [SideMenu] Remove toggle, toggleImagePath and deprecated appearances.

### Patch Changes

- Updated dependencies [[`d89d31f`](https://github.azc.ext.hp.com/veneer/veneer/commit/d89d31f0dd76cc0ae9695f700742eeae66153f0b), [`66c998d`](https://github.azc.ext.hp.com/veneer/veneer/commit/66c998d469980d12a6d14659ad20499de8f5e945), [`d89d31f`](https://github.azc.ext.hp.com/veneer/veneer/commit/d89d31f0dd76cc0ae9695f700742eeae66153f0b), [`63cfb0a`](https://github.azc.ext.hp.com/veneer/veneer/commit/63cfb0ae67e7d29a035a64f5b5387a0f8da4a156), [`a091726`](https://github.azc.ext.hp.com/veneer/veneer/commit/a091726b09da8e2391a31bcf6f424192944f5059), [`d89d31f`](https://github.azc.ext.hp.com/veneer/veneer/commit/d89d31f0dd76cc0ae9695f700742eeae66153f0b), [`d89d31f`](https://github.azc.ext.hp.com/veneer/veneer/commit/d89d31f0dd76cc0ae9695f700742eeae66153f0b), [`d89d31f`](https://github.azc.ext.hp.com/veneer/veneer/commit/d89d31f0dd76cc0ae9695f700742eeae66153f0b), [`0d1efc5`](https://github.azc.ext.hp.com/veneer/veneer/commit/0d1efc5ce9e0af2e93d8f1eded56d582828acc6c), [`d89d31f`](https://github.azc.ext.hp.com/veneer/veneer/commit/d89d31f0dd76cc0ae9695f700742eeae66153f0b), [`372e06d`](https://github.azc.ext.hp.com/veneer/veneer/commit/372e06d8c79283608581008450f0669f1dfeaefc), [`78d44ae`](https://github.azc.ext.hp.com/veneer/veneer/commit/78d44aefbaf050bed5d3c95c2393cea42310534c), [`d89d31f`](https://github.azc.ext.hp.com/veneer/veneer/commit/d89d31f0dd76cc0ae9695f700742eeae66153f0b), [`f4967bf`](https://github.azc.ext.hp.com/veneer/veneer/commit/f4967bfa79820c2ff749aab24dc541fa7c007bba), [`3867b4e`](https://github.azc.ext.hp.com/veneer/veneer/commit/3867b4e7aed56ca7db80d598baab738c54a5c2e5), [`d89d31f`](https://github.azc.ext.hp.com/veneer/veneer/commit/d89d31f0dd76cc0ae9695f700742eeae66153f0b), [`d89d31f`](https://github.azc.ext.hp.com/veneer/veneer/commit/d89d31f0dd76cc0ae9695f700742eeae66153f0b), [`d89d31f`](https://github.azc.ext.hp.com/veneer/veneer/commit/d89d31f0dd76cc0ae9695f700742eeae66153f0b), [`d89d31f`](https://github.azc.ext.hp.com/veneer/veneer/commit/d89d31f0dd76cc0ae9695f700742eeae66153f0b)]:
  - @veneer/core@3.111.0

## 3.61.5

### Patch Changes

- Updated dependencies [[`baeb58a`](https://github.azc.ext.hp.com/veneer/veneer/commit/baeb58a2c0b87068cc54b8802198fdf56a82d03e), [`33f8494`](https://github.azc.ext.hp.com/veneer/veneer/commit/33f8494cf0fb8b0cdd1e2ce53cee1bfd6a4f2cdb), [`3102aab`](https://github.azc.ext.hp.com/veneer/veneer/commit/3102aab29e1e71fb7ef1512c406472c000d8207c), [`200772f`](https://github.azc.ext.hp.com/veneer/veneer/commit/200772f3cb7a2973f4cca40e199f58727b3808c1), [`4297251`](https://github.azc.ext.hp.com/veneer/veneer/commit/429725102342eda058cb85e681fbc5c81be04738), [`b1adfef`](https://github.azc.ext.hp.com/veneer/veneer/commit/b1adfef3c099302bc03cb932d0872dbf8083210f), [`fab214a`](https://github.azc.ext.hp.com/veneer/veneer/commit/fab214adc6ce389dbc1fc4c20f13086665675e3b), [`374b5f9`](https://github.azc.ext.hp.com/veneer/veneer/commit/374b5f9f765f0b64685b66b8597fc579a443dd8b), [`8bb321b`](https://github.azc.ext.hp.com/veneer/veneer/commit/8bb321b4a4e8d2304917754cc806055dd0e9a21c), [`b7675be`](https://github.azc.ext.hp.com/veneer/veneer/commit/b7675bef1e6422dd29ac84479379d968af784059), [`1b694c8`](https://github.azc.ext.hp.com/veneer/veneer/commit/1b694c8885ac1480b7d944bf74d8e43eb7a7db04), [`89f0a85`](https://github.azc.ext.hp.com/veneer/veneer/commit/89f0a8582b36bcec211c684529fe9e09fef0412e), [`35d24d9`](https://github.azc.ext.hp.com/veneer/veneer/commit/35d24d99610a49821390c0af4ff3955dc9af7503), [`fd8f720`](https://github.azc.ext.hp.com/veneer/veneer/commit/fd8f72019384c4fd539b6c80e01e5f0e24807800), [`c102084`](https://github.azc.ext.hp.com/veneer/veneer/commit/c102084ee761cb8a53118cfe09efad8538993fe3), [`0f4596f`](https://github.azc.ext.hp.com/veneer/veneer/commit/0f4596f71181198779a86a256497beec1799becb)]:
  - @veneer/core@3.110.0

## 3.61.4

### Patch Changes

- Updated dependencies [[`c0b0fb3`](https://github.azc.ext.hp.com/veneer/veneer/commit/c0b0fb355cee852da4f4440c1ee6982aa5e2e67a), [`fef5300`](https://github.azc.ext.hp.com/veneer/veneer/commit/fef5300be118f08556f3c6908068da3fb722df23), [`2e352ca`](https://github.azc.ext.hp.com/veneer/veneer/commit/2e352ca6720d300c8a946284ffb556e5fd8f56cf), [`f5549e8`](https://github.azc.ext.hp.com/veneer/veneer/commit/f5549e86a9084631f2459191d6c4b0f20079bf62), [`d9ed94b`](https://github.azc.ext.hp.com/veneer/veneer/commit/d9ed94bbfa07e7fbf21be631aa7d872acec93142), [`3025276`](https://github.azc.ext.hp.com/veneer/veneer/commit/30252766fba21406d34e59f42b61a99bdc6aa28d), [`746ef2b`](https://github.azc.ext.hp.com/veneer/veneer/commit/746ef2b30e4866041c7a4171239893cdccee8fd3), [`8183aba`](https://github.azc.ext.hp.com/veneer/veneer/commit/8183aba224138b0a13b2c51375a9d5e7a912c30b), [`ced9689`](https://github.azc.ext.hp.com/veneer/veneer/commit/ced96892641511026228fb98d56cc76cde736279)]:
  - @veneer/core@3.109.0

## 3.61.3

### Patch Changes

- Updated dependencies [[`e7d0f5a`](https://github.azc.ext.hp.com/veneer/veneer/commit/e7d0f5a79694ca88b332d66a6f50fdf4c184cc81), [`f2bcc26`](https://github.azc.ext.hp.com/veneer/veneer/commit/f2bcc2630714c575f04c5c5737e7736fbe9ab172), [`237fde9`](https://github.azc.ext.hp.com/veneer/veneer/commit/237fde990089c67c4f8fe09d4e21258a87e81086), [`06e3109`](https://github.azc.ext.hp.com/veneer/veneer/commit/06e31098914a1d8c81d28bfb815bbec6cfaa52e6), [`20e1aec`](https://github.azc.ext.hp.com/veneer/veneer/commit/20e1aec2ed38d20e74894f7824c4894e1f25e46a), [`e8935b8`](https://github.azc.ext.hp.com/veneer/veneer/commit/e8935b8ac2f5b58e1bc858147f06668f3fdaa5d3), [`e4320cd`](https://github.azc.ext.hp.com/veneer/veneer/commit/e4320cd176b8fd67d32f0a892bd993bf5044dd52), [`ee7c90b`](https://github.azc.ext.hp.com/veneer/veneer/commit/ee7c90b05efef820d3de82a5db6895184bfc523b), [`950544c`](https://github.azc.ext.hp.com/veneer/veneer/commit/950544cf2a7dbce1f88b8a18b2e3016703599ce4), [`b7d6a32`](https://github.azc.ext.hp.com/veneer/veneer/commit/b7d6a32d001aa9e2d3a53da2b185801ef7c3ad3c), [`6f36500`](https://github.azc.ext.hp.com/veneer/veneer/commit/6f36500ebe55a9e32eb8da64cb95699807e4e87c)]:
  - @veneer/core@3.108.0

## 3.61.2

### Patch Changes

- Updated dependencies [[`775f452`](https://github.azc.ext.hp.com/veneer/veneer/commit/775f452b0fc5d1073d6ad8f940b85f4b266c1aa5), [`33a9147`](https://github.azc.ext.hp.com/veneer/veneer/commit/33a914752f8683ae4065380d1622a23def3e94e4), [`cb61939`](https://github.azc.ext.hp.com/veneer/veneer/commit/cb61939567bb052cd81b5b5d004963f89ac8ff11), [`0b1f404`](https://github.azc.ext.hp.com/veneer/veneer/commit/0b1f404ba9b3ecf4118501f57bc168dd7f0c2633), [`7271a60`](https://github.azc.ext.hp.com/veneer/veneer/commit/7271a604edd8fd6acc0fd2e718885a5d6c320d06), [`35b0c28`](https://github.azc.ext.hp.com/veneer/veneer/commit/35b0c28fd67d1688130661a60b4d92fac0014bd5), [`7fd2719`](https://github.azc.ext.hp.com/veneer/veneer/commit/7fd27194e649cf25a0ad37de4f249a462c737bb5)]:
  - @veneer/core@3.107.0

## 3.61.1

### Patch Changes

- Updated dependencies [[`0b6ec20`](https://github.azc.ext.hp.com/veneer/veneer/commit/0b6ec20f57af4ff30150c60c1872a213bcdc66bd), [`825a58e`](https://github.azc.ext.hp.com/veneer/veneer/commit/825a58e7b299829f0b2013af65ec428ca4aa1182), [`25b3c94`](https://github.azc.ext.hp.com/veneer/veneer/commit/25b3c94f58fa967bdc4af57c01d6733f37bf1bf9), [`745dc3e`](https://github.azc.ext.hp.com/veneer/veneer/commit/745dc3e83204128ded82fd0e7f70f864cdc235f6), [`b4b59b4`](https://github.azc.ext.hp.com/veneer/veneer/commit/b4b59b4b1de75f5725e9ee35ac5160d8366bf1ab), [`648c69b`](https://github.azc.ext.hp.com/veneer/veneer/commit/648c69bf1c9246ddbea4835439b17208740683bf)]:
  - @veneer/core@3.106.0

## 3.61.0

### Minor Changes

- [`9ee153f`](https://github.azc.ext.hp.com/veneer/veneer/commit/9ee153fcdc13f03e341205c556fb24e157583aef) Thanks [@walter-ferreira](https://github.azc.ext.hp.com/walter-ferreira)! - [Foundation] Update @veneer/assets to 3.14.0, update @veneer/primitives to 3.63.0 and update @veneer/semantics to 3.9.0

### Patch Changes

- Updated dependencies [[`88d6465`](https://github.azc.ext.hp.com/veneer/veneer/commit/88d64655c51745115eb75ce9322f934ddfaf5d60), [`b3c50ff`](https://github.azc.ext.hp.com/veneer/veneer/commit/b3c50ff33457f91d36f44e4ef89660806f30d116), [`9ee153f`](https://github.azc.ext.hp.com/veneer/veneer/commit/9ee153fcdc13f03e341205c556fb24e157583aef), [`3d111ce`](https://github.azc.ext.hp.com/veneer/veneer/commit/3d111cee401ef00fe94231cf8768eab4760025fc), [`543af65`](https://github.azc.ext.hp.com/veneer/veneer/commit/543af6513246ddc4c757a1bf80e1c88ce1743d1a), [`ccddc0a`](https://github.azc.ext.hp.com/veneer/veneer/commit/ccddc0a00cefd2f39e6ca8279ffcf3b995ea3dbd), [`7a66aea`](https://github.azc.ext.hp.com/veneer/veneer/commit/7a66aea877a9e7e1759990f5e2a25b5e47d475d7), [`e459fa2`](https://github.azc.ext.hp.com/veneer/veneer/commit/e459fa22d20ca3b0aa297127981e5aad344cd2e8), [`76ad29d`](https://github.azc.ext.hp.com/veneer/veneer/commit/76ad29d608f34963dcb89aaad369ccd3d808daa8)]:
  - @veneer/core@3.105.0

## 3.60.5

### Patch Changes

- Updated dependencies [[`3762723`](https://github.azc.ext.hp.com/veneer/veneer/commit/3762723f840ea58d7ca8c26c96684e3c185452c2), [`818db74`](https://github.azc.ext.hp.com/veneer/veneer/commit/818db74ae3486ffe550c5d40c45d621906d6d027), [`dcf6c87`](https://github.azc.ext.hp.com/veneer/veneer/commit/dcf6c87c790578923ee8632bb8ec92e4ce7e2faf), [`de59845`](https://github.azc.ext.hp.com/veneer/veneer/commit/de5984549f222f2c58cdfcbdb68f20be34aae4e7), [`3dde97b`](https://github.azc.ext.hp.com/veneer/veneer/commit/3dde97bbcaeaff0727c1002ab863c7489a869fe4), [`41b4d70`](https://github.azc.ext.hp.com/veneer/veneer/commit/41b4d70691d7963bb5368ecd90f9cd99b1446b7f), [`3762723`](https://github.azc.ext.hp.com/veneer/veneer/commit/3762723f840ea58d7ca8c26c96684e3c185452c2), [`3762723`](https://github.azc.ext.hp.com/veneer/veneer/commit/3762723f840ea58d7ca8c26c96684e3c185452c2), [`3762723`](https://github.azc.ext.hp.com/veneer/veneer/commit/3762723f840ea58d7ca8c26c96684e3c185452c2), [`ca9c6ee`](https://github.azc.ext.hp.com/veneer/veneer/commit/ca9c6ee0b9cb6060d2e4e8cd391523f47fb853ed), [`213b711`](https://github.azc.ext.hp.com/veneer/veneer/commit/213b7116e1c325cfd0426f5c654441c79c6f8935), [`3762723`](https://github.azc.ext.hp.com/veneer/veneer/commit/3762723f840ea58d7ca8c26c96684e3c185452c2), [`3762723`](https://github.azc.ext.hp.com/veneer/veneer/commit/3762723f840ea58d7ca8c26c96684e3c185452c2), [`3762723`](https://github.azc.ext.hp.com/veneer/veneer/commit/3762723f840ea58d7ca8c26c96684e3c185452c2), [`34b5e9f`](https://github.azc.ext.hp.com/veneer/veneer/commit/34b5e9fa9feda928c59efa389b26b0321f578738)]:
  - @veneer/core@3.104.0

## 3.60.4

### Patch Changes

- Updated dependencies [[`e4e18c1`](https://github.azc.ext.hp.com/veneer/veneer/commit/e4e18c1585abcced192570ada1584d24569ba566), [`e85862d`](https://github.azc.ext.hp.com/veneer/veneer/commit/e85862d50cd3671098af0907c8258cbc3d908c0d), [`e4e18c1`](https://github.azc.ext.hp.com/veneer/veneer/commit/e4e18c1585abcced192570ada1584d24569ba566), [`4fb1a74`](https://github.azc.ext.hp.com/veneer/veneer/commit/4fb1a745f7c2438534f34cd9931dfc285a1834ba), [`e4e18c1`](https://github.azc.ext.hp.com/veneer/veneer/commit/e4e18c1585abcced192570ada1584d24569ba566), [`e4e18c1`](https://github.azc.ext.hp.com/veneer/veneer/commit/e4e18c1585abcced192570ada1584d24569ba566), [`fee4c92`](https://github.azc.ext.hp.com/veneer/veneer/commit/fee4c924c997ae16636dafb7a141955aa59c1a0d), [`e4e18c1`](https://github.azc.ext.hp.com/veneer/veneer/commit/e4e18c1585abcced192570ada1584d24569ba566), [`cbab306`](https://github.azc.ext.hp.com/veneer/veneer/commit/cbab306a726ed366f7928dd15161cd465dd45118), [`e4e18c1`](https://github.azc.ext.hp.com/veneer/veneer/commit/e4e18c1585abcced192570ada1584d24569ba566), [`e4e18c1`](https://github.azc.ext.hp.com/veneer/veneer/commit/e4e18c1585abcced192570ada1584d24569ba566), [`e4e18c1`](https://github.azc.ext.hp.com/veneer/veneer/commit/e4e18c1585abcced192570ada1584d24569ba566), [`e4e18c1`](https://github.azc.ext.hp.com/veneer/veneer/commit/e4e18c1585abcced192570ada1584d24569ba566), [`e4e18c1`](https://github.azc.ext.hp.com/veneer/veneer/commit/e4e18c1585abcced192570ada1584d24569ba566), [`e4e18c1`](https://github.azc.ext.hp.com/veneer/veneer/commit/e4e18c1585abcced192570ada1584d24569ba566)]:
  - @veneer/core@3.103.0

## 3.60.3

### Patch Changes

- Updated dependencies [[`e39462a`](https://github.azc.ext.hp.com/veneer/veneer/commit/e39462a9ac0f852592507e453d4550afbcbc2723), [`a943882`](https://github.azc.ext.hp.com/veneer/veneer/commit/a943882f5c3a4f127a1cfdea937e3871be06eedd), [`50ede93`](https://github.azc.ext.hp.com/veneer/veneer/commit/50ede93295b039e82bba3b340a2c398479537328), [`9d3f6bb`](https://github.azc.ext.hp.com/veneer/veneer/commit/9d3f6bbf41fab524e442d5612a939788c2e7312c), [`0b29e7e`](https://github.azc.ext.hp.com/veneer/veneer/commit/0b29e7e57f180ed39b2144a2653db0f8bafce5e3), [`b21b152`](https://github.azc.ext.hp.com/veneer/veneer/commit/b21b152f697ed17c5dd11ebb44c74dd75c82d02c), [`5bda84a`](https://github.azc.ext.hp.com/veneer/veneer/commit/5bda84a27b78b82195a02566f9b94323f4ab995f), [`79bf91a`](https://github.azc.ext.hp.com/veneer/veneer/commit/79bf91aaf7e5111a2a80453286fc1849790a34d5), [`c4e15e2`](https://github.azc.ext.hp.com/veneer/veneer/commit/c4e15e2975a70f926399908fb3c1b72aeb40bac2)]:
  - @veneer/core@3.102.0

## 3.60.2

### Patch Changes

- Updated dependencies [[`9edd411`](https://github.azc.ext.hp.com/veneer/veneer/commit/9edd4116f445ddef6b85fc178fea407b708d080b), [`6c9783f`](https://github.azc.ext.hp.com/veneer/veneer/commit/6c9783f5d3834db132ac0d45d662337a954a9630), [`7eef67d`](https://github.azc.ext.hp.com/veneer/veneer/commit/7eef67d61c374708cc507c8e512c3e8a2d64bd80), [`072e9ac`](https://github.azc.ext.hp.com/veneer/veneer/commit/072e9ac78cedf139373e03f100a4366df6fc07f3), [`435f4c5`](https://github.azc.ext.hp.com/veneer/veneer/commit/435f4c5c4d5acad14c7483a77031201a41f1473b)]:
  - @veneer/core@3.101.0

## 3.60.1

### Patch Changes

- Updated dependencies [[`7c6497b`](https://github.azc.ext.hp.com/veneer/veneer/commit/7c6497b89d900c1617949ba663e50745a8351cb9), [`8dc5c5f`](https://github.azc.ext.hp.com/veneer/veneer/commit/8dc5c5fa01bf073617b8d940872544da4c56953b), [`d3a478e`](https://github.azc.ext.hp.com/veneer/veneer/commit/d3a478e0e398e44588877e4d803019376cf61d53), [`7cb72ae`](https://github.azc.ext.hp.com/veneer/veneer/commit/7cb72ae026fd44ae4c1198498295934a49def199), [`46d7685`](https://github.azc.ext.hp.com/veneer/veneer/commit/46d76852611b5d4ae0b32caa6e9e409497b2af09), [`6f32867`](https://github.azc.ext.hp.com/veneer/veneer/commit/6f32867322b594638090f4ea51e02b60cf82f174), [`96c884d`](https://github.azc.ext.hp.com/veneer/veneer/commit/96c884d1e4e0cabac972c0b057a110367c55ef98), [`00fb27b`](https://github.azc.ext.hp.com/veneer/veneer/commit/00fb27ba928cf7b4ce232c42033142db1998e567), [`57d873f`](https://github.azc.ext.hp.com/veneer/veneer/commit/57d873fa44ffaf896b06dc7f076b3630573a3766), [`bd40031`](https://github.azc.ext.hp.com/veneer/veneer/commit/bd40031bc59bc267a7086644fd05a0f3c52c661a), [`63ee2ac`](https://github.azc.ext.hp.com/veneer/veneer/commit/63ee2ac53412b385a3d8bf0bfb23e446ca6423e8), [`3956182`](https://github.azc.ext.hp.com/veneer/veneer/commit/39561827762cd7f1431eb28e6a7469c7761a3292), [`7cb72ae`](https://github.azc.ext.hp.com/veneer/veneer/commit/7cb72ae026fd44ae4c1198498295934a49def199), [`54d216f`](https://github.azc.ext.hp.com/veneer/veneer/commit/54d216ffbc7d3643d3e268080b71a61bed39bd72), [`6ed4a5d`](https://github.azc.ext.hp.com/veneer/veneer/commit/6ed4a5d1b51d57a0b1c5a6c76aa202361513a55c), [`2ca77c0`](https://github.azc.ext.hp.com/veneer/veneer/commit/2ca77c0ba1efe9d8321e73c93994531f593f16ee), [`e137d68`](https://github.azc.ext.hp.com/veneer/veneer/commit/e137d68d3924c7d12423b187b95293b632cd2bb6), [`ce80e8f`](https://github.azc.ext.hp.com/veneer/veneer/commit/ce80e8f5610aefaa5dad7119e7e9e68e9781f48e), [`df100ad`](https://github.azc.ext.hp.com/veneer/veneer/commit/df100add7a27d8cb8cd662dc99a3cefbd2e0d022), [`555624f`](https://github.azc.ext.hp.com/veneer/veneer/commit/555624f4b99eb6d8ab0f03d6f56315fa3287bfaf), [`5936264`](https://github.azc.ext.hp.com/veneer/veneer/commit/5936264fb680054445fdbe612158fb493a6770a5), [`7c6497b`](https://github.azc.ext.hp.com/veneer/veneer/commit/7c6497b89d900c1617949ba663e50745a8351cb9), [`7939b5a`](https://github.azc.ext.hp.com/veneer/veneer/commit/7939b5a1521271ca61a0d7f4a255d42d002b1b09), [`2d91caa`](https://github.azc.ext.hp.com/veneer/veneer/commit/2d91caabce564f5b9bd29af15066c242d2b093ad), [`6ed4a5d`](https://github.azc.ext.hp.com/veneer/veneer/commit/6ed4a5d1b51d57a0b1c5a6c76aa202361513a55c), [`c01ab74`](https://github.azc.ext.hp.com/veneer/veneer/commit/c01ab74c27a7893215d28afc1818c2c2e317a0e4), [`f53ebd6`](https://github.azc.ext.hp.com/veneer/veneer/commit/f53ebd6a00a7bacf633b5828a215fc9cd1a1900b), [`0637dc0`](https://github.azc.ext.hp.com/veneer/veneer/commit/0637dc0b6c6b6eb3bf7a1d2f8522be06c4c16325), [`0d41fe0`](https://github.azc.ext.hp.com/veneer/veneer/commit/0d41fe020fcedf65d091ec5db0f8d2dc0f2b4042)]:
  - @veneer/core@3.100.0

## 3.60.0

### Minor Changes

- [#6396](https://github.azc.ext.hp.com/veneer/veneer/pull/6396) [`aa84d22`](https://github.azc.ext.hp.com/veneer/veneer/commit/aa84d221a14b82cd929f71f4d596e033f1759180) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [Foundation] Update @veneer/assets to 3.8.0, update @veneer/primitives to 3.61.0 and update @veneer/semantics to 3.6.0

- [#6298](https://github.azc.ext.hp.com/veneer/veneer/pull/6298) [`a984c97`](https://github.azc.ext.hp.com/veneer/veneer/commit/a984c976285393889a3ba9c53ca312fb765b49dc) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - [React] Update minimum supported react to 16.14.0

  This is in preparation for a future update to React 17; it is strongly recommended to update to React 18.

### Patch Changes

- Updated dependencies [[`90cef04`](https://github.azc.ext.hp.com/veneer/veneer/commit/90cef04c28198cacf1be1d7573f9280a80f3a52d), [`836b834`](https://github.azc.ext.hp.com/veneer/veneer/commit/836b834e1d74a4a116d1fd2a5b5884792472f396), [`eae526b`](https://github.azc.ext.hp.com/veneer/veneer/commit/eae526b671f668fcc9ce23927673ee2100d80c4f), [`14a1b88`](https://github.azc.ext.hp.com/veneer/veneer/commit/14a1b8825d764dcf51b41c4bc0e15b732823f58d), [`d4e15a7`](https://github.azc.ext.hp.com/veneer/veneer/commit/d4e15a706609ce97edcf8a8b2f83dbde93a848b4), [`88c2ae0`](https://github.azc.ext.hp.com/veneer/veneer/commit/88c2ae0c14011a82e75a891079cfe13c618a33d0), [`986dbb4`](https://github.azc.ext.hp.com/veneer/veneer/commit/986dbb412d29c0031e8e052111cbaf702504434d), [`0cd81d1`](https://github.azc.ext.hp.com/veneer/veneer/commit/0cd81d12f8f9de6032d87ce2898253271b24d716), [`08fc3db`](https://github.azc.ext.hp.com/veneer/veneer/commit/08fc3db8545293104ea9af4964b6d487925ccd66), [`a0d2c16`](https://github.azc.ext.hp.com/veneer/veneer/commit/a0d2c162f159b7350f196cc0cfa5ce1956d1ae81), [`afbd6f3`](https://github.azc.ext.hp.com/veneer/veneer/commit/afbd6f3159062b585197498c403696b3d33e39d9), [`8c27665`](https://github.azc.ext.hp.com/veneer/veneer/commit/8c2766504e58472d8a457beefc22c414c433b431), [`0bb1303`](https://github.azc.ext.hp.com/veneer/veneer/commit/0bb13031d6c3f74081265f5ea7b40f59c1292555), [`a3765ca`](https://github.azc.ext.hp.com/veneer/veneer/commit/a3765ca2d9172fd5214eeb146291aac6034b5b97), [`97d8b85`](https://github.azc.ext.hp.com/veneer/veneer/commit/97d8b85a9fb8f7a5271877cb64c5d34254a4617f), [`aa84d22`](https://github.azc.ext.hp.com/veneer/veneer/commit/aa84d221a14b82cd929f71f4d596e033f1759180), [`836b834`](https://github.azc.ext.hp.com/veneer/veneer/commit/836b834e1d74a4a116d1fd2a5b5884792472f396), [`f7bf563`](https://github.azc.ext.hp.com/veneer/veneer/commit/f7bf5634828dab7e61b1050616e88e264a06948b), [`a984c97`](https://github.azc.ext.hp.com/veneer/veneer/commit/a984c976285393889a3ba9c53ca312fb765b49dc), [`836b834`](https://github.azc.ext.hp.com/veneer/veneer/commit/836b834e1d74a4a116d1fd2a5b5884792472f396)]:
  - @veneer/core@3.99.0

## 3.59.1

### Patch Changes

- Updated dependencies [[`e4c6c7d`](https://github.azc.ext.hp.com/veneer/veneer/commit/e4c6c7dcffd168e43a487edd8a19e6a400bb5a07), [`e4c6c7d`](https://github.azc.ext.hp.com/veneer/veneer/commit/e4c6c7dcffd168e43a487edd8a19e6a400bb5a07), [`3b5e8b3`](https://github.azc.ext.hp.com/veneer/veneer/commit/3b5e8b300e4875622d5c26a9cf9e73ddd8ca8ebd), [`e4c6c7d`](https://github.azc.ext.hp.com/veneer/veneer/commit/e4c6c7dcffd168e43a487edd8a19e6a400bb5a07), [`7a87a86`](https://github.azc.ext.hp.com/veneer/veneer/commit/7a87a8623112d5382afa3bcf76391fd72c4d77f1), [`e4c6c7d`](https://github.azc.ext.hp.com/veneer/veneer/commit/e4c6c7dcffd168e43a487edd8a19e6a400bb5a07), [`e4c6c7d`](https://github.azc.ext.hp.com/veneer/veneer/commit/e4c6c7dcffd168e43a487edd8a19e6a400bb5a07), [`e4c6c7d`](https://github.azc.ext.hp.com/veneer/veneer/commit/e4c6c7dcffd168e43a487edd8a19e6a400bb5a07), [`6ab8524`](https://github.azc.ext.hp.com/veneer/veneer/commit/6ab8524421dac59612276921aace793a8a8d09c5), [`dd99934`](https://github.azc.ext.hp.com/veneer/veneer/commit/dd99934fa1903b8f0d372857e0035efdc0297926), [`e4c6c7d`](https://github.azc.ext.hp.com/veneer/veneer/commit/e4c6c7dcffd168e43a487edd8a19e6a400bb5a07), [`e4c6c7d`](https://github.azc.ext.hp.com/veneer/veneer/commit/e4c6c7dcffd168e43a487edd8a19e6a400bb5a07), [`e4c6c7d`](https://github.azc.ext.hp.com/veneer/veneer/commit/e4c6c7dcffd168e43a487edd8a19e6a400bb5a07)]:
  - @veneer/core@3.98.0

## 3.59.0

### Minor Changes

- [#6088](https://github.azc.ext.hp.com/veneer/veneer/pull/6088) [`8fa272d`](https://github.azc.ext.hp.com/veneer/veneer/commit/8fa272d76c16b0d17576c0cfcc6b42f33c5d4bcf) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - Veneer packages have moved to a new repository on Nexus.

  In order to simplify Veneer's release process, Veneer packages are only published to the GitHub repository (https://npm.github.azc.ext.hp.com).

  To support users who need to use Nexus, there is a new Nexus repository (https://nexus-int.corp.hpicloud.net/repository/veneer-proxy/) that mirrors the GitHub repository.

  If you are using Nexus, and are unable to switch to GitHub, please update your configuration to point at this new repository.

### Patch Changes

- [#6232](https://github.azc.ext.hp.com/veneer/veneer/pull/6232) [`b7231a6`](https://github.azc.ext.hp.com/veneer/veneer/commit/b7231a6f6c845dbc9fb7a421ea0c3a5aeda6900b) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - [Foundation] Update packages

- Updated dependencies [[`0136aa9`](https://github.azc.ext.hp.com/veneer/veneer/commit/0136aa90ec3fdf17c6c2d7622996ca724ca4548b), [`8fa272d`](https://github.azc.ext.hp.com/veneer/veneer/commit/8fa272d76c16b0d17576c0cfcc6b42f33c5d4bcf), [`2b29997`](https://github.azc.ext.hp.com/veneer/veneer/commit/2b29997624437acc8bdaa40a9ccf71b9c955ba0b), [`b7231a6`](https://github.azc.ext.hp.com/veneer/veneer/commit/b7231a6f6c845dbc9fb7a421ea0c3a5aeda6900b)]:
  - @veneer/core@3.97.0

## 3.58.5

### Patch Changes

- Updated dependencies [[`6df1339`](https://github.azc.ext.hp.com/veneer/veneer/commit/6df133991ed07ebc73497ec6749374944d313fc0)]:
  - @veneer/core@3.96.0

## 3.58.4

### Patch Changes

- Updated dependencies [[`d6b31fa181`](https://github.azc.ext.hp.com/veneer/veneer/commit/d6b31fa18115541bafccca1e53329d1a3a97c37d)]:
  - @veneer/core@3.95.1

## 3.58.3

### Patch Changes

- Updated dependencies [[`8707c64a93`](https://github.azc.ext.hp.com/veneer/veneer/commit/8707c64a93b783928851275409dc00648689d9ac), [`8707c64a93`](https://github.azc.ext.hp.com/veneer/veneer/commit/8707c64a93b783928851275409dc00648689d9ac), [`854ac795c8`](https://github.azc.ext.hp.com/veneer/veneer/commit/854ac795c894bd75e7f4a164fe6c13ebca33f460), [`e144dd5e18`](https://github.azc.ext.hp.com/veneer/veneer/commit/e144dd5e185e7e5a4e538575524b2a507eee9cf7), [`c9658eaf33`](https://github.azc.ext.hp.com/veneer/veneer/commit/c9658eaf332642b76cab5886e58bb20d5f3b6079), [`f2b5da4724`](https://github.azc.ext.hp.com/veneer/veneer/commit/f2b5da4724f83541def45aebf2bc574e82c9f858), [`da566fc4ef`](https://github.azc.ext.hp.com/veneer/veneer/commit/da566fc4ef41349f86ddec4138da66f16b4533e5), [`94b9a5752d`](https://github.azc.ext.hp.com/veneer/veneer/commit/94b9a5752d438e0e1dacaf105d617203731c1eec), [`8ee6dc5de7`](https://github.azc.ext.hp.com/veneer/veneer/commit/8ee6dc5de792f0cf3db86b7a057d3060ce19aceb)]:
  - @veneer/core@3.95.0

## 3.58.2

### Patch Changes

- Updated dependencies [[`2821359eb5fe`](https://github.azc.ext.hp.com/veneer/veneer/commit/2821359eb5fe52f4e199f6633f77d2cd00457257), [`b0a6982d08cc`](https://github.azc.ext.hp.com/veneer/veneer/commit/b0a6982d08cc39aded0b838e6d00fafea9da5999), [`1d3dd55667da`](https://github.azc.ext.hp.com/veneer/veneer/commit/1d3dd55667da16f3ee9b8a601d2f527a460fbb49), [`0f9b6878adc8`](https://github.azc.ext.hp.com/veneer/veneer/commit/0f9b6878adc85db21c7766f47603b7ff9a12782e)]:
  - @veneer/core@3.94.0

## 3.58.1

### Patch Changes

- Updated dependencies [[`dcd71c594`](https://github.azc.ext.hp.com/veneer/veneer/commit/dcd71c5947eff83a536c9ada156b4adb9c620f65)]:
  - @veneer/core@3.93.0

## 3.58.0

### Minor Changes

- [#5931](https://github.azc.ext.hp.com/veneer/veneer/pull/5931) [`807caeaf2`](https://github.azc.ext.hp.com/veneer/veneer/commit/807caeaf2fe6908781815a40f8ca3db9fa2081ea) Thanks [@tulio-silva](https://github.azc.ext.hp.com/tulio-silva)! - [Icons] Veneer Icons now supports system colors or any hex/rgb string.

  [DatePicker] Fix Component visual bugs.

### Patch Changes

- Updated dependencies [[`e098f9585`](https://github.azc.ext.hp.com/veneer/veneer/commit/e098f9585316553787341855b22614908e149945), [`dda0a1319`](https://github.azc.ext.hp.com/veneer/veneer/commit/dda0a131946a0c935fb06cb6ad75d6e6f750652f), [`807caeaf2`](https://github.azc.ext.hp.com/veneer/veneer/commit/807caeaf2fe6908781815a40f8ca3db9fa2081ea)]:
  - @veneer/core@3.92.0

## 3.57.3

### Patch Changes

- Updated dependencies [[`889c8f465`](https://github.azc.ext.hp.com/veneer/veneer/commit/889c8f465c8f4c6ceeeb30371986049411a43275), [`165ed4b49`](https://github.azc.ext.hp.com/veneer/veneer/commit/165ed4b496ffd1e6fa1c3f3c17b920dc973633fd), [`7f865ceb5`](https://github.azc.ext.hp.com/veneer/veneer/commit/7f865ceb5558a37e6ba1f6f96930de4db95c92b3), [`646fce6d9`](https://github.azc.ext.hp.com/veneer/veneer/commit/646fce6d983305f21fcdfce3aa7bd9cdd6e9af9b), [`028304e68`](https://github.azc.ext.hp.com/veneer/veneer/commit/028304e685a4185ba2406737379c1157cbf058ce), [`b1032f2d4`](https://github.azc.ext.hp.com/veneer/veneer/commit/b1032f2d47ee87435435c80d2be842e1ab9136ba), [`baaad90c1`](https://github.azc.ext.hp.com/veneer/veneer/commit/baaad90c1f25f8decbf53ac66159d94332eb14c9), [`4dd996151`](https://github.azc.ext.hp.com/veneer/veneer/commit/4dd996151fe979095e7e98b32f2203855600e132), [`0b5558d12`](https://github.azc.ext.hp.com/veneer/veneer/commit/0b5558d1295294f7812d0547431ce21940052fa6), [`608893733`](https://github.azc.ext.hp.com/veneer/veneer/commit/6088937333b4b9b94b395c8d6830185f3d2273b3)]:
  - @veneer/core@3.91.0

## 3.57.2

### Patch Changes

- Updated dependencies [[`d741f01a8d`](https://github.azc.ext.hp.com/veneer/veneer/commit/d741f01a8dfaaa4ae96d325d00f023cee15445bd), [`7f865ceb55`](https://github.azc.ext.hp.com/veneer/veneer/commit/7f865ceb5558a37e6ba1f6f96930de4db95c92b3), [`b1032f2d47`](https://github.azc.ext.hp.com/veneer/veneer/commit/b1032f2d47ee87435435c80d2be842e1ab9136ba), [`baaad90c1f`](https://github.azc.ext.hp.com/veneer/veneer/commit/baaad90c1f25f8decbf53ac66159d94332eb14c9), [`4dd996151f`](https://github.azc.ext.hp.com/veneer/veneer/commit/4dd996151fe979095e7e98b32f2203855600e132)]:
  - @veneer/core@3.90.0

## 3.57.1

### Patch Changes

- Updated dependencies [[`251da94e0`](https://github.azc.ext.hp.com/veneer/veneer/commit/251da94e0480b905d40ced57ec5519e3613e431f), [`94915652f`](https://github.azc.ext.hp.com/veneer/veneer/commit/94915652fdc7a57d648e5acf6cc06e019890517d), [`809bea155`](https://github.azc.ext.hp.com/veneer/veneer/commit/809bea155d43958075a80592fa269eb89d7fad54), [`4ef92a8f5`](https://github.azc.ext.hp.com/veneer/veneer/commit/4ef92a8f5acc112b132fc75f90e60e29fc4cc412), [`5e83c2e09`](https://github.azc.ext.hp.com/veneer/veneer/commit/5e83c2e0958c5f6473a83452d89221a1d92f6367), [`d50706a60`](https://github.azc.ext.hp.com/veneer/veneer/commit/d50706a606be5637e34a7bb9179c136539127cef), [`1ea724a26`](https://github.azc.ext.hp.com/veneer/veneer/commit/1ea724a267e8d05c6d08045959385811a7ce06b5), [`c0b9b4d13`](https://github.azc.ext.hp.com/veneer/veneer/commit/c0b9b4d136a2a5f63536d5fba9a873e002a09e70), [`94915652f`](https://github.azc.ext.hp.com/veneer/veneer/commit/94915652fdc7a57d648e5acf6cc06e019890517d), [`f2af3cbdc`](https://github.azc.ext.hp.com/veneer/veneer/commit/f2af3cbdc730102c3e7dad8e00e9227e9970f475), [`6767e8c4d`](https://github.azc.ext.hp.com/veneer/veneer/commit/6767e8c4dd000b0f1ba4529288fb99da04aa0ec7), [`a933e15ef`](https://github.azc.ext.hp.com/veneer/veneer/commit/a933e15ef60632caf6da1d978d1d0ee411e17eef), [`bfba5865a`](https://github.azc.ext.hp.com/veneer/veneer/commit/bfba5865aad051827f3e253346e2ff861f8f0d03), [`16451bf39`](https://github.azc.ext.hp.com/veneer/veneer/commit/16451bf3941b4fe1f9b98b23e33ca55079169c1e)]:
  - @veneer/core@3.89.0

## 3.57.0

### Minor Changes

- [#5398](https://github.azc.ext.hp.com/veneer/veneer/pull/5398) [`122765e2b`](https://github.azc.ext.hp.com/veneer/veneer/commit/122765e2bbd057601597ea64b60c567901b2fcaf) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - [Infra] Internal code structure changed

  In order to normalise our build steps, internal code structure of the shipped `@veneer/flags` and `@veneer/theme` packages has changed.

  If you are currently importing from the root (e.g. `import { ThemeProvider} from '@veneer/theme'`) then no change is required.

  If you are importing from specific files (which is not recommended), you will need to add `dist` to the root of the import, e.g. `import ThemeProvider from '@vener/theme/dist/theme_provider'`.

### Patch Changes

- Updated dependencies [[`275ba6022`](https://github.azc.ext.hp.com/veneer/veneer/commit/275ba60225f37fdd4036935902c4e283ee9a24d6), [`caa0eb1d0`](https://github.azc.ext.hp.com/veneer/veneer/commit/caa0eb1d0d8bd3cacb4c10113599662a43f077a9), [`016db5893`](https://github.azc.ext.hp.com/veneer/veneer/commit/016db5893bbb3d45c833c2abbe95a14f1e0102ea), [`2471849ee`](https://github.azc.ext.hp.com/veneer/veneer/commit/2471849eeaf711fbda2dedb44fe7e097b85c357f)]:
  - @veneer/core@3.88.0

## 3.56.3

### Patch Changes

- Updated dependencies [[`3c2d28c05`](https://github.azc.ext.hp.com/veneer/veneer/commit/3c2d28c058be864186c6d41c24e7a4d0c5207d9e), [`70481ae74`](https://github.azc.ext.hp.com/veneer/veneer/commit/70481ae748c89580f940b15bca73f8219bba2e95), [`9ead481e3`](https://github.azc.ext.hp.com/veneer/veneer/commit/9ead481e318379e848cf0aee6b24545406b677c2), [`cd43e6401`](https://github.azc.ext.hp.com/veneer/veneer/commit/cd43e6401cbc61a0862ee5eead5f051283f28d49), [`0f5c8357e`](https://github.azc.ext.hp.com/veneer/veneer/commit/0f5c8357e964388e584502148dc8c5f32ef7883d), [`5636556ba`](https://github.azc.ext.hp.com/veneer/veneer/commit/5636556ba00df7ceeb580f39cb047a42da541edf), [`9ead481e3`](https://github.azc.ext.hp.com/veneer/veneer/commit/9ead481e318379e848cf0aee6b24545406b677c2), [`db392cecd`](https://github.azc.ext.hp.com/veneer/veneer/commit/db392cecda8f03b29ddf15ae0652114250f8ab6a), [`2d4e9f281`](https://github.azc.ext.hp.com/veneer/veneer/commit/2d4e9f281c0c32ed3f910a461065f451b4e820cf)]:
  - @veneer/core@3.87.0

## 3.56.2

### Patch Changes

- [#5423](https://github.azc.ext.hp.com/veneer/veneer/pull/5423) [`61d3b09e37`](https://github.azc.ext.hp.com/veneer/veneer/commit/61d3b09e375a335dafad889058ebaf68cd475d2e) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - [Flag] Import CustomImage from barrel file

- Updated dependencies [[`6bf6b77a00`](https://github.azc.ext.hp.com/veneer/veneer/commit/6bf6b77a002e1b57000b6d91c49d45dc848159c9), [`f9552ce040`](https://github.azc.ext.hp.com/veneer/veneer/commit/f9552ce040ea717395da24f2d7c10967e6620c61), [`9fd80ee1b6`](https://github.azc.ext.hp.com/veneer/veneer/commit/9fd80ee1b6e23e102389e6a6be690a51ecb35aff), [`36cc88df1e`](https://github.azc.ext.hp.com/veneer/veneer/commit/36cc88df1e7de4ba220b9927c7f8575e4483317c)]:
  - @veneer/core@3.86.0

## 3.56.1

### Patch Changes

- Updated dependencies [[`f90a410150`](https://github.azc.ext.hp.com/veneer/veneer/commit/f90a41015039222cf0babcabdfe99dfd8d57cfba), [`7fc61591b8`](https://github.azc.ext.hp.com/veneer/veneer/commit/7fc61591b8c6a09c8861790d192f7fba3ae6ad2a), [`6dd9d0e3ad`](https://github.azc.ext.hp.com/veneer/veneer/commit/6dd9d0e3ad17950e76630024074f6d888c2be0c2), [`ef69a228ae`](https://github.azc.ext.hp.com/veneer/veneer/commit/ef69a228ae588ff625a34b564fc2410370bfb172), [`11667f13bd`](https://github.azc.ext.hp.com/veneer/veneer/commit/11667f13bd262d2cffd5d8dc7c21fa617285fbb2), [`ead2a3f60d`](https://github.azc.ext.hp.com/veneer/veneer/commit/ead2a3f60de18c41464293205c72ffd920a2bda0)]:
  - @veneer/core@3.85.0

## 3.56.0

### Minor Changes

- [#5424](https://github.azc.ext.hp.com/veneer/veneer/pull/5424) [`1ebd9c926d`](https://github.azc.ext.hp.com/veneer/veneer/commit/1ebd9c926dc637efb4695742ca5ae25094c7f5a3) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [Icons] Update placeholder icon when there is no shape available.

### Patch Changes

- Updated dependencies [[`cd698732d9`](https://github.azc.ext.hp.com/veneer/veneer/commit/cd698732d9bc3a3f068690cd64927612c0d22887), [`3e98039103`](https://github.azc.ext.hp.com/veneer/veneer/commit/3e980391031fcedcf920785bb933f5749f72e433), [`bb3be63ef3`](https://github.azc.ext.hp.com/veneer/veneer/commit/bb3be63ef3d98e5f174ca9df208bf1f08bd867e3), [`9f527767b8`](https://github.azc.ext.hp.com/veneer/veneer/commit/9f527767b808397ba848841c430ffc4eb1ece956), [`1ebd9c926d`](https://github.azc.ext.hp.com/veneer/veneer/commit/1ebd9c926dc637efb4695742ca5ae25094c7f5a3), [`b0819af6cd`](https://github.azc.ext.hp.com/veneer/veneer/commit/b0819af6cd1e0c8f60e0af947458c5689880fce0), [`99c30e56e3`](https://github.azc.ext.hp.com/veneer/veneer/commit/99c30e56e3f50476e95fa0bf02aa3c326d889471), [`d325eae3c4`](https://github.azc.ext.hp.com/veneer/veneer/commit/d325eae3c49593731c0cf97068dcb643033abbad), [`7e7914043e`](https://github.azc.ext.hp.com/veneer/veneer/commit/7e7914043eb969c91572d35c83ae386bd91db22f), [`75eb8dcc22`](https://github.azc.ext.hp.com/veneer/veneer/commit/75eb8dcc227903051751da0a9006a05a52206c0f), [`ae7b94ebf6`](https://github.azc.ext.hp.com/veneer/veneer/commit/ae7b94ebf69563458e210f3b4797aa0f52f3cc22), [`2b792f16f8`](https://github.azc.ext.hp.com/veneer/veneer/commit/2b792f16f8e74bc20e0c54b4480a13cf537110ea), [`8af0d73ca7`](https://github.azc.ext.hp.com/veneer/veneer/commit/8af0d73ca7957d9279e48aa3ad99c24a3a633415), [`062428b77d`](https://github.azc.ext.hp.com/veneer/veneer/commit/062428b77d3cefa178fbe40c5a310c981f92319b), [`223e173389`](https://github.azc.ext.hp.com/veneer/veneer/commit/223e173389781e9b9785e80aaf50b74b2bef7100)]:
  - @veneer/core@3.84.0

## 3.55.1

## 3.55.0

### Minor Changes

- [#5307](https://github.azc.ext.hp.com/veneer/veneer/pull/5307) [`93a7687c70`](https://github.azc.ext.hp.com/veneer/veneer/commit/93a7687c705912b57496f84c28d62161165b9025) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - [Flags] Update flag sources to use typescript

  This also updates the sources for the flags which updates about 24 flags and adds eight new ones.

### Patch Changes

- Updated dependencies [[`6ac33f1a7f`](https://github.azc.ext.hp.com/veneer/veneer/commit/6ac33f1a7f62debcaef13e7efd81b0fed45b69ac), [`7a21c5cb96`](https://github.azc.ext.hp.com/veneer/veneer/commit/7a21c5cb96a6d92ae64c37e1b4c3a20ba945eef2), [`370e7dbaa4`](https://github.azc.ext.hp.com/veneer/veneer/commit/370e7dbaa4a3e96f0f877ffe06946ce2e6545007), [`93a7687c70`](https://github.azc.ext.hp.com/veneer/veneer/commit/93a7687c705912b57496f84c28d62161165b9025), [`b6ac19a251`](https://github.azc.ext.hp.com/veneer/veneer/commit/b6ac19a251c62da6369a8fe86b01baa0d3406347), [`7a21c5cb96`](https://github.azc.ext.hp.com/veneer/veneer/commit/7a21c5cb96a6d92ae64c37e1b4c3a20ba945eef2), [`a562b7b45a`](https://github.azc.ext.hp.com/veneer/veneer/commit/a562b7b45a2ba18779195ce4f0fa73187074c0c8), [`2e2b4df516`](https://github.azc.ext.hp.com/veneer/veneer/commit/2e2b4df516f4782b373731eff02a705bc1d511d1), [`c74a54d4d5`](https://github.azc.ext.hp.com/veneer/veneer/commit/c74a54d4d5f06dc2e2c66f2047b9fed6030acb64), [`9a90b12f45`](https://github.azc.ext.hp.com/veneer/veneer/commit/9a90b12f4578536f10fda983fa0807afea1179d5), [`96a359817f`](https://github.azc.ext.hp.com/veneer/veneer/commit/96a359817f18067a7c56c2b22d6ed2856f9e5eb3), [`f5e53b8c03`](https://github.azc.ext.hp.com/veneer/veneer/commit/f5e53b8c03d9c9db358c9ff7889d8e29f4e38de8), [`a36a264f63`](https://github.azc.ext.hp.com/veneer/veneer/commit/a36a264f632edc184d8dd01622b7595bd10dddff), [`a7cc1eba63`](https://github.azc.ext.hp.com/veneer/veneer/commit/a7cc1eba6371fc48d500aeb3c1f7835a31cc326a), [`ba0c675581`](https://github.azc.ext.hp.com/veneer/veneer/commit/ba0c67558105d1997fbb654ff1ff758b09fb06a6), [`9993633591`](https://github.azc.ext.hp.com/veneer/veneer/commit/999363359191418529d365b57e3474b6b252c76a), [`0cad46e0e0`](https://github.azc.ext.hp.com/veneer/veneer/commit/0cad46e0e03aa55e575622be2c0ac1d7f9392937), [`c24a40f209`](https://github.azc.ext.hp.com/veneer/veneer/commit/c24a40f2094578faf9d217aa52832817d9d16f3c), [`370e7dbaa4`](https://github.azc.ext.hp.com/veneer/veneer/commit/370e7dbaa4a3e96f0f877ffe06946ce2e6545007)]:
  - @veneer/core@3.83.0

## 3.54.24

## 3.54.23

## 3.54.22

## 3.54.21

## 3.54.20

## 3.54.19

## 3.54.18

## 3.54.17

## 3.54.16

## 3.54.15

## 3.54.14

## 3.54.13

## 3.54.12

## 3.54.11

## 3.54.10

## 3.54.9

## 3.54.8

## 3.54.7

## 3.54.6

## 3.54.5

## 3.54.4

## 3.54.3

## 3.54.2

## 3.54.1

## 3.54.0

### Minor Changes

- [#4589](https://github.azc.ext.hp.com/veneer/veneer/pull/4589) [`6f1cedaa0`](https://github.azc.ext.hp.com/veneer/veneer/commit/6f1cedaa010404f6bfe53bd658e7b4a6c0794a2f) Thanks [@douglas-michaelsen](https://github.azc.ext.hp.com/douglas-michaelsen)! - Refactoring RefAttributes and HTMLAttributes types for Button and Card components

## 3.53.6

## 3.53.5

## 3.53.4

## 3.53.3

## 3.53.2

## 3.53.1

## 3.53.0

### Minor Changes

- [#4379](https://github.azc.ext.hp.com/veneer/veneer/pull/4379) [`d600198ee`](https://github.azc.ext.hp.com/veneer/veneer/commit/d600198eeefe728c314b74c0068dbdecab461f37) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [Infra] Support React 18

## 3.52.0

## 3.51.0

## 3.50.0

## 3.49.1

## 3.49.0

## 3.48.1

## 3.48.0

## 3.47.0

### Minor Changes

- [#4177](https://github.azc.ext.hp.com/veneer/veneer/pull/4177) [`286293cb8`](https://github.azc.ext.hp.com/veneer/veneer/commit/286293cb89185e894fd09e1799b18275d54fad95) Thanks [@bianca-camargo-machado1](https://github.azc.ext.hp.com/bianca-camargo-machado1)! - [Icon] Icons in Print Category - Filled versions

      ⚠ The old "IconRibbon" is "IconRibbonCheckmark" now and "IconRibbon" has a new SVG

## 3.46.0

## 3.45.1

## 3.45.0

## 3.44.0

## 3.43.0

## 3.42.1

## 3.42.0

## 3.41.0

### Minor Changes

- [#3989](https://github.azc.ext.hp.com/veneer/veneer/pull/3989) [`fe9508f19`](https://github.azc.ext.hp.com/veneer/veneer/commit/fe9508f198dc70c679be553506f40a4a36ab82f9) Thanks [@bianca-camargo-machado1](https://github.azc.ext.hp.com/bianca-camargo-machado1)! - [Flag] Avoid replacing default black color by the themes variables
