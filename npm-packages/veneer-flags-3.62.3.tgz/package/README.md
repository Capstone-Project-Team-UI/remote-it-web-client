# @veneer/flags

## Installation

The `@veneer/flags` package is available in a private NPM registry under the `@veneer` scope. For more details check the [documentation page](http://veneer.design) to get started.

```bash
npm install --save @veneer/flags
```

or

```bash
yarn add @veneer/flags
```

## Flags

Currently, the `@veneer/flags` package support all the svg country flags provided by [flag-icon-css](https://github.com/lipis/flag-icon-css).

#### Usage

```js
import React from 'react';
import { FlagBR, FlagUS } from '@veneer/flags';

export default function Flags() {
  return (
    <div>
      <FlagBR />
      <FlagUS size={100} disabled />
    </div>
  );
}
```

#### ThemeProvider

```js
import React from 'react';
import { FlagBR, FlagUS } from '@veneer/flags';
import { ThemeProvider } from '@veneer/theme';

export default function Flags() {
  return (
    <ThemeProvider shape="sharp">
      <FlagBR />
    </ThemeProvider>
  );
}
```

## Documentation

If you're looking for `@veneer/flags` documentation, check out:

- [Veneer](https://veneer.hp.com/)
