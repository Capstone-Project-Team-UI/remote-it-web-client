# @veneer/styles

## 3.64.0

### Minor Changes

- [#6759](https://github.azc.ext.hp.com/veneer/veneer/pull/6759) [`20e1aec`](https://github.azc.ext.hp.com/veneer/veneer/commit/20e1aec2ed38d20e74894f7824c4894e1f25e46a) Thanks [@walter-ferreira](https://github.azc.ext.hp.com/walter-ferreira)! - [Typography] Added new classes for `body-regular`, `label-regular` and `caption-regular`.

## 3.63.0

### Minor Changes

- [`9ee153f`](https://github.azc.ext.hp.com/veneer/veneer/commit/9ee153fcdc13f03e341205c556fb24e157583aef) Thanks [@walter-ferreira](https://github.azc.ext.hp.com/walter-ferreira)! - [Foundation] Update @veneer/assets to 3.14.0, update @veneer/primitives to 3.63.0 and update @veneer/semantics to 3.9.0

## 3.62.0

### Minor Changes

- [#6598](https://github.azc.ext.hp.com/veneer/veneer/pull/6598) [`818db74`](https://github.azc.ext.hp.com/veneer/veneer/commit/818db74ae3486ffe550c5d40c45d621906d6d027) Thanks [@anderson-freitas](https://github.azc.ext.hp.com/anderson-freitas)! - [Foundation] Update @veneer/assets to 3.13.0, update @veneer/primitives to 3.62.0 and update @veneer/semantics to 3.8.0

## 3.61.0

### Minor Changes

- [#6448](https://github.azc.ext.hp.com/veneer/veneer/pull/6448) [`2ca77c0`](https://github.azc.ext.hp.com/veneer/veneer/commit/2ca77c0ba1efe9d8321e73c93994531f593f16ee) Thanks [@pedro-soares](https://github.azc.ext.hp.com/pedro-soares)! - [Foundation] Update @veneer/assets to 3.9.0, update @veneer/primitives to 3.61.1 and update @veneer/semantics to 3.7.0

## 3.60.0

### Minor Changes

- [#6396](https://github.azc.ext.hp.com/veneer/veneer/pull/6396) [`aa84d22`](https://github.azc.ext.hp.com/veneer/veneer/commit/aa84d221a14b82cd929f71f4d596e033f1759180) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [Foundation] Update @veneer/assets to 3.8.0, update @veneer/primitives to 3.61.0 and update @veneer/semantics to 3.6.0

- [#6298](https://github.azc.ext.hp.com/veneer/veneer/pull/6298) [`a984c97`](https://github.azc.ext.hp.com/veneer/veneer/commit/a984c976285393889a3ba9c53ca312fb765b49dc) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - [React] Update minimum supported react to 16.14.0

  This is in preparation for a future update to React 17; it is strongly recommended to update to React 18.

## 3.59.0

### Minor Changes

- [#6088](https://github.azc.ext.hp.com/veneer/veneer/pull/6088) [`8fa272d`](https://github.azc.ext.hp.com/veneer/veneer/commit/8fa272d76c16b0d17576c0cfcc6b42f33c5d4bcf) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - Veneer packages have moved to a new repository on Nexus.

  In order to simplify Veneer's release process, Veneer packages are only published to the GitHub repository (https://npm.github.azc.ext.hp.com).

  To support users who need to use Nexus, there is a new Nexus repository (https://nexus-int.corp.hpicloud.net/repository/veneer-proxy/) that mirrors the GitHub repository.

  If you are using Nexus, and are unable to switch to GitHub, please update your configuration to point at this new repository.

## 3.58.1

### Patch Changes

- [#6064](https://github.azc.ext.hp.com/veneer/veneer/pull/6064) [`da566fc4ef`](https://github.azc.ext.hp.com/veneer/veneer/commit/da566fc4ef41349f86ddec4138da66f16b4533e5) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - [Styles] Fix anchor outline flickering

  Anchor outlines would briefly flicker when clicking away from a clicked anchor.

## 3.58.0

### Minor Changes

- [#5397](https://github.azc.ext.hp.com/veneer/veneer/pull/5397) [`8f0286084`](https://github.azc.ext.hp.com/veneer/veneer/commit/8f0286084602e9c733d467f829d816ffed681dab) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [Tokens] Consume new tokens package. If your project use tokens outside components, [consider reading this how to migrate guide](https://stackoverflow.hp.dev/articles/6485).

## 3.57.0

### Minor Changes

- [#5335](https://github.azc.ext.hp.com/veneer/veneer/pull/5335) [`dff4fe454`](https://github.azc.ext.hp.com/veneer/veneer/commit/dff4fe454f7b5edcdaa911cdbb27b0e6be7d65b6) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [CssBaseline] Convert source files to typescript.

## 3.56.0

### Minor Changes

- [#4962](https://github.azc.ext.hp.com/veneer/veneer/pull/4962) [`0791e2737`](https://github.azc.ext.hp.com/veneer/veneer/commit/0791e2737dc41c818aa9810269b043e55466fdb1) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [Typography] Prevent potential faux bold/slant across browsers and OSs.

## 3.55.0

### Minor Changes

- [#4760](https://github.azc.ext.hp.com/veneer/veneer/pull/4760) [`cae21572e`](https://github.azc.ext.hp.com/veneer/veneer/commit/cae21572e750bb05a4f21b7f8faa3104e9dca331) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [Typography] Forma DJR UI update
  🆕 Additions:

  New className `.salt` which applies new high-legibility CSS.
  When using `<i>` or `.italic` className, `Forma DJR UI Italic` will be used.
  New token `fontTextItalic`.

  ❌ Removals:

  Specific font for bold tags `<strong>`, `<b>`. Now, Forma DJR UI is the deafult font for it.
  Removed `letter-spacing: 'normal'` from `ar, bg, el, he, ja, ko, ru, sr, th, uk, zh` languages. It will be handled by `Forma DJR UI`.

  ⭐ Changes:

  Tokens:

  `fontTextRegular` from `Forma DJR Display` to `Forma DJR UI`.
  `fontTitleRegular` from `Forma DJR Display` to `Forma DJR UI`.
  All `letterSpacing` tokens have a new value `0`.

## 3.54.0

### Minor Changes

- [#4834](https://github.azc.ext.hp.com/veneer/veneer/pull/4834) [`775392b5e7`](https://github.azc.ext.hp.com/veneer/veneer/commit/775392b5e754d40cebed1641a52db3ab3900f0a3) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [Typography] Define values for `<sub />` and `<sup />` tags

## 3.53.0

### Minor Changes

- [#4379](https://github.azc.ext.hp.com/veneer/veneer/pull/4379) [`d600198ee`](https://github.azc.ext.hp.com/veneer/veneer/commit/d600198eeefe728c314b74c0068dbdecab461f37) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [Infra] Support React 18

### Patch Changes

- [#4374](https://github.azc.ext.hp.com/veneer/veneer/pull/4374) [`8a90864b8`](https://github.azc.ext.hp.com/veneer/veneer/commit/8a90864b8370100d31efa84dca7f3094d3b07b19) Thanks [@bianca-camargo-machado1](https://github.azc.ext.hp.com/bianca-camargo-machado1)! - [Typography] Fix subtitleLarge spacing on small breakpoint

* [#4369](https://github.azc.ext.hp.com/veneer/veneer/pull/4369) [`f78e174a5`](https://github.azc.ext.hp.com/veneer/veneer/commit/f78e174a5e24bbb4e82e6d7f721ee935d2e6b446) Thanks [@bianca-camargo-machado1](https://github.azc.ext.hp.com/bianca-camargo-machado1)! - [Typography] Fix Title Large on medium breakpoint

## 3.52.0

### Minor Changes

- [#4255](https://github.azc.ext.hp.com/veneer/veneer/pull/4255) [`122e3a6b2`](https://github.azc.ext.hp.com/veneer/veneer/commit/122e3a6b2b66a8c5fec47010233dd4fba0bbeb3c) Thanks [@bianca-camargo-machado1](https://github.azc.ext.hp.com/bianca-camargo-machado1)! - Update typography to Forma DJR

  ⚠ `title-large--light`, `title-medium--light`, `title-regular--light`, `title-small--light`, `subtitle-large--light`, and `subtitle-regular--light` styles have been deprecated and it'll be removed in the next major release.

  ⚠ `fontFamilyLight` and `fontFamilyRegular`tokens have been deprecated and it'll be removed in the next major release.

  ⚠ The current fallback font for Middle East is Arial.

  🆕 New tokens: `fontTextRegular`, `fontTextMedium`, and `fontTitleRegular`.

  🎨 Updates on: `letterSpacing1`, `letterSpacing2`, `letterSpacing3`, `letterSpacing4` and `letterSpacing5` tokens.

## 3.45.0

### Minor Changes

- [#4118](https://github.azc.ext.hp.com/veneer/veneer/pull/4118) [`c0dddb8d4`](https://github.azc.ext.hp.com/veneer/veneer/commit/c0dddb8d463fef243c58daffbad034c2b006a52d) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [Typography] Add new type style "Label Small".
