# @veneer/styles

## Installation

The `@veneer/styles` package is available in a private NPM registry under the `@veneer` scope. For more details check the [documentation page](http://veneer.design) to get started.

```bash
npm install --save @veneer/styles
```

or

```bash
yarn add @veneer/styles
```

## Styles

### Typography

Currently, the `@veneer/styles` package has only our Typography styles.

#### Usage

```js
import React from 'react';
import '@veneer/styles/typography/typography.css';

export default function Typography() {
  return (
    <div>
      <h1>Typography H1</h1>
      <h2>Typography H2</h2>
      <h3>Typography H3</h3>
      <h4>Typography H4</h4>
      <h5>Typography H5</h5>
      <h6>Typography H6</h6>
      <p className="title-large">ClassName Title Large</p>
      <p className="title-medium">ClassName Title Medium</p>
    </div>
  );
}
```

## Documentation

If you're looking for `@veneer/styles` documentation, check out:

- [Veneer](https://veneer.hp.com/)
