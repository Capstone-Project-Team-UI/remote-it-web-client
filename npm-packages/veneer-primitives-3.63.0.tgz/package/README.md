# @veneer/primitives

> Primitives are representations of a visual property such as typography, color, spacing, etc. These primitive values are language / application agnostic and can be used on any platform.

## Installation

The `@veneer/primitives` package is available in a private NPM registry under the `@veneer` scope. For more details check the [documentation page](https://veneer.hp.com/platforms/web/get-started/develop-with-veneer-web/) to get started.

```bash
npm install --save @veneer/primitives
```

or

```bash
yarn add @veneer/primitives
```

## Usage

> All primitives and their values can be viewed on the [Design Tokens](https://veneer.hp.com/foundation/design-tokens/library/) page.

### Javascript

In Javascript, you can import this module from the default export by doing the following in your code:

```js
// ESM
import primitives from '@veneer/primitives';

// CommonJS
const primitives = require('@veneer/primitives');
```

Javascript primitives names are formatted in "camelCase", eg.: `primitives.color.hpBlue6`.

#### Example with style prop

This is a example how to style a simple HTML button with `@veneer/primitives` in Javascript.

```js
import React from 'react';
import primitives from '@veneer/primitives';

const Button = ({ children }) => (
  <button
    onClick={(e) => console.log(e)}
    style={{
      backgroundColor: primitives.color.hpBlue6,
      borderRadius: primitives.layout.borderRadius4,
      color: primitives.color.white,
      fontFamily: primitives.typography.family0,
      fontSize: primitives.typography.fontSize3,
      lineHeight: primitives.typography.lineHeight3,
      padding: `${primitives.layout.size3} ${primitives.layout.size8}`,
    }}
    type="button"
  >
    {children}
  </button>
);

export default Button;
```

### Sass

In Sass, you can import the primitives by doing:

```scss
@import '<path_to_node_modules>/@veneer/primitives/dist/primitives.scss';
```

Sass primitives names are formatted in "kebab-case", eg.: `$color-hp-blue6`.

#### Example

This is a example how to style a simple HTML button with `@veneer/primitives` in Sass.

- Style:

```scss
// button.scss
@import './node_modules/@veneer/primitives/dist/primitives.scss';

.button-with-primitives {
  background-color: $color-hp-blue6;
  border-radius: $layout-corner-radius4;
  color: $color-white;
  font-family: $typography-family0;
  font-size: $typography-size3;
  line-height: $typography-line-height3;
  padding: $layout-size3 $layout-size8;
}
```

- Component:

```js
// button.js
import React from 'react';
import './button.scss'; // When using node-sass and CRA

const Button = ({ children }) => (
  <button
    className="button-with-primitives"
    onClick={(e) => console.log(e)}
    type="button"
  >
    {children}
  </button>
);

export default Button;
```

## Documentation

If you're looking for `@veneer/primitives` documentation, check out:

- [Design Tokens](https://veneer.hp.com/foundation/design-tokens/library/)
