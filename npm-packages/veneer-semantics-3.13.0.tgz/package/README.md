# @veneer/semantics

> Semantics tokens are representations of visual properties that can vary depending on semantics, like light and dark modes, standard and high densities and sharp and round shapes. These semantic values are language / application agnostic and can be used on any platform.

## Installation

The `@veneer/semantics` package is available in a private NPM registry under the `@veneer` scope. For more details check the [documentation page](https://veneer.hp.com/platforms/web/get-started/develop-with-veneer-web/) to get started.

```bash
npm install --save @veneer/semantics
```

or

```bash
yarn add @veneer/semantics
```

## Usage

> More details on how to customize colors on Veneer can be found [here](https://veneer.hp.com/platforms/web/providers/theme/customize/).

## Documentation

If you're looking for more information about Veneer, check this out:

- [Veneer Website](https://veneer.hp.com/)
