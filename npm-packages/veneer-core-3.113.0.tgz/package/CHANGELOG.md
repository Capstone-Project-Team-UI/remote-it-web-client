# @veneer/core

## 3.113.0

### Minor Changes

- [#7026](https://github.azc.ext.hp.com/veneer/veneer/pull/7026) [`58ea6d8`](https://github.azc.ext.hp.com/veneer/veneer/commit/58ea6d864e51af1bb0556a5e07dc314fac9d1c82) Thanks [@walter-ferreira](https://github.azc.ext.hp.com/walter-ferreira)! - [NotificationBadge] Fix count variation `border-color` in high contrast mode.

- [#6976](https://github.azc.ext.hp.com/veneer/veneer/pull/6976) [`dc378eb`](https://github.azc.ext.hp.com/veneer/veneer/commit/dc378eb376bf82f7e71e321edc23b500059161da) Thanks [@joao-flores-de-leao](https://github.azc.ext.hp.com/joao-flores-de-leao)! - [DatePicker]
  [FilePicker]
  [Password]
  [Search]
  [TextArea]
  [TextBox]

  - Restructure of the components -> Inputs are now more independent.
  - Enhanced documentation -> typescript and inherited props were validate and corrected.
  - Accessibility conformance -> Restructure of the component impact on the DOM and more relationship between inputs, labels and helper texts.
  - Redesign FilePicker to match other inputs design.
  - Separate Range DatePicker inputs interaction for better accessibility.
  - For more information, check our latest announcement on our website https://veneer.hpbp.io/

- [#7074](https://github.azc.ext.hp.com/veneer/veneer/pull/7074) [`83e66a5`](https://github.azc.ext.hp.com/veneer/veneer/commit/83e66a5c45a723bb4bc708433addb4dceada436a) Thanks [@walter-ferreira](https://github.azc.ext.hp.com/walter-ferreira)! - Update @veneer/assets package to 3.21

- [#6973](https://github.azc.ext.hp.com/veneer/veneer/pull/6973) [`8696106`](https://github.azc.ext.hp.com/veneer/veneer/commit/8696106e345abb1eb7ee4f373311018d66c340fa) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [NotificationCenter] Add `topContentArea` which is rendered on the top of the content.

- [#7070](https://github.azc.ext.hp.com/veneer/veneer/pull/7070) [`27e451b`](https://github.azc.ext.hp.com/veneer/veneer/commit/27e451b37128d29f385a8516ca84c34976f78678) Thanks [@vinicius-silva](https://github.azc.ext.hp.com/vinicius-silva)! - [Anchor Menu] added noWrap optional prop

- [#7025](https://github.azc.ext.hp.com/veneer/veneer/pull/7025) [`26161e8`](https://github.azc.ext.hp.com/veneer/veneer/commit/26161e8fafbd699a2f66d6f1371a64adfd2b3087) Thanks [@walter-ferreira](https://github.azc.ext.hp.com/walter-ferreira)! - [Hyperlink] Add underline decoration to the default state

- [#7029](https://github.azc.ext.hp.com/veneer/veneer/pull/7029) [`d17ddda`](https://github.azc.ext.hp.com/veneer/veneer/commit/d17ddda3ed6ce9fa5e7ae37f054966fef7ff19af) Thanks [@tamires-silva](https://github.azc.ext.hp.com/tamires-silva)! - [Avatar] Update with double focus ring

### Patch Changes

- [#6978](https://github.azc.ext.hp.com/veneer/veneer/pull/6978) [`f3bf166`](https://github.azc.ext.hp.com/veneer/veneer/commit/f3bf166dff615e06e7514a1fd816c5b9d3ef8e61) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - [Infra] Ensure compatibility with React 19 types

- [#7067](https://github.azc.ext.hp.com/veneer/veneer/pull/7067) [`64ade0f`](https://github.azc.ext.hp.com/veneer/veneer/commit/64ade0f6fb61fc32d81f557e691379a3f43e509e) Thanks [@vinicius-silva](https://github.azc.ext.hp.com/vinicius-silva)! - [Select] Add Tooltip to the options

- Updated dependencies [[`f3bf166`](https://github.azc.ext.hp.com/veneer/veneer/commit/f3bf166dff615e06e7514a1fd816c5b9d3ef8e61), [`dc378eb`](https://github.azc.ext.hp.com/veneer/veneer/commit/dc378eb376bf82f7e71e321edc23b500059161da)]:
  - @veneer/theme@3.89.0

## 3.112.1

### Patch Changes

- [#6994](https://github.azc.ext.hp.com/veneer/veneer/pull/6994) [`21bbbe7`](https://github.azc.ext.hp.com/veneer/veneer/commit/21bbbe7cb586b75429040ca456ffa6bad5295806) Thanks [@joao-flores-de-leao](https://github.azc.ext.hp.com/joao-flores-de-leao)! - [Foundation] Update foundation packages.

- Updated dependencies [[`21bbbe7`](https://github.azc.ext.hp.com/veneer/veneer/commit/21bbbe7cb586b75429040ca456ffa6bad5295806)]:
  - @veneer/theme@3.88.1

## 3.112.0

### Minor Changes

- [#6963](https://github.azc.ext.hp.com/veneer/veneer/pull/6963) [`f66d37a`](https://github.azc.ext.hp.com/veneer/veneer/commit/f66d37a8009f92cad000c86d44653ae1efaa2391) Thanks [@pedro-soares](https://github.azc.ext.hp.com/pedro-soares)! - [Select] Fix the behavior when the SelectInput label had Tooltip not allowing the user to open the select modal.

- [#6933](https://github.azc.ext.hp.com/veneer/veneer/pull/6933) [`eef1052`](https://github.azc.ext.hp.com/veneer/veneer/commit/eef1052f16d902f7f2046d622b1b30ae662dedd3) Thanks [@pedro-soares](https://github.azc.ext.hp.com/pedro-soares)! - [NotificationCenter] Hide scrollBar when there isn't overflow.

- [#6950](https://github.azc.ext.hp.com/veneer/veneer/pull/6950) [`0930bda`](https://github.azc.ext.hp.com/veneer/veneer/commit/0930bda8d8c1e2115cd20264dc0b6b1da0cedb1a) Thanks [@joao-flores-de-leao](https://github.azc.ext.hp.com/joao-flores-de-leao)! - [Scrollbar] Update style to match a11y requirements.

- [#6943](https://github.azc.ext.hp.com/veneer/veneer/pull/6943) [`9f353af`](https://github.azc.ext.hp.com/veneer/veneer/commit/9f353af6b90bd2e13cc3364dfddc1ef2da890bbc) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [NotificationBadge] Add `count` to component.
  If count is provided, style will change and display the count.
  If no `children` is passed, the count will be displayed inline, otherwise it will be displayed as a floating badge.

  [NotificationCenter] Add `tabs` functionality.

  - You can pass any prop from `TabsInterface` to `tabs`
  - The application needs to control tabs state.

  [Tabs] Add `notificationCount` to tab data. Will display a `<NotificationBadge />` inline with label.

- [#6961](https://github.azc.ext.hp.com/veneer/veneer/pull/6961) [`d578284`](https://github.azc.ext.hp.com/veneer/veneer/commit/d57828456aeba1c86d52fd7b14ffad4bf5348446) Thanks [@pedro-soares](https://github.azc.ext.hp.com/pedro-soares)! - [Infra] Update @veneer/assets to 3.20 and @veneer/semantics to 3.13

  `stroke.default` is now `stroke.decorative.default`. Please update with your customizing it on `extendedSemantics()`.

- [#6980](https://github.azc.ext.hp.com/veneer/veneer/pull/6980) [`fabf984`](https://github.azc.ext.hp.com/veneer/veneer/commit/fabf984873e410caeee437ddf8cd2b468826c8d5) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [NotificationCenter] Add `topContentArea` which is rendered on the top of the content.

- [#6954](https://github.azc.ext.hp.com/veneer/veneer/pull/6954) [`d7e3d87`](https://github.azc.ext.hp.com/veneer/veneer/commit/d7e3d8726610cbbe6d36f47dcf2b28f2b6da1639) Thanks [@pedro-soares](https://github.azc.ext.hp.com/pedro-soares)! - [DatePicker] Fix onBlur missing behavior when change months

- [#6936](https://github.azc.ext.hp.com/veneer/veneer/pull/6936) [`f70bd5b`](https://github.azc.ext.hp.com/veneer/veneer/commit/f70bd5bc79086351e16dda588d375baa6a84f268) Thanks [@vinicius-silva](https://github.azc.ext.hp.com/vinicius-silva)! - [Table] add `singleSelection` option to `rowSelector` prop and deprecate `avatar`; Create new `rowAvatar` prop

- [#6959](https://github.azc.ext.hp.com/veneer/veneer/pull/6959) [`78d4247`](https://github.azc.ext.hp.com/veneer/veneer/commit/78d424799ae68556e92984862821d1fe5e946e71) Thanks [@tamires-silva](https://github.azc.ext.hp.com/tamires-silva)! - [Breadcrumbs] Add double focus ring
  [Checkbox] Add double focus ring
  [RadioButton] Add double focus ring
  [Toggle] Add double focus ring
  [Slider] Add double focus ring

- [#6946](https://github.azc.ext.hp.com/veneer/veneer/pull/6946) [`c846a5a`](https://github.azc.ext.hp.com/veneer/veneer/commit/c846a5a15dff9421317a5bb6ea95416aef02abd5) Thanks [@joao-flores-de-leao](https://github.azc.ext.hp.com/joao-flores-de-leao)! - [NotificationCenter]

  - New prop `bottomArea` to provide interactive content.
  - New descriptions on some props to illustrate their usages.
  - New Divider that clearly defines the boundaries of the clickable areas.

- [#6949](https://github.azc.ext.hp.com/veneer/veneer/pull/6949) [`47bbfac`](https://github.azc.ext.hp.com/veneer/veneer/commit/47bbfacd35ecce2355f1cae656e881efa9d45aa9) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [Table] Add `rowProps`. Useful to set your own props on `tr` tag. It only works for body rows.

### Patch Changes

- [#6918](https://github.azc.ext.hp.com/veneer/veneer/pull/6918) [`131ec74`](https://github.azc.ext.hp.com/veneer/veneer/commit/131ec744400baee3611e79753b8b95019bfebb3a) Thanks [@joao-flores-de-leao](https://github.azc.ext.hp.com/joao-flores-de-leao)! - [Select]

  - `wrap` property changed the default to ensure better responsiveness.
  - Focus ring style updated to match new design definitions.

- [#6944](https://github.azc.ext.hp.com/veneer/veneer/pull/6944) [`6cd18c0`](https://github.azc.ext.hp.com/veneer/veneer/commit/6cd18c006ef4a6f07ddc915de71d1dbdea28adc6) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [Checkbox] Prevents double click on input from selecting label.

- Updated dependencies [[`d578284`](https://github.azc.ext.hp.com/veneer/veneer/commit/d57828456aeba1c86d52fd7b14ffad4bf5348446)]:
  - @veneer/theme@3.88.0

## 3.111.0

### Minor Changes

- [#6350](https://github.azc.ext.hp.com/veneer/veneer/pull/6350) [`d89d31f`](https://github.azc.ext.hp.com/veneer/veneer/commit/d89d31f0dd76cc0ae9695f700742eeae66153f0b) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [NotificationBadge] Remove deprecated positions.
  [ContextualMenu] Remove deprecated `onMouseDown` and `useJsPositioning`.

- [#6908](https://github.azc.ext.hp.com/veneer/veneer/pull/6908) [`66c998d`](https://github.azc.ext.hp.com/veneer/veneer/commit/66c998d469980d12a6d14659ad20499de8f5e945) Thanks [@tamires-silva](https://github.azc.ext.hp.com/tamires-silva)! - [PasswordRequirements] Remove min-width and break long words

- [#6350](https://github.azc.ext.hp.com/veneer/veneer/pull/6350) [`d89d31f`](https://github.azc.ext.hp.com/veneer/veneer/commit/d89d31f0dd76cc0ae9695f700742eeae66153f0b) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [Tabs] Remove scrollLeftButton and scrollRightButton i18n.

- [#6915](https://github.azc.ext.hp.com/veneer/veneer/pull/6915) [`a091726`](https://github.azc.ext.hp.com/veneer/veneer/commit/a091726b09da8e2391a31bcf6f424192944f5059) Thanks [@vinicius-silva](https://github.azc.ext.hp.com/vinicius-silva)! - [ProgressIndicator] Update track color to Background Disabled

- [#6350](https://github.azc.ext.hp.com/veneer/veneer/pull/6350) [`d89d31f`](https://github.azc.ext.hp.com/veneer/veneer/commit/d89d31f0dd76cc0ae9695f700742eeae66153f0b) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [Header] Remove `leftArea` and `rightAtea`.

- [#6350](https://github.azc.ext.hp.com/veneer/veneer/pull/6350) [`d89d31f`](https://github.azc.ext.hp.com/veneer/veneer/commit/d89d31f0dd76cc0ae9695f700742eeae66153f0b) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [Footer] Remove `leftArea` and `rightArea`.

- [#6350](https://github.azc.ext.hp.com/veneer/veneer/pull/6350) [`d89d31f`](https://github.azc.ext.hp.com/veneer/veneer/commit/d89d31f0dd76cc0ae9695f700742eeae66153f0b) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [Modal] Remove left, right alignments.

- [#6914](https://github.azc.ext.hp.com/veneer/veneer/pull/6914) [`0d1efc5`](https://github.azc.ext.hp.com/veneer/veneer/commit/0d1efc5ce9e0af2e93d8f1eded56d582828acc6c) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [Table] Fix Skeleton loading, base row height and singlePage no items alignment.

- [#6350](https://github.azc.ext.hp.com/veneer/veneer/pull/6350) [`d89d31f`](https://github.azc.ext.hp.com/veneer/veneer/commit/d89d31f0dd76cc0ae9695f700742eeae66153f0b) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [Table] Remove onSelectAll.

- [#6350](https://github.azc.ext.hp.com/veneer/veneer/pull/6350) [`d89d31f`](https://github.azc.ext.hp.com/veneer/veneer/commit/d89d31f0dd76cc0ae9695f700742eeae66153f0b) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [SideBar] Remove left, right positions.

- [#6931](https://github.azc.ext.hp.com/veneer/veneer/pull/6931) [`f4967bf`](https://github.azc.ext.hp.com/veneer/veneer/commit/f4967bfa79820c2ff749aab24dc541fa7c007bba) Thanks [@pedro-soares](https://github.azc.ext.hp.com/pedro-soares)! - [InlineNotification] Fixed the alignment when there wasn't an actionButton

- [#6907](https://github.azc.ext.hp.com/veneer/veneer/pull/6907) [`3867b4e`](https://github.azc.ext.hp.com/veneer/veneer/commit/3867b4e7aed56ca7db80d598baab738c54a5c2e5) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [Typography] `useTheme` now provides all typography helpers.

- [#6350](https://github.azc.ext.hp.com/veneer/veneer/pull/6350) [`d89d31f`](https://github.azc.ext.hp.com/veneer/veneer/commit/d89d31f0dd76cc0ae9695f700742eeae66153f0b) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [Accordion] Remove `hoverable`.

  [Breadcrumbs] Remove `truncateText`.

  [AnchorMenu] Remove `left`, `right`.

- [#6350](https://github.azc.ext.hp.com/veneer/veneer/pull/6350) [`d89d31f`](https://github.azc.ext.hp.com/veneer/veneer/commit/d89d31f0dd76cc0ae9695f700742eeae66153f0b) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [TreeView] Remove `onCollapese` and `onExpand`.

- [#6350](https://github.azc.ext.hp.com/veneer/veneer/pull/6350) [`d89d31f`](https://github.azc.ext.hp.com/veneer/veneer/commit/d89d31f0dd76cc0ae9695f700742eeae66153f0b) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [List] Remove `leftArea` and `rightArea`.

- [#6350](https://github.azc.ext.hp.com/veneer/veneer/pull/6350) [`d89d31f`](https://github.azc.ext.hp.com/veneer/veneer/commit/d89d31f0dd76cc0ae9695f700742eeae66153f0b) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [SideMenu] Remove toggle, toggleImagePath and deprecated appearances.

### Patch Changes

- [#6909](https://github.azc.ext.hp.com/veneer/veneer/pull/6909) [`63cfb0a`](https://github.azc.ext.hp.com/veneer/veneer/commit/63cfb0ae67e7d29a035a64f5b5387a0f8da4a156) Thanks [@vinicius-silva](https://github.azc.ext.hp.com/vinicius-silva)! - [Table] Column reorder is saving not confirmed selection order

- [#6917](https://github.azc.ext.hp.com/veneer/veneer/pull/6917) [`372e06d`](https://github.azc.ext.hp.com/veneer/veneer/commit/372e06d8c79283608581008450f0669f1dfeaefc) Thanks [@vinicius-silva](https://github.azc.ext.hp.com/vinicius-silva)! - [Date Picker] On mobile and tablet, sometimes date picker is not opening properly

- [#6942](https://github.azc.ext.hp.com/veneer/veneer/pull/6942) [`78d44ae`](https://github.azc.ext.hp.com/veneer/veneer/commit/78d44aefbaf050bed5d3c95c2393cea42310534c) Thanks [@joao-flores-de-leao](https://github.azc.ext.hp.com/joao-flores-de-leao)! - [Select]
  - `wrap` property changed the default to ensure better responsiveness.
  - Focus ring style updated to match new design definitions.
- Updated dependencies [[`d89d31f`](https://github.azc.ext.hp.com/veneer/veneer/commit/d89d31f0dd76cc0ae9695f700742eeae66153f0b), [`3867b4e`](https://github.azc.ext.hp.com/veneer/veneer/commit/3867b4e7aed56ca7db80d598baab738c54a5c2e5), [`d89d31f`](https://github.azc.ext.hp.com/veneer/veneer/commit/d89d31f0dd76cc0ae9695f700742eeae66153f0b)]:
  - @veneer/theme@3.87.0

## 3.110.0

### Minor Changes

- [#6857](https://github.azc.ext.hp.com/veneer/veneer/pull/6857) [`baeb58a`](https://github.azc.ext.hp.com/veneer/veneer/commit/baeb58a2c0b87068cc54b8802198fdf56a82d03e) Thanks [@pedro-soares](https://github.azc.ext.hp.com/pedro-soares)! - [Search] Add portal and portalContainer props.

- [#6869](https://github.azc.ext.hp.com/veneer/veneer/pull/6869) [`33f8494`](https://github.azc.ext.hp.com/veneer/veneer/commit/33f8494cf0fb8b0cdd1e2ce53cee1bfd6a4f2cdb) Thanks [@tamires-silva](https://github.azc.ext.hp.com/tamires-silva)! - [A11y] Revamp focus ring for hyperlinks, AnchorMenu, Attached and Online Tabs.

- [#6761](https://github.azc.ext.hp.com/veneer/veneer/pull/6761) [`3102aab`](https://github.azc.ext.hp.com/veneer/veneer/commit/3102aab29e1e71fb7ef1512c406472c000d8207c) Thanks [@heyou-wang](https://github.azc.ext.hp.com/heyou-wang)! - [TextArea] Add new props:

  - `autoResize`: Auto resize Text Area height when true.
  - `maxHeight`: Set the maximum height for automatic growth.
  - `onHeightChange`: Sets the callback fired when the height changes automatically.

- [#6860](https://github.azc.ext.hp.com/veneer/veneer/pull/6860) [`200772f`](https://github.azc.ext.hp.com/veneer/veneer/commit/200772f3cb7a2973f4cca40e199f58727b3808c1) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [ThemeProvider] Remove `inputBackground`. Our design team opted to have all forms controls with withe background as default. Please stop using this prop since it wont work and theres no way to set transparent. We recommend you stick with white background.

- [#6884](https://github.azc.ext.hp.com/veneer/veneer/pull/6884) [`4297251`](https://github.azc.ext.hp.com/veneer/veneer/commit/429725102342eda058cb85e681fbc5c81be04738) Thanks [@anderson-freitas](https://github.azc.ext.hp.com/anderson-freitas)! - [AnchorMenu] Set default item when AnchorMenu is loaded

- [#6865](https://github.azc.ext.hp.com/veneer/veneer/pull/6865) [`b1adfef`](https://github.azc.ext.hp.com/veneer/veneer/commit/b1adfef3c099302bc03cb932d0872dbf8083210f) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [Tooltip] Add `maxWidth`

- [#6883](https://github.azc.ext.hp.com/veneer/veneer/pull/6883) [`fab214a`](https://github.azc.ext.hp.com/veneer/veneer/commit/fab214adc6ce389dbc1fc4c20f13086665675e3b) Thanks [@anderson-freitas](https://github.azc.ext.hp.com/anderson-freitas)! - [TextArea] Update padding to be applied to the textArea

- [#6897](https://github.azc.ext.hp.com/veneer/veneer/pull/6897) [`374b5f9`](https://github.azc.ext.hp.com/veneer/veneer/commit/374b5f9f765f0b64685b66b8597fc579a443dd8b) Thanks [@walter-ferreira](https://github.azc.ext.hp.com/walter-ferreira)! - [Infra] Update @veneer/assets to 3.19

- [#6855](https://github.azc.ext.hp.com/veneer/veneer/pull/6855) [`8bb321b`](https://github.azc.ext.hp.com/veneer/veneer/commit/8bb321b4a4e8d2304917754cc806055dd0e9a21c) Thanks [@pedro-soares](https://github.azc.ext.hp.com/pedro-soares)! - [Table] Align center the message and icons when there isn't itens to show

- [#6822](https://github.azc.ext.hp.com/veneer/veneer/pull/6822) [`b7675be`](https://github.azc.ext.hp.com/veneer/veneer/commit/b7675bef1e6422dd29ac84479379d968af784059) Thanks [@tamires-silva](https://github.azc.ext.hp.com/tamires-silva)! - [InlineNotification] Add accessibility props: `aria-label` , `aria-labelledby`, `aria-describedby`

- [#6866](https://github.azc.ext.hp.com/veneer/veneer/pull/6866) [`1b694c8`](https://github.azc.ext.hp.com/veneer/veneer/commit/1b694c8885ac1480b7d944bf74d8e43eb7a7db04) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [Button] Remove `pointerEvents: none` from label and icon

- [#6843](https://github.azc.ext.hp.com/veneer/veneer/pull/6843) [`89f0a85`](https://github.azc.ext.hp.com/veneer/veneer/commit/89f0a8582b36bcec211c684529fe9e09fef0412e) Thanks [@joao-flores-de-leao](https://github.azc.ext.hp.com/joao-flores-de-leao)! - [Tag]

  - Add a default i18n `clear` property.
  - Updated the the instances of close to clear for consistency.
  - `clearButton` changed to boolean.

- [#6863](https://github.azc.ext.hp.com/veneer/veneer/pull/6863) [`35d24d9`](https://github.azc.ext.hp.com/veneer/veneer/commit/35d24d99610a49821390c0af4ff3955dc9af7503) Thanks [@walter-ferreira](https://github.azc.ext.hp.com/walter-ferreira)! - [Toggle] Redesign colors.

- [#6856](https://github.azc.ext.hp.com/veneer/veneer/pull/6856) [`fd8f720`](https://github.azc.ext.hp.com/veneer/veneer/commit/fd8f72019384c4fd539b6c80e01e5f0e24807800) Thanks [@anderson-freitas](https://github.azc.ext.hp.com/anderson-freitas)! - [Select] Add behavior to not close popover on scroll/zoom when is a device mobile and search is true

- [#6874](https://github.azc.ext.hp.com/veneer/veneer/pull/6874) [`c102084`](https://github.azc.ext.hp.com/veneer/veneer/commit/c102084ee761cb8a53118cfe09efad8538993fe3) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [Search] Add `onSearchButtonClick` that fires when search button is clicked.

- [#6885](https://github.azc.ext.hp.com/veneer/veneer/pull/6885) [`0f4596f`](https://github.azc.ext.hp.com/veneer/veneer/commit/0f4596f71181198779a86a256497beec1799becb) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [Select] Update hover and active option colors.

### Patch Changes

- Updated dependencies [[`200772f`](https://github.azc.ext.hp.com/veneer/veneer/commit/200772f3cb7a2973f4cca40e199f58727b3808c1)]:
  - @veneer/theme@3.86.0

## 3.109.0

### Minor Changes

- [#6817](https://github.azc.ext.hp.com/veneer/veneer/pull/6817) [`c0b0fb3`](https://github.azc.ext.hp.com/veneer/veneer/commit/c0b0fb355cee852da4f4440c1ee6982aa5e2e67a) Thanks [@anderson-freitas](https://github.azc.ext.hp.com/anderson-freitas)! - [AnimatedHeight]: Fixed the findDOMNode deprecated warning from Accordion, SideMenu and TreeView.

- [#6757](https://github.azc.ext.hp.com/veneer/veneer/pull/6757) [`fef5300`](https://github.azc.ext.hp.com/veneer/veneer/commit/fef5300be118f08556f3c6908068da3fb722df23) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [Stepper] Add `indicator` appearance. Update following styles for status:

  - Complete: Updated title color for default, hover and active states.
  - Current: Add filled background and outer outline.
  - Incomplete: Add background-color for default.
  - Disabled: Removed children and updated border and background-color.

  If you are using `indicator` appearance, please use complete/incomplete steps to go over it.

- [#6844](https://github.azc.ext.hp.com/veneer/veneer/pull/6844) [`2e352ca`](https://github.azc.ext.hp.com/veneer/veneer/commit/2e352ca6720d300c8a946284ffb556e5fd8f56cf) Thanks [@walter-ferreira](https://github.azc.ext.hp.com/walter-ferreira)! - [Infra] Update @veneer/assets to 3.18

- [#6800](https://github.azc.ext.hp.com/veneer/veneer/pull/6800) [`f5549e8`](https://github.azc.ext.hp.com/veneer/veneer/commit/f5549e86a9084631f2459191d6c4b0f20079bf62) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [Accordion] Update header divider and fix several issues on accordion styles.

- [#6810](https://github.azc.ext.hp.com/veneer/veneer/pull/6810) [`d9ed94b`](https://github.azc.ext.hp.com/veneer/veneer/commit/d9ed94bbfa07e7fbf21be631aa7d872acec93142) Thanks [@pedro-soares](https://github.azc.ext.hp.com/pedro-soares)! - [Tag] Changed the label type to ReactNode instead of string.

- [#6794](https://github.azc.ext.hp.com/veneer/veneer/pull/6794) [`3025276`](https://github.azc.ext.hp.com/veneer/veneer/commit/30252766fba21406d34e59f42b61a99bdc6aa28d) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [CustomImage] Add `content` to support lottie files or any other content wanted.

- [#6801](https://github.azc.ext.hp.com/veneer/veneer/pull/6801) [`746ef2b`](https://github.azc.ext.hp.com/veneer/veneer/commit/746ef2b30e4866041c7a4171239893cdccee8fd3) Thanks [@anderson-freitas](https://github.azc.ext.hp.com/anderson-freitas)! - [Select] Fix focus ring when an option is selected.

- [#6795](https://github.azc.ext.hp.com/veneer/veneer/pull/6795) [`8183aba`](https://github.azc.ext.hp.com/veneer/veneer/commit/8183aba224138b0a13b2c51375a9d5e7a912c30b) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [Modal] Add `header`.

- [#6792](https://github.azc.ext.hp.com/veneer/veneer/pull/6792) [`ced9689`](https://github.azc.ext.hp.com/veneer/veneer/commit/ced96892641511026228fb98d56cc76cde736279) Thanks [@anderson-freitas](https://github.azc.ext.hp.com/anderson-freitas)! - [Button] Update background-color when appearance ghost and active

## 3.108.0

### Minor Changes

- [#6768](https://github.azc.ext.hp.com/veneer/veneer/pull/6768) [`e7d0f5a`](https://github.azc.ext.hp.com/veneer/veneer/commit/e7d0f5a79694ca88b332d66a6f50fdf4c184cc81) Thanks [@tamires-silva](https://github.azc.ext.hp.com/tamires-silva)! - [Button][ContextualMenu][Tabs] Double focus ring added to improve accessibility in conformance to WCAG 2.1 AA.

- [#6754](https://github.azc.ext.hp.com/veneer/veneer/pull/6754) [`f2bcc26`](https://github.azc.ext.hp.com/veneer/veneer/commit/f2bcc2630714c575f04c5c5737e7736fbe9ab172) Thanks [@anderson-freitas](https://github.azc.ext.hp.com/anderson-freitas)! - [SegmentedControl] Add `block` property. Will make the child items adjust to the parent width, leaving them all the same width.

- [#6755](https://github.azc.ext.hp.com/veneer/veneer/pull/6755) [`237fde9`](https://github.azc.ext.hp.com/veneer/veneer/commit/237fde990089c67c4f8fe09d4e21258a87e81086) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [Stepper] Add `size`, `description` props. This is a partial release only on development side, design is still working on it. So please be aware of possible changes.

- [#6708](https://github.azc.ext.hp.com/veneer/veneer/pull/6708) [`06e3109`](https://github.azc.ext.hp.com/veneer/veneer/commit/06e31098914a1d8c81d28bfb815bbec6cfaa52e6) Thanks [@joao-flores-de-leao](https://github.azc.ext.hp.com/joao-flores-de-leao)! - [Hyperlink] Update on colors to match contrast guidelines of WCAG 2.1 AA.

- [#6759](https://github.azc.ext.hp.com/veneer/veneer/pull/6759) [`20e1aec`](https://github.azc.ext.hp.com/veneer/veneer/commit/20e1aec2ed38d20e74894f7824c4894e1f25e46a) Thanks [@walter-ferreira](https://github.azc.ext.hp.com/walter-ferreira)! - [Typography] Added new classes for `body-regular`, `label-regular` and `caption-regular`.

- [#6751](https://github.azc.ext.hp.com/veneer/veneer/pull/6751) [`e8935b8`](https://github.azc.ext.hp.com/veneer/veneer/commit/e8935b8ac2f5b58e1bc858147f06668f3fdaa5d3) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [ProgressIndicator] Add sizing controls to circular variant and an option to display label inside the circular indicator.

- [#6769](https://github.azc.ext.hp.com/veneer/veneer/pull/6769) [`e4320cd`](https://github.azc.ext.hp.com/veneer/veneer/commit/e4320cd176b8fd67d32f0a892bd993bf5044dd52) Thanks [@anderson-freitas](https://github.azc.ext.hp.com/anderson-freitas)! - [NotificationCenter] Add customClass property in the notificationCenter component to allow add custom style to the NotificationCenter

- [#6766](https://github.azc.ext.hp.com/veneer/veneer/pull/6766) [`ee7c90b`](https://github.azc.ext.hp.com/veneer/veneer/commit/ee7c90b05efef820d3de82a5db6895184bfc523b) Thanks [@pedro-soares](https://github.azc.ext.hp.com/pedro-soares)! - [InlineNotification]

  - A new variant to the InlineNotification `type` called `custom` was added that allows the user to customize the component.
  - A new property called `icon` was added that allows the user to use a custom icon.
  - A new property called `actionPlacement` was added to change the placement of the action button. The two possible placements are `bottom-start` and `top`.
  - Added a new property called `date` that should receive a string containing the date.
  - Style changes

- [#6782](https://github.azc.ext.hp.com/veneer/veneer/pull/6782) [`b7d6a32`](https://github.azc.ext.hp.com/veneer/veneer/commit/b7d6a32d001aa9e2d3a53da2b185801ef7c3ad3c) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [SideMenuItem] Add `onToggle`.

- [#6786](https://github.azc.ext.hp.com/veneer/veneer/pull/6786) [`6f36500`](https://github.azc.ext.hp.com/veneer/veneer/commit/6f36500ebe55a9e32eb8da64cb95699807e4e87c) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [Infra] Update @veneer/assets to 3.17 and @veneer/semantics to 3.12

### Patch Changes

- [#6742](https://github.azc.ext.hp.com/veneer/veneer/pull/6742) [`950544c`](https://github.azc.ext.hp.com/veneer/veneer/commit/950544cf2a7dbce1f88b8a18b2e3016703599ce4) Thanks [@anderson-freitas](https://github.azc.ext.hp.com/anderson-freitas)! - [InlineNotification][ToastNotification] Update warning icon color

- Updated dependencies [[`20e1aec`](https://github.azc.ext.hp.com/veneer/veneer/commit/20e1aec2ed38d20e74894f7824c4894e1f25e46a), [`6f36500`](https://github.azc.ext.hp.com/veneer/veneer/commit/6f36500ebe55a9e32eb8da64cb95699807e4e87c)]:
  - @veneer/styles@3.64.0
  - @veneer/theme@3.85.0

## 3.107.0

### Minor Changes

- [#6719](https://github.azc.ext.hp.com/veneer/veneer/pull/6719) [`775f452`](https://github.azc.ext.hp.com/veneer/veneer/commit/775f452b0fc5d1073d6ad8f940b85f4b266c1aa5) Thanks [@anderson-freitas](https://github.azc.ext.hp.com/anderson-freitas)! - [Avatar] Add size 32 on Avatar

- [#6732](https://github.azc.ext.hp.com/veneer/veneer/pull/6732) [`33a9147`](https://github.azc.ext.hp.com/veneer/veneer/commit/33a914752f8683ae4065380d1622a23def3e94e4) Thanks [@anderson-freitas](https://github.azc.ext.hp.com/anderson-freitas)! - [Logos] Add Hp Progress Mark, HyperX, ZByHp, Forest First, Poly (Poly Logomark) logos

- [#6726](https://github.azc.ext.hp.com/veneer/veneer/pull/6726) [`0b1f404`](https://github.azc.ext.hp.com/veneer/veneer/commit/0b1f404ba9b3ecf4118501f57bc168dd7f0c2633) Thanks [@pedro-soares](https://github.azc.ext.hp.com/pedro-soares)! - [DatePicker] Add onFocus and onBlur event handlers to the DatePicker component interface

- [#6713](https://github.azc.ext.hp.com/veneer/veneer/pull/6713) [`7271a60`](https://github.azc.ext.hp.com/veneer/veneer/commit/7271a604edd8fd6acc0fd2e718885a5d6c320d06) Thanks [@tamires-silva](https://github.azc.ext.hp.com/tamires-silva)! - [Input] Add Background Filled option for hover and pressed states
  [FormControl] Add Background Filled option for hover and pressed states

- [#6722](https://github.azc.ext.hp.com/veneer/veneer/pull/6722) [`35b0c28`](https://github.azc.ext.hp.com/veneer/veneer/commit/35b0c28fd67d1688130661a60b4d92fac0014bd5) Thanks [@pedro-soares](https://github.azc.ext.hp.com/pedro-soares)! - [Select] Add onFocus and onBlur event handlers to the Select component interface

- [#6739](https://github.azc.ext.hp.com/veneer/veneer/pull/6739) [`7fd2719`](https://github.azc.ext.hp.com/veneer/veneer/commit/7fd27194e649cf25a0ad37de4f249a462c737bb5) Thanks [@pedro-soares](https://github.azc.ext.hp.com/pedro-soares)! - [Foundation] Update @veneer/assets to 3.16.0 and update @veneer/semantics to 3.11.0

### Patch Changes

- [#6720](https://github.azc.ext.hp.com/veneer/veneer/pull/6720) [`cb61939`](https://github.azc.ext.hp.com/veneer/veneer/commit/cb61939567bb052cd81b5b5d004963f89ac8ff11) Thanks [@anderson-freitas](https://github.azc.ext.hp.com/anderson-freitas)! - [ContextualMenu] Define `strategy` as `fixed` to make it work as SideMenu item.

- Updated dependencies [[`33a9147`](https://github.azc.ext.hp.com/veneer/veneer/commit/33a914752f8683ae4065380d1622a23def3e94e4), [`7fd2719`](https://github.azc.ext.hp.com/veneer/veneer/commit/7fd27194e649cf25a0ad37de4f249a462c737bb5)]:
  - @veneer/logos@3.4.0
  - @veneer/theme@3.84.0

## 3.106.0

### Minor Changes

- [#6691](https://github.azc.ext.hp.com/veneer/veneer/pull/6691) [`0b6ec20`](https://github.azc.ext.hp.com/veneer/veneer/commit/0b6ec20f57af4ff30150c60c1872a213bcdc66bd) Thanks [@walter-ferreira](https://github.azc.ext.hp.com/walter-ferreira)! - [SideMenu] New UI for SideMenu Parent Item with Children Elements and onClick callback

- [#6682](https://github.azc.ext.hp.com/veneer/veneer/pull/6682) [`825a58e`](https://github.azc.ext.hp.com/veneer/veneer/commit/825a58e7b299829f0b2013af65ec428ca4aa1182) Thanks [@pedro-soares](https://github.azc.ext.hp.com/pedro-soares)! - [NotificationCenter]

  - [x] Adjusted the component with the new design definitions.

- [#6721](https://github.azc.ext.hp.com/veneer/veneer/pull/6721) [`25b3c94`](https://github.azc.ext.hp.com/veneer/veneer/commit/25b3c94f58fa967bdc4af57c01d6733f37bf1bf9) Thanks [@anderson-freitas](https://github.azc.ext.hp.com/anderson-freitas)! - [Avatar] Add size 32 on Avatar

- [#6664](https://github.azc.ext.hp.com/veneer/veneer/pull/6664) [`745dc3e`](https://github.azc.ext.hp.com/veneer/veneer/commit/745dc3e83204128ded82fd0e7f70f864cdc235f6) Thanks [@pedro-soares](https://github.azc.ext.hp.com/pedro-soares)! - [Breadcrumbs] Increasing the component size to fit the whole container

- [#6669](https://github.azc.ext.hp.com/veneer/veneer/pull/6669) [`b4b59b4`](https://github.azc.ext.hp.com/veneer/veneer/commit/b4b59b4b1de75f5725e9ee35ac5160d8366bf1ab) Thanks [@anderson-freitas](https://github.azc.ext.hp.com/anderson-freitas)! - [Select] Update padding when input has no label
  [Search] Update padding when input has no label
  [TextBox] Update padding when input has no label
  [TextArea] Update padding when input has no label

- [#6690](https://github.azc.ext.hp.com/veneer/veneer/pull/6690) [`648c69b`](https://github.azc.ext.hp.com/veneer/veneer/commit/648c69bf1c9246ddbea4835439b17208740683bf) Thanks [@anderson-freitas](https://github.azc.ext.hp.com/anderson-freitas)! - [Foundation] Update @veneer/assets to 3.15.0 and update @veneer/semantics to 3.10.0

### Patch Changes

- Updated dependencies [[`648c69b`](https://github.azc.ext.hp.com/veneer/veneer/commit/648c69bf1c9246ddbea4835439b17208740683bf)]:
  - @veneer/theme@3.83.0

## 3.105.0

### Minor Changes

- [`88d6465`](https://github.azc.ext.hp.com/veneer/veneer/commit/88d64655c51745115eb75ce9322f934ddfaf5d60) Thanks [@pedro-soares](https://github.azc.ext.hp.com/pedro-soares)! - Removing deprecated React methods to avoid warnings.

- [`b3c50ff`](https://github.azc.ext.hp.com/veneer/veneer/commit/b3c50ff33457f91d36f44e4ef89660806f30d116) Thanks [@pedro-soares](https://github.azc.ext.hp.com/pedro-soares)! - [SegmentedControl]

  - [x] Add `noWrap`. When it's ´true´ segmented control item text that overflows will have ellipsis, otherwise the text is going to break line to fit its whole content.
  - [x] Deprecate `responsiveBreakpoint` property.

- [`9ee153f`](https://github.azc.ext.hp.com/veneer/veneer/commit/9ee153fcdc13f03e341205c556fb24e157583aef) Thanks [@walter-ferreira](https://github.azc.ext.hp.com/walter-ferreira)! - [Foundation] Update @veneer/assets to 3.14.0, update @veneer/primitives to 3.63.0 and update @veneer/semantics to 3.9.0

- [`3d111ce`](https://github.azc.ext.hp.com/veneer/veneer/commit/3d111cee401ef00fe94231cf8768eab4760025fc) Thanks [@pedro-soares](https://github.azc.ext.hp.com/pedro-soares)! - [DatePicker] Fix the separateLabel jumping on RTL focus

- [`543af65`](https://github.azc.ext.hp.com/veneer/veneer/commit/543af6513246ddc4c757a1bf80e1c88ce1743d1a) Thanks [@walter-ferreira](https://github.azc.ext.hp.com/walter-ferreira)! - [Menu Item] Removed the visual cue when in Pill shape and High Contrast mode

- [`ccddc0a`](https://github.azc.ext.hp.com/veneer/veneer/commit/ccddc0a00cefd2f39e6ca8279ffcf3b995ea3dbd) Thanks [@anderson-freitas](https://github.azc.ext.hp.com/anderson-freitas)! - [TextArea] Add min-height on textArea to improve the responsiveness.

- [`7a66aea`](https://github.azc.ext.hp.com/veneer/veneer/commit/7a66aea877a9e7e1759990f5e2a25b5e47d475d7) Thanks [@walter-ferreira](https://github.azc.ext.hp.com/walter-ferreira)! - [DatePicker] Fixed endDate visibility on hover and active states.

- [`e459fa2`](https://github.azc.ext.hp.com/veneer/veneer/commit/e459fa22d20ca3b0aa297127981e5aad344cd2e8) Thanks [@walter-ferreira](https://github.azc.ext.hp.com/walter-ferreira)! - [Coackmark] Removed Portal from component to fix RTL exibition

- [`76ad29d`](https://github.azc.ext.hp.com/veneer/veneer/commit/76ad29d608f34963dcb89aaad369ccd3d808daa8) Thanks [@anderson-freitas](https://github.azc.ext.hp.com/anderson-freitas)! - [InlineNotification] Set vertical alignment to top of the icon and close button.

### Patch Changes

- Updated dependencies [[`88d6465`](https://github.azc.ext.hp.com/veneer/veneer/commit/88d64655c51745115eb75ce9322f934ddfaf5d60), [`9ee153f`](https://github.azc.ext.hp.com/veneer/veneer/commit/9ee153fcdc13f03e341205c556fb24e157583aef)]:
  - @veneer/theme@3.82.0
  - @veneer/styles@3.63.0

## 3.104.0

### Minor Changes

- [#6558](https://github.azc.ext.hp.com/veneer/veneer/pull/6558) [`3762723`](https://github.azc.ext.hp.com/veneer/veneer/commit/3762723f840ea58d7ca8c26c96684e3c185452c2) Thanks [@anderson-freitas](https://github.azc.ext.hp.com/anderson-freitas)! - [ContextualMenu] Add behavior to close popover with the menu options when page is scrolled or zoom changed

- [#6598](https://github.azc.ext.hp.com/veneer/veneer/pull/6598) [`818db74`](https://github.azc.ext.hp.com/veneer/veneer/commit/818db74ae3486ffe550c5d40c45d621906d6d027) Thanks [@anderson-freitas](https://github.azc.ext.hp.com/anderson-freitas)! - [Foundation] Update @veneer/assets to 3.13.0, update @veneer/primitives to 3.62.0 and update @veneer/semantics to 3.8.0

- [#6578](https://github.azc.ext.hp.com/veneer/veneer/pull/6578) [`dcf6c87`](https://github.azc.ext.hp.com/veneer/veneer/commit/dcf6c87c790578923ee8632bb8ec92e4ce7e2faf) Thanks [@anderson-freitas](https://github.azc.ext.hp.com/anderson-freitas)! - [ContextualMenu] Add text wrap to menu item

- [#6385](https://github.azc.ext.hp.com/veneer/veneer/pull/6385) [`de59845`](https://github.azc.ext.hp.com/veneer/veneer/commit/de5984549f222f2c58cdfcbdb68f20be34aae4e7) Thanks [@joao-flores-de-leao](https://github.azc.ext.hp.com/joao-flores-de-leao)! - [Breadcrumbs]

  - [x] Added a contextual menu to display previous accessed pages.
  - [x] Replaced aria attributes overrides in favor of native HTML accessibility.
  - [x] Improved style of the component to match new features.

- [#6587](https://github.azc.ext.hp.com/veneer/veneer/pull/6587) [`3dde97b`](https://github.azc.ext.hp.com/veneer/veneer/commit/3dde97bbcaeaff0727c1002ab863c7489a869fe4) Thanks [@anderson-freitas](https://github.azc.ext.hp.com/anderson-freitas)! - [Select] Fix to call scrollEnd event when zoom is other than 100%

- [#6602](https://github.azc.ext.hp.com/veneer/veneer/pull/6602) [`41b4d70`](https://github.azc.ext.hp.com/veneer/veneer/commit/41b4d70691d7963bb5368ecd90f9cd99b1446b7f) Thanks [@anderson-freitas](https://github.azc.ext.hp.com/anderson-freitas)! - [Menu Item] Removed the visual cue when in Pill shape and High Contrast mode

- [#6558](https://github.azc.ext.hp.com/veneer/veneer/pull/6558) [`3762723`](https://github.azc.ext.hp.com/veneer/veneer/commit/3762723f840ea58d7ca8c26c96684e3c185452c2) Thanks [@anderson-freitas](https://github.azc.ext.hp.com/anderson-freitas)! - [DatePicker] Add behavior to close popover with the calendar when page is scrolled or zoom changed

- [#6558](https://github.azc.ext.hp.com/veneer/veneer/pull/6558) [`3762723`](https://github.azc.ext.hp.com/veneer/veneer/commit/3762723f840ea58d7ca8c26c96684e3c185452c2) Thanks [@anderson-freitas](https://github.azc.ext.hp.com/anderson-freitas)! - [Search] Add behavior to close popover with the result search when page is scrolled or zoom changed

- [#6558](https://github.azc.ext.hp.com/veneer/veneer/pull/6558) [`3762723`](https://github.azc.ext.hp.com/veneer/veneer/commit/3762723f840ea58d7ca8c26c96684e3c185452c2) Thanks [@anderson-freitas](https://github.azc.ext.hp.com/anderson-freitas)! - [NotificationCenter] Add behavior to close popover when page is scrolled or zoom changed

- [#6597](https://github.azc.ext.hp.com/veneer/veneer/pull/6597) [`ca9c6ee`](https://github.azc.ext.hp.com/veneer/veneer/commit/ca9c6ee0b9cb6060d2e4e8cd391523f47fb853ed) Thanks [@walter-ferreira](https://github.azc.ext.hp.com/walter-ferreira)! - [Select] Fixed an issue that was preventing the Select Popover to be dismissed in a Modal

- [#6579](https://github.azc.ext.hp.com/veneer/veneer/pull/6579) [`213b711`](https://github.azc.ext.hp.com/veneer/veneer/commit/213b7116e1c325cfd0426f5c654441c79c6f8935) Thanks [@joao-flores-de-leao](https://github.azc.ext.hp.com/joao-flores-de-leao)! - [A11y] Focus ring style updated to avoid overrides and animations.

- [#6558](https://github.azc.ext.hp.com/veneer/veneer/pull/6558) [`3762723`](https://github.azc.ext.hp.com/veneer/veneer/commit/3762723f840ea58d7ca8c26c96684e3c185452c2) Thanks [@anderson-freitas](https://github.azc.ext.hp.com/anderson-freitas)! - [Select] Add behavior to close popover with the options when page is scrolled or zoom changed

- [#6558](https://github.azc.ext.hp.com/veneer/veneer/pull/6558) [`3762723`](https://github.azc.ext.hp.com/veneer/veneer/commit/3762723f840ea58d7ca8c26c96684e3c185452c2) Thanks [@anderson-freitas](https://github.azc.ext.hp.com/anderson-freitas)! - [Tooltip] Add behavior to close tooltip when page is scrolled or zoom changed

- [#6558](https://github.azc.ext.hp.com/veneer/veneer/pull/6558) [`3762723`](https://github.azc.ext.hp.com/veneer/veneer/commit/3762723f840ea58d7ca8c26c96684e3c185452c2) Thanks [@anderson-freitas](https://github.azc.ext.hp.com/anderson-freitas)! - [Password] Add behavior to close popover with the requirements when page is scrolled or zoom changed

- [#6581](https://github.azc.ext.hp.com/veneer/veneer/pull/6581) [`34b5e9f`](https://github.azc.ext.hp.com/veneer/veneer/commit/34b5e9fa9feda928c59efa389b26b0321f578738) Thanks [@pedro-soares](https://github.azc.ext.hp.com/pedro-soares)! - [Select] A new 'wrap' property was added that wraps the select popover items when they are bigger than the select input width.

### Patch Changes

- Updated dependencies [[`818db74`](https://github.azc.ext.hp.com/veneer/veneer/commit/818db74ae3486ffe550c5d40c45d621906d6d027)]:
  - @veneer/styles@3.62.0
  - @veneer/theme@3.81.0

## 3.103.0

### Minor Changes

- [#6428](https://github.azc.ext.hp.com/veneer/veneer/pull/6428) [`e4e18c1`](https://github.azc.ext.hp.com/veneer/veneer/commit/e4e18c1585abcced192570ada1584d24569ba566) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - [DatePicker] Switch to floating-ui.

- [#6508](https://github.azc.ext.hp.com/veneer/veneer/pull/6508) [`e85862d`](https://github.azc.ext.hp.com/veneer/veneer/commit/e85862d50cd3671098af0907c8258cbc3d908c0d) Thanks [@anderson-freitas](https://github.azc.ext.hp.com/anderson-freitas)! - [Foundation] Update @veneer/assets to 3.11.0

- [#6428](https://github.azc.ext.hp.com/veneer/veneer/pull/6428) [`e4e18c1`](https://github.azc.ext.hp.com/veneer/veneer/commit/e4e18c1585abcced192570ada1584d24569ba566) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - [Password] Switch to floating-ui

- [#6548](https://github.azc.ext.hp.com/veneer/veneer/pull/6548) [`4fb1a74`](https://github.azc.ext.hp.com/veneer/veneer/commit/4fb1a745f7c2438534f34cd9931dfc285a1834ba) Thanks [@anderson-freitas](https://github.azc.ext.hp.com/anderson-freitas)! - [Foundation] Update @veneer/assets to 3.12.0

- [#6428](https://github.azc.ext.hp.com/veneer/veneer/pull/6428) [`e4e18c1`](https://github.azc.ext.hp.com/veneer/veneer/commit/e4e18c1585abcced192570ada1584d24569ba566) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - [Popover] Remove popper.js as a dependency

- [#6428](https://github.azc.ext.hp.com/veneer/veneer/pull/6428) [`e4e18c1`](https://github.azc.ext.hp.com/veneer/veneer/commit/e4e18c1585abcced192570ada1584d24569ba566) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - [Coachmark] Switch to floating-ui.

- [#6521](https://github.azc.ext.hp.com/veneer/veneer/pull/6521) [`fee4c92`](https://github.azc.ext.hp.com/veneer/veneer/commit/fee4c924c997ae16636dafb7a141955aa59c1a0d) Thanks [@thallen-galvo](https://github.azc.ext.hp.com/thallen-galvo)! - [Select] Fixed text color when Select is disabled

- [#6428](https://github.azc.ext.hp.com/veneer/veneer/pull/6428) [`e4e18c1`](https://github.azc.ext.hp.com/veneer/veneer/commit/e4e18c1585abcced192570ada1584d24569ba566) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - [Tooltip] Convert to floating-ui

- [#6516](https://github.azc.ext.hp.com/veneer/veneer/pull/6516) [`cbab306`](https://github.azc.ext.hp.com/veneer/veneer/commit/cbab306a726ed366f7928dd15161cd465dd45118) Thanks [@thallen-galvo](https://github.azc.ext.hp.com/thallen-galvo)! - [Table] Fixed page scroll when configuring the column order

- [#6428](https://github.azc.ext.hp.com/veneer/veneer/pull/6428) [`e4e18c1`](https://github.azc.ext.hp.com/veneer/veneer/commit/e4e18c1585abcced192570ada1584d24569ba566) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - [Search] Switch to floating-ui.

- [#6428](https://github.azc.ext.hp.com/veneer/veneer/pull/6428) [`e4e18c1`](https://github.azc.ext.hp.com/veneer/veneer/commit/e4e18c1585abcced192570ada1584d24569ba566) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - [ContextualMenu] Switch to floating-ui.

  - The popperModifiers property has been deprecated and replaced by the floatingMiddleware property. To migrate your current implementation of the popperModifiers property to floatingMiddleware, see the floating interface documentation (https://floating-ui.com/docs/middleware).

- [#6428](https://github.azc.ext.hp.com/veneer/veneer/pull/6428) [`e4e18c1`](https://github.azc.ext.hp.com/veneer/veneer/commit/e4e18c1585abcced192570ada1584d24569ba566) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - [Select] switch to floating-ui

- [#6428](https://github.azc.ext.hp.com/veneer/veneer/pull/6428) [`e4e18c1`](https://github.azc.ext.hp.com/veneer/veneer/commit/e4e18c1585abcced192570ada1584d24569ba566) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - [NotificationCenter] Switch to floating-ui.

- [#6428](https://github.azc.ext.hp.com/veneer/veneer/pull/6428) [`e4e18c1`](https://github.azc.ext.hp.com/veneer/veneer/commit/e4e18c1585abcced192570ada1584d24569ba566) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - [Popover] Remove deprecated placements

  Directional placements (`left` and `right`) have been removed in favour of RTL-aware logical placements (`leading` and `trailing`)

### Patch Changes

- [#6428](https://github.azc.ext.hp.com/veneer/veneer/pull/6428) [`e4e18c1`](https://github.azc.ext.hp.com/veneer/veneer/commit/e4e18c1585abcced192570ada1584d24569ba566) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - [Dependencies] Remove @reach/auto-id

## 3.102.0

### Minor Changes

- [#6513](https://github.azc.ext.hp.com/veneer/veneer/pull/6513) [`e39462a`](https://github.azc.ext.hp.com/veneer/veneer/commit/e39462a9ac0f852592507e453d4550afbcbc2723) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - [Foundation] Update @veneer/assets to 3.11.0

- [#6443](https://github.azc.ext.hp.com/veneer/veneer/pull/6443) [`50ede93`](https://github.azc.ext.hp.com/veneer/veneer/commit/50ede93295b039e82bba3b340a2c398479537328) Thanks [@tamires-silva](https://github.azc.ext.hp.com/tamires-silva)! - [Input] Update min width from helper text and update behavior for long words.

- [#6351](https://github.azc.ext.hp.com/veneer/veneer/pull/6351) [`9d3f6bb`](https://github.azc.ext.hp.com/veneer/veneer/commit/9d3f6bbf41fab524e442d5612a939788c2e7312c) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - [Button] Remove deprecated appearances

- [#6348](https://github.azc.ext.hp.com/veneer/veneer/pull/6348) [`b21b152`](https://github.azc.ext.hp.com/veneer/veneer/commit/b21b152f697ed17c5dd11ebb44c74dd75c82d02c) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [InlineNotification] Action Button now will be displayed always at the bottom of the component. Also fixed alignments issues.

- [#6470](https://github.azc.ext.hp.com/veneer/veneer/pull/6470) [`5bda84a`](https://github.azc.ext.hp.com/veneer/veneer/commit/5bda84a27b78b82195a02566f9b94323f4ab995f) Thanks [@tamires-silva](https://github.azc.ext.hp.com/tamires-silva)! - [Input] Add tooltip to truncated label and add noTruncate property that allows the label not to be truncated in input components

- [#6458](https://github.azc.ext.hp.com/veneer/veneer/pull/6458) [`79bf91a`](https://github.azc.ext.hp.com/veneer/veneer/commit/79bf91aaf7e5111a2a80453286fc1849790a34d5) Thanks [@tamires-silva](https://github.azc.ext.hp.com/tamires-silva)! - [Table] Updates check for style application in header box

### Patch Changes

- [#6468](https://github.azc.ext.hp.com/veneer/veneer/pull/6468) [`a943882`](https://github.azc.ext.hp.com/veneer/veneer/commit/a943882f5c3a4f127a1cfdea937e3871be06eedd) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - [NotificationCenter] Fix icon sizing

- [#6461](https://github.azc.ext.hp.com/veneer/veneer/pull/6461) [`c4e15e2`](https://github.azc.ext.hp.com/veneer/veneer/commit/c4e15e2975a70f926399908fb3c1b72aeb40bac2) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - [AnchorMenu] Fix hover effects

  Fix a bug in the anchor menu where active item would sometimes lose styling on mouse leave.

- Updated dependencies [[`e0bfd76`](https://github.azc.ext.hp.com/veneer/veneer/commit/e0bfd76f1da8e9d01a11ac14046bd751448f8fc6)]:
  - @veneer/theme@3.80.0

## 3.101.0

### Minor Changes

- [#6424](https://github.azc.ext.hp.com/veneer/veneer/pull/6424) [`9edd411`](https://github.azc.ext.hp.com/veneer/veneer/commit/9edd4116f445ddef6b85fc178fea407b708d080b) Thanks [@walter-ferreira](https://github.azc.ext.hp.com/walter-ferreira)! - [DatePicker] Updated end date separate label in pill shape.

- [#6459](https://github.azc.ext.hp.com/veneer/veneer/pull/6459) [`6c9783f`](https://github.azc.ext.hp.com/veneer/veneer/commit/6c9783f5d3834db132ac0d45d662337a954a9630) Thanks [@joao-flores-de-leao](https://github.azc.ext.hp.com/joao-flores-de-leao)! - [Foundation] Update @veneer/assets to 3.10.0

- [#6442](https://github.azc.ext.hp.com/veneer/veneer/pull/6442) [`7eef67d`](https://github.azc.ext.hp.com/veneer/veneer/commit/7eef67d61c374708cc507c8e512c3e8a2d64bd80) Thanks [@tamires-silva](https://github.azc.ext.hp.com/tamires-silva)! - [Stepper] Remove fixed height from base style to fix component height vertically

- [#6414](https://github.azc.ext.hp.com/veneer/veneer/pull/6414) [`072e9ac`](https://github.azc.ext.hp.com/veneer/veneer/commit/072e9ac78cedf139373e03f100a4366df6fc07f3) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [Tabs] Add disabled property to TabInterface.

### Patch Changes

- [#6413](https://github.azc.ext.hp.com/veneer/veneer/pull/6413) [`435f4c5`](https://github.azc.ext.hp.com/veneer/veneer/commit/435f4c5c4d5acad14c7483a77031201a41f1473b) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [Tabs] Fix animation on safari.

## 3.100.0

### Minor Changes

- [#6394](https://github.azc.ext.hp.com/veneer/veneer/pull/6394) [`8dc5c5f`](https://github.azc.ext.hp.com/veneer/veneer/commit/8dc5c5fa01bf073617b8d940872544da4c56953b) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [Tabs] Set Tabs label as ReactNode.

  With this addition, you can have icons along with labels. Check our storybook for more information.

- [#6328](https://github.azc.ext.hp.com/veneer/veneer/pull/6328) [`d3a478e`](https://github.azc.ext.hp.com/veneer/veneer/commit/d3a478e0e398e44588877e4d803019376cf61d53) Thanks [@anderson-freitas](https://github.azc.ext.hp.com/anderson-freitas)! - [Pagination] Padding adjustments

- [#6356](https://github.azc.ext.hp.com/veneer/veneer/pull/6356) [`7cb72ae`](https://github.azc.ext.hp.com/veneer/veneer/commit/7cb72ae026fd44ae4c1198498295934a49def199) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - [Table] Header row now has grey background"

- [#6359](https://github.azc.ext.hp.com/veneer/veneer/pull/6359) [`46d7685`](https://github.azc.ext.hp.com/veneer/veneer/commit/46d76852611b5d4ae0b32caa6e9e409497b2af09) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [Inputs][FormControls] Add `background` property to set components background. Default is `transparent`, but you can set to `filled`.
  Components contemplated: DatePicker, FilePicker, Password, Search, Select, TextArea, TextBox, Checkbox, RadioButton, Toggle.

  [ThemeProvider] Add `inputBackground` property. Will control all inputs background between transparent or filled.

- [#6371](https://github.azc.ext.hp.com/veneer/veneer/pull/6371) [`6f32867`](https://github.azc.ext.hp.com/veneer/veneer/commit/6f32867322b594638090f4ea51e02b60cf82f174) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [Table] Use Tag instead of Fake Button on items selected.

- [#6335](https://github.azc.ext.hp.com/veneer/veneer/pull/6335) [`96c884d`](https://github.azc.ext.hp.com/veneer/veneer/commit/96c884d1e4e0cabac972c0b057a110367c55ef98) Thanks [@pedro-soares](https://github.azc.ext.hp.com/pedro-soares)! - [FormControl] Deprecate 'separatedLabel=false' when the the theme density is high.

- [#6293](https://github.azc.ext.hp.com/veneer/veneer/pull/6293) [`00fb27b`](https://github.azc.ext.hp.com/veneer/veneer/commit/00fb27ba928cf7b4ce232c42033142db1998e567) Thanks [@tamires-silva](https://github.azc.ext.hp.com/tamires-silva)! - [Table] fix select all items behavior

- [#6317](https://github.azc.ext.hp.com/veneer/veneer/pull/6317) [`57d873f`](https://github.azc.ext.hp.com/veneer/veneer/commit/57d873fa44ffaf896b06dc7f076b3630573a3766) Thanks [@joao-flores-de-leao](https://github.azc.ext.hp.com/joao-flores-de-leao)! - [Checkbox]

  - Added `aria-disabled` (component not interactive, but focusable by assistive technologies)
  - Fixed double trigger by keyboard use.
  - Changed properties to help WCAG coverage
  - Increased the hit area on high density to 24px

- [#6357](https://github.azc.ext.hp.com/veneer/veneer/pull/6357) [`bd40031`](https://github.azc.ext.hp.com/veneer/veneer/commit/bd40031bc59bc267a7086644fd05a0f3c52c661a) Thanks [@tamires-silva](https://github.azc.ext.hp.com/tamires-silva)! - [Action Button] Change icon color

- [#6358](https://github.azc.ext.hp.com/veneer/veneer/pull/6358) [`63ee2ac`](https://github.azc.ext.hp.com/veneer/veneer/commit/63ee2ac53412b385a3d8bf0bfb23e446ca6423e8) Thanks [@anderson-freitas](https://github.azc.ext.hp.com/anderson-freitas)! - [DatePicker][Select] Update the input label zIndex to 0

- [#6393](https://github.azc.ext.hp.com/veneer/veneer/pull/6393) [`3956182`](https://github.azc.ext.hp.com/veneer/veneer/commit/39561827762cd7f1431eb28e6a7469c7761a3292) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [AnchorMenu] Fix zIndex issue.

- [#6356](https://github.azc.ext.hp.com/veneer/veneer/pull/6356) [`7cb72ae`](https://github.azc.ext.hp.com/veneer/veneer/commit/7cb72ae026fd44ae4c1198498295934a49def199) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - [Table] Allow disabling zebra stripes

  A new `zebra` property is added to the `Table` component. If set to `false`, zebra stripes will be disabled.

- [#6397](https://github.azc.ext.hp.com/veneer/veneer/pull/6397) [`54d216f`](https://github.azc.ext.hp.com/veneer/veneer/commit/54d216ffbc7d3643d3e268080b71a61bed39bd72) Thanks [@anderson-freitas](https://github.azc.ext.hp.com/anderson-freitas)! - [DatePicker] Updated the select month/year on pill shape to have the same border-radius as the round shape

- [#6324](https://github.azc.ext.hp.com/veneer/veneer/pull/6324) [`6ed4a5d`](https://github.azc.ext.hp.com/veneer/veneer/commit/6ed4a5d1b51d57a0b1c5a6c76aa202361513a55c) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - [Scrollbar] Deprecated scrollbar has been removed

- [#6448](https://github.azc.ext.hp.com/veneer/veneer/pull/6448) [`2ca77c0`](https://github.azc.ext.hp.com/veneer/veneer/commit/2ca77c0ba1efe9d8321e73c93994531f593f16ee) Thanks [@pedro-soares](https://github.azc.ext.hp.com/pedro-soares)! - [Foundation] Update @veneer/assets to 3.9.0, update @veneer/primitives to 3.61.1 and update @veneer/semantics to 3.7.0

- [#6395](https://github.azc.ext.hp.com/veneer/veneer/pull/6395) [`ce80e8f`](https://github.azc.ext.hp.com/veneer/veneer/commit/ce80e8f5610aefaa5dad7119e7e9e68e9781f48e) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [Pagination] Fix focus state for page size select.

- [#6381](https://github.azc.ext.hp.com/veneer/veneer/pull/6381) [`df100ad`](https://github.azc.ext.hp.com/veneer/veneer/commit/df100add7a27d8cb8cd662dc99a3cefbd2e0d022) Thanks [@tamires-silva](https://github.azc.ext.hp.com/tamires-silva)! - [Table] Change table cell height and paddings

- [#6263](https://github.azc.ext.hp.com/veneer/veneer/pull/6263) [`555624f`](https://github.azc.ext.hp.com/veneer/veneer/commit/555624f4b99eb6d8ab0f03d6f56315fa3287bfaf) Thanks [@joao-flores-de-leao](https://github.azc.ext.hp.com/joao-flores-de-leao)! - [CustomImage]

  - Organized the props descriptions to better show which ones are for svg/img/both
  - Deprecated the focusable prop since images should not be focusable, but wrapped in interactive elements
  - Deprecated the title in favor of native `aria-label` or `alt`, depending on the type of image (`svg` or `img`)
  - Added aria-label, aria-hidden, aria-labelledby to the props that show on website
  - Added the informative/decorative logic based on the aria-label
    - For `img`
      - default is an decorative (hidden from screenreaders)
      - if an alt/aria-label/aria-labelledby is provided the component turns informative (looses aria-hidden and becomes visible to screenreaders)
    - For `svg`
      - default is an decorative (hidden from screenreaders)
      - if an aria-label or aria-labelledby is provided the component turns informative (looses aria-hidde, changes role from 'presentation' to 'img' and becomes visible for screenreaders)

- [#6372](https://github.azc.ext.hp.com/veneer/veneer/pull/6372) [`5936264`](https://github.azc.ext.hp.com/veneer/veneer/commit/5936264fb680054445fdbe612158fb493a6770a5) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [Table] Add `containerOutline` which renders a contained version of Table.

- [#6368](https://github.azc.ext.hp.com/veneer/veneer/pull/6368) [`7c6497b`](https://github.azc.ext.hp.com/veneer/veneer/commit/7c6497b89d900c1617949ba663e50745a8351cb9) Thanks [@walter-ferreira](https://github.azc.ext.hp.com/walter-ferreira)! - [ContextualMenu] Update label paddings in pill shape

- [#6128](https://github.azc.ext.hp.com/veneer/veneer/pull/6128) [`7939b5a`](https://github.azc.ext.hp.com/veneer/veneer/commit/7939b5a1521271ca61a0d7f4a255d42d002b1b09) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - [Infra] Update to emotion 11

  As part of the upgrade to emotion 11, two new peer dependencies have been added for `@veneer/core`:

  - `@emotion/react`: `^11.11.4`
  - `@emotion/cache`: `^11.11.0`

  This is to ensure that if you are already using emotion 11, only one version of each is used.

- [#6352](https://github.azc.ext.hp.com/veneer/veneer/pull/6352) [`2d91caa`](https://github.azc.ext.hp.com/veneer/veneer/commit/2d91caabce564f5b9bd29af15066c242d2b093ad) Thanks [@joao-flores-de-leao](https://github.azc.ext.hp.com/joao-flores-de-leao)! - [Toggle]

  - [x] Added ´aria-disabled´ (component not interactive, but focusable).
  - [x] Replaced aria attributes overrides in favor of native HTML accessibility.
  - [x] Organized and simplified decorative and interactive elements.

- [#6324](https://github.azc.ext.hp.com/veneer/veneer/pull/6324) [`6ed4a5d`](https://github.azc.ext.hp.com/veneer/veneer/commit/6ed4a5d1b51d57a0b1c5a6c76aa202361513a55c) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - [Infra] Update @emotion/core to latest version 10

- [#6380](https://github.azc.ext.hp.com/veneer/veneer/pull/6380) [`c01ab74`](https://github.azc.ext.hp.com/veneer/veneer/commit/c01ab74c27a7893215d28afc1818c2c2e317a0e4) Thanks [@pedro-soares](https://github.azc.ext.hp.com/pedro-soares)! - [Table] columns now have a `highlight` property. If set to `true` the column should be entire highlighted. This property is already using the new semantics colors `effects.highlight.default`"

- [#6360](https://github.azc.ext.hp.com/veneer/veneer/pull/6360) [`0637dc0`](https://github.azc.ext.hp.com/veneer/veneer/commit/0637dc0b6c6b6eb3bf7a1d2f8522be06c4c16325) Thanks [@tamires-silva](https://github.azc.ext.hp.com/tamires-silva)! - [Tabs] Adds check to modify tab display when there is no content panel.

- [#6364](https://github.azc.ext.hp.com/veneer/veneer/pull/6364) [`0d41fe0`](https://github.azc.ext.hp.com/veneer/veneer/commit/0d41fe020fcedf65d091ec5db0f8d2dc0f2b4042) Thanks [@anderson-freitas](https://github.azc.ext.hp.com/anderson-freitas)! - [List] Padding adjustments

### Patch Changes

- [#6368](https://github.azc.ext.hp.com/veneer/veneer/pull/6368) [`7c6497b`](https://github.azc.ext.hp.com/veneer/veneer/commit/7c6497b89d900c1617949ba663e50745a8351cb9) Thanks [@walter-ferreira](https://github.azc.ext.hp.com/walter-ferreira)! - [ContextualMenu][SideMenu] Fixed visual cue for pill shape

- [#6326](https://github.azc.ext.hp.com/veneer/veneer/pull/6326) [`e137d68`](https://github.azc.ext.hp.com/veneer/veneer/commit/e137d68d3924c7d12423b187b95293b632cd2bb6) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - [MenuItem] Ensure onClick passed to MenuItem is not called when item disabled

- [#6330](https://github.azc.ext.hp.com/veneer/veneer/pull/6330) [`f53ebd6`](https://github.azc.ext.hp.com/veneer/veneer/commit/f53ebd6a00a7bacf633b5828a215fc9cd1a1900b) Thanks [@walter-ferreira](https://github.azc.ext.hp.com/walter-ferreira)! - [DatePicker] Fixed Single DatePicker border in HC

- Updated dependencies [[`2ca77c0`](https://github.azc.ext.hp.com/veneer/veneer/commit/2ca77c0ba1efe9d8321e73c93994531f593f16ee)]:
  - @veneer/styles@3.61.0
  - @veneer/theme@3.79.0

## 3.99.0

### Minor Changes

- [#6304](https://github.azc.ext.hp.com/veneer/veneer/pull/6304) [`90cef04`](https://github.azc.ext.hp.com/veneer/veneer/commit/90cef04c28198cacf1be1d7573f9280a80f3a52d) Thanks [@joao-flores-de-leao](https://github.azc.ext.hp.com/joao-flores-de-leao)! - [RadioButtons] Component deprecated in favor of `RadioGroup`.
  [RadioButton]

  - Small refactor on RadioButton style to improve animations and focus `SC 2.1.1`.
  - Separation of decorative and interactive elements to fix screen reader compatibility `SC 1.3.1`.
  - aria-label and aria-labelledby clearly documented to aid users.
  - Added possibility to use aria-disabled (component not interactive, but focus still possible to help assistive technologies)
  - Target size upgraded to be 24px on HD `SC 2.5.8`.
  - Pseudoelement ::before removed to avoid cluttered styles and to align better with design (that uses a borderWidth of 6px instead of another element).
    [RadioGroup]
  - New component based on RadioButtons, but slightly changed to better reflect its behavior, RadioButtons is still available but deprecated.
  - Disabled prop added to disable the whole group.
  - Label prop added to conform to `SC 2.4.6`, `SC 3.3.2`, `SC 4.1.2` and especially `SC 1.3.5`.
  - `<div role='radiogroup'/>` changed to `<fieldset/>` `SC 4.1.2`.
  - aria-label and aria-labelledby clearly documented to aid users.
  - Added possibility to use aria-disabled (component not interactive, but focus still possible to help assistive technologies).

- [#6273](https://github.azc.ext.hp.com/veneer/veneer/pull/6273) [`eae526b`](https://github.azc.ext.hp.com/veneer/veneer/commit/eae526b671f668fcc9ce23927673ee2100d80c4f) Thanks [@joao-flores-de-leao](https://github.azc.ext.hp.com/joao-flores-de-leao)! - [Checkbox]

  - Improvements to match WCAG guidelines on accessibility.
  - Deprecated the focusable prop since images should not be focusable, but wrapped in interactive elements.
  - Deprecated the label prop (but still left it working) in favor or aria-label for consistency.
  - Added aria-label, aria-hidden, aria-labelledby custom description.
  - Added the informative/decorative logic based on the aria-label.
    - default is an decorative svg (hidden from screenreaders).
    - if an aria-label or aria-labelledby is provided the icon turns informative (looses aria-hidden, changes role from 'presentation' to 'img' and becomes visible for screenreaders).

- [#6294](https://github.azc.ext.hp.com/veneer/veneer/pull/6294) [`14a1b88`](https://github.azc.ext.hp.com/veneer/veneer/commit/14a1b8825d764dcf51b41c4bc0e15b732823f58d) Thanks [@walter-ferreira](https://github.azc.ext.hp.com/walter-ferreira)! - [ProgressIndicator] add pill shape support and `trackThickness` property.

- [#6259](https://github.azc.ext.hp.com/veneer/veneer/pull/6259) [`d4e15a7`](https://github.azc.ext.hp.com/veneer/veneer/commit/d4e15a706609ce97edcf8a8b2f83dbde93a848b4) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - [Chart] Remove chart exports from `@veneer/core`

  Please update your chart imports to `@veneer/highcharts-interface`

- [#6236](https://github.azc.ext.hp.com/veneer/veneer/pull/6236) [`88c2ae0`](https://github.azc.ext.hp.com/veneer/veneer/commit/88c2ae0c14011a82e75a891079cfe13c618a33d0) Thanks [@tamires-silva](https://github.azc.ext.hp.com/tamires-silva)! - [Search] Padding adjustments

- [#6279](https://github.azc.ext.hp.com/veneer/veneer/pull/6279) [`986dbb4`](https://github.azc.ext.hp.com/veneer/veneer/commit/986dbb412d29c0031e8e052111cbaf702504434d) Thanks [@pedro-soares](https://github.azc.ext.hp.com/pedro-soares)! - [Accordion] Padding adjustments

- [#6270](https://github.azc.ext.hp.com/veneer/veneer/pull/6270) [`0cd81d1`](https://github.azc.ext.hp.com/veneer/veneer/commit/0cd81d12f8f9de6032d87ce2898253271b24d716) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [SegmentedControl] Update focus ring to follow keyboard conventions. Fix keyboard trap

- [#6282](https://github.azc.ext.hp.com/veneer/veneer/pull/6282) [`08fc3db`](https://github.azc.ext.hp.com/veneer/veneer/commit/08fc3db8545293104ea9af4964b6d487925ccd66) Thanks [@anderson-freitas](https://github.azc.ext.hp.com/anderson-freitas)! - [List] Padding adjustments

- [#6243](https://github.azc.ext.hp.com/veneer/veneer/pull/6243) [`a0d2c16`](https://github.azc.ext.hp.com/veneer/veneer/commit/a0d2c162f159b7350f196cc0cfa5ce1956d1ae81) Thanks [@walter-ferreira](https://github.azc.ext.hp.com/walter-ferreira)! - [DatePicker] Adjust paddings on pill shape.

- [#6310](https://github.azc.ext.hp.com/veneer/veneer/pull/6310) [`afbd6f3`](https://github.azc.ext.hp.com/veneer/veneer/commit/afbd6f3159062b585197498c403696b3d33e39d9) Thanks [@walter-ferreira](https://github.azc.ext.hp.com/walter-ferreira)! - [ProgressIndicator] Update the Round Linear Progress Indicator to look like pill

- [#6240](https://github.azc.ext.hp.com/veneer/veneer/pull/6240) [`8c27665`](https://github.azc.ext.hp.com/veneer/veneer/commit/8c2766504e58472d8a457beefc22c414c433b431) Thanks [@tamires-silva](https://github.azc.ext.hp.com/tamires-silva)! - [Filepicker] Padding adjustments

- [#6274](https://github.azc.ext.hp.com/veneer/veneer/pull/6274) [`0bb1303`](https://github.azc.ext.hp.com/veneer/veneer/commit/0bb13031d6c3f74081265f5ea7b40f59c1292555) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [NotificationCenter] Add `hideIcon` prop to NotificationCenterItem. This prop will hide the status icon, avatar is standalone.
  `leftHeaderArea` and `rightHeaderArea` have been removed. Please update your code with `leadingHeaderArea` and `trailingHeaderArea`.

- [#6291](https://github.azc.ext.hp.com/veneer/veneer/pull/6291) [`a3765ca`](https://github.azc.ext.hp.com/veneer/veneer/commit/a3765ca2d9172fd5214eeb146291aac6034b5b97) Thanks [@walter-ferreira](https://github.azc.ext.hp.com/walter-ferreira)! - [Search] Fix padding between trailing icon and border

- [#6396](https://github.azc.ext.hp.com/veneer/veneer/pull/6396) [`aa84d22`](https://github.azc.ext.hp.com/veneer/veneer/commit/aa84d221a14b82cd929f71f4d596e033f1759180) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [Foundation] Update @veneer/assets to 3.8.0, update @veneer/primitives to 3.61.0 and update @veneer/semantics to 3.6.0

- [#6349](https://github.azc.ext.hp.com/veneer/veneer/pull/6349) [`836b834`](https://github.azc.ext.hp.com/veneer/veneer/commit/836b834e1d74a4a116d1fd2a5b5884792472f396) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - [ContextualMenu] Update label paddings in pill shape

- [#6298](https://github.azc.ext.hp.com/veneer/veneer/pull/6298) [`a984c97`](https://github.azc.ext.hp.com/veneer/veneer/commit/a984c976285393889a3ba9c53ca312fb765b49dc) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - [React] Update minimum supported react to 16.14.0

  This is in preparation for a future update to React 17; it is strongly recommended to update to React 18.

- [#6349](https://github.azc.ext.hp.com/veneer/veneer/pull/6349) [`836b834`](https://github.azc.ext.hp.com/veneer/veneer/commit/836b834e1d74a4a116d1fd2a5b5884792472f396) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - [List] Padding adjustments

### Patch Changes

- [#6349](https://github.azc.ext.hp.com/veneer/veneer/pull/6349) [`836b834`](https://github.azc.ext.hp.com/veneer/veneer/commit/836b834e1d74a4a116d1fd2a5b5884792472f396) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - [ContextualMenu][SideMenu] Fixed visual cue for pill shape

- [#6281](https://github.azc.ext.hp.com/veneer/veneer/pull/6281) [`97d8b85`](https://github.azc.ext.hp.com/veneer/veneer/commit/97d8b85a9fb8f7a5271877cb64c5d34254a4617f) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [InlineNotification] Set title property to optional.

- [#6344](https://github.azc.ext.hp.com/veneer/veneer/pull/6344) [`f7bf563`](https://github.azc.ext.hp.com/veneer/veneer/commit/f7bf5634828dab7e61b1050616e88e264a06948b) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - [DatePicker] Fixed Single DatePicker border in HC

- Updated dependencies [[`aa84d22`](https://github.azc.ext.hp.com/veneer/veneer/commit/aa84d221a14b82cd929f71f4d596e033f1759180), [`a984c97`](https://github.azc.ext.hp.com/veneer/veneer/commit/a984c976285393889a3ba9c53ca312fb765b49dc)]:
  - @veneer/styles@3.60.0
  - @veneer/theme@3.78.0

## 3.98.0

### Minor Changes

- [#6257](https://github.azc.ext.hp.com/veneer/veneer/pull/6257) [`e4c6c7d`](https://github.azc.ext.hp.com/veneer/veneer/commit/e4c6c7dcffd168e43a487edd8a19e6a400bb5a07) Thanks [@joao-flores-de-leao](https://github.azc.ext.hp.com/joao-flores-de-leao)! - [TextBox/Input] Adjust paddings on pill shape.

- [#6257](https://github.azc.ext.hp.com/veneer/veneer/pull/6257) [`e4c6c7d`](https://github.azc.ext.hp.com/veneer/veneer/commit/e4c6c7dcffd168e43a487edd8a19e6a400bb5a07) Thanks [@joao-flores-de-leao](https://github.azc.ext.hp.com/joao-flores-de-leao)! - [TreeView] Adjust paddings.

- [#6257](https://github.azc.ext.hp.com/veneer/veneer/pull/6257) [`e4c6c7d`](https://github.azc.ext.hp.com/veneer/veneer/commit/e4c6c7dcffd168e43a487edd8a19e6a400bb5a07) Thanks [@joao-flores-de-leao](https://github.azc.ext.hp.com/joao-flores-de-leao)! - [ToastNotification] Adjust paddings on all densities.

- [#6257](https://github.azc.ext.hp.com/veneer/veneer/pull/6257) [`e4c6c7d`](https://github.azc.ext.hp.com/veneer/veneer/commit/e4c6c7dcffd168e43a487edd8a19e6a400bb5a07) Thanks [@joao-flores-de-leao](https://github.azc.ext.hp.com/joao-flores-de-leao)! - [ContextualMenu] Adjust paddings on pill shape.

- [#6257](https://github.azc.ext.hp.com/veneer/veneer/pull/6257) [`e4c6c7d`](https://github.azc.ext.hp.com/veneer/veneer/commit/e4c6c7dcffd168e43a487edd8a19e6a400bb5a07) Thanks [@joao-flores-de-leao](https://github.azc.ext.hp.com/joao-flores-de-leao)! - [Modal] Adjust paddings on pill shape.

- [#6257](https://github.azc.ext.hp.com/veneer/veneer/pull/6257) [`e4c6c7d`](https://github.azc.ext.hp.com/veneer/veneer/commit/e4c6c7dcffd168e43a487edd8a19e6a400bb5a07) Thanks [@joao-flores-de-leao](https://github.azc.ext.hp.com/joao-flores-de-leao)! - [Password] Adjust paddings on pill shape.

- [#6290](https://github.azc.ext.hp.com/veneer/veneer/pull/6290) [`6ab8524`](https://github.azc.ext.hp.com/veneer/veneer/commit/6ab8524421dac59612276921aace793a8a8d09c5) Thanks [@joao-flores-de-leao](https://github.azc.ext.hp.com/joao-flores-de-leao)! - [Search] Fix padding between trailing icon and border

- [#6257](https://github.azc.ext.hp.com/veneer/veneer/pull/6257) [`e4c6c7d`](https://github.azc.ext.hp.com/veneer/veneer/commit/e4c6c7dcffd168e43a487edd8a19e6a400bb5a07) Thanks [@joao-flores-de-leao](https://github.azc.ext.hp.com/joao-flores-de-leao)! - [Select] Adjust paddings on pill shape.
  [TextArea] Adjust paddings on pill shape.

- [#6257](https://github.azc.ext.hp.com/veneer/veneer/pull/6257) [`e4c6c7d`](https://github.azc.ext.hp.com/veneer/veneer/commit/e4c6c7dcffd168e43a487edd8a19e6a400bb5a07) Thanks [@joao-flores-de-leao](https://github.azc.ext.hp.com/joao-flores-de-leao)! - [SideMenu] Adjust paddings on pill shape.

- [#6257](https://github.azc.ext.hp.com/veneer/veneer/pull/6257) [`e4c6c7d`](https://github.azc.ext.hp.com/veneer/veneer/commit/e4c6c7dcffd168e43a487edd8a19e6a400bb5a07) Thanks [@joao-flores-de-leao](https://github.azc.ext.hp.com/joao-flores-de-leao)! - [Breadcrumbs] Update paddings for pill shape.

### Patch Changes

- [#6308](https://github.azc.ext.hp.com/veneer/veneer/pull/6308) [`3b5e8b3`](https://github.azc.ext.hp.com/veneer/veneer/commit/3b5e8b300e4875622d5c26a9cf9e73ddd8ca8ebd) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - [Infra] Update @veneer/semantics to 3.5.0

- [#6189](https://github.azc.ext.hp.com/veneer/veneer/pull/6189) [`7a87a86`](https://github.azc.ext.hp.com/veneer/veneer/commit/7a87a8623112d5382afa3bcf76391fd72c4d77f1) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - [ToastNotification] Closing toast clicks no longer propagate

- [#6225](https://github.azc.ext.hp.com/veneer/veneer/pull/6225) [`dd99934`](https://github.azc.ext.hp.com/veneer/veneer/commit/dd99934fa1903b8f0d372857e0035efdc0297926) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - [AppHeader] Fix rendering of ReactNode appName

- Updated dependencies [[`e4c6c7d`](https://github.azc.ext.hp.com/veneer/veneer/commit/e4c6c7dcffd168e43a487edd8a19e6a400bb5a07), [`3b5e8b3`](https://github.azc.ext.hp.com/veneer/veneer/commit/3b5e8b300e4875622d5c26a9cf9e73ddd8ca8ebd), [`e4c6c7d`](https://github.azc.ext.hp.com/veneer/veneer/commit/e4c6c7dcffd168e43a487edd8a19e6a400bb5a07), [`e4c6c7d`](https://github.azc.ext.hp.com/veneer/veneer/commit/e4c6c7dcffd168e43a487edd8a19e6a400bb5a07)]:
  - @veneer/theme@3.77.0
  - @veneer/highcharts-interface@3.60.1

## 3.97.0

### Minor Changes

- [#6088](https://github.azc.ext.hp.com/veneer/veneer/pull/6088) [`8fa272d`](https://github.azc.ext.hp.com/veneer/veneer/commit/8fa272d76c16b0d17576c0cfcc6b42f33c5d4bcf) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - Veneer packages have moved to a new repository on Nexus.

  In order to simplify Veneer's release process, Veneer packages are only published to the GitHub repository (https://npm.github.azc.ext.hp.com).

  To support users who need to use Nexus, there is a new Nexus repository (https://nexus-int.corp.hpicloud.net/repository/veneer-proxy/) that mirrors the GitHub repository.

  If you are using Nexus, and are unable to switch to GitHub, please update your configuration to point at this new repository.

### Patch Changes

- [#6175](https://github.azc.ext.hp.com/veneer/veneer/pull/6175) [`0136aa9`](https://github.azc.ext.hp.com/veneer/veneer/commit/0136aa90ec3fdf17c6c2d7622996ca724ca4548b) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - [DatePicker] Fix aria labels on year navigation

- [#6196](https://github.azc.ext.hp.com/veneer/veneer/pull/6196) [`2b29997`](https://github.azc.ext.hp.com/veneer/veneer/commit/2b29997624437acc8bdaa40a9ccf71b9c955ba0b) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - [Table] Fix resizing on firefox/safari desktop

- [#6232](https://github.azc.ext.hp.com/veneer/veneer/pull/6232) [`b7231a6`](https://github.azc.ext.hp.com/veneer/veneer/commit/b7231a6f6c845dbc9fb7a421ea0c3a5aeda6900b) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - [Foundation] Update packages

- Updated dependencies [[`8fa272d`](https://github.azc.ext.hp.com/veneer/veneer/commit/8fa272d76c16b0d17576c0cfcc6b42f33c5d4bcf), [`b7231a6`](https://github.azc.ext.hp.com/veneer/veneer/commit/b7231a6f6c845dbc9fb7a421ea0c3a5aeda6900b)]:
  - @veneer/highcharts-interface@3.60.0
  - @veneer/theme@3.76.0
  - @veneer/logos@3.3.0
  - @veneer/styles@3.59.0

## 3.96.0

### Minor Changes

- [#6098](https://github.azc.ext.hp.com/veneer/veneer/pull/6098) [`6df1339`](https://github.azc.ext.hp.com/veneer/veneer/commit/6df133991ed07ebc73497ec6749374944d313fc0) Thanks [@walter-ferreira](https://github.azc.ext.hp.com/walter-ferreira)! - Add Pill Shape support and updated Select component

### Patch Changes

- Updated dependencies [[`6df1339`](https://github.azc.ext.hp.com/veneer/veneer/commit/6df133991ed07ebc73497ec6749374944d313fc0), [`ff06fd3`](https://github.azc.ext.hp.com/veneer/veneer/commit/ff06fd324e5fdd74155f0cb9f40636d319d1a179)]:
  - @veneer/theme@3.75.0
  - @veneer/highcharts-interface@3.59.3

## 3.95.1

### Patch Changes

- [#6192](https://github.azc.ext.hp.com/veneer/veneer/pull/6192) [`d6b31fa181`](https://github.azc.ext.hp.com/veneer/veneer/commit/d6b31fa18115541bafccca1e53329d1a3a97c37d) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [SideMenu] Fix box-sizing behavior for visual cue.

## 3.95.0

### 🎨 Color Updates

- Expanded system color definitions

  - 🆕 Added Help, Caution, Spotlight, and Effect colors.
  - 🌈 For improved color theming, added Foreground, Base, and Background colors to interaction elements
  - 🚫 Removed transparency from some background colors, like non-neutrals

- Enhanced consistency between design and code
  - 📦 Foundation packages updated from Tokens to Primitives
  - 📦 Foundation packages updated from System to Semantics

📕 For more information about these changes, check the [development migration guide](https://github.azc.ext.hp.com/veneer/veneer-dictionaries/blob/release/3.3.0/MIGRATION.MD)

### Minor Changes

- [#5484](https://github.azc.ext.hp.com/veneer/veneer/pull/5484) [`c9658eaf33`](https://github.azc.ext.hp.com/veneer/veneer/commit/c9658eaf332642b76cab5886e58bb20d5f3b6079) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [Button] New appearance `caution` added

* [#6087](https://github.azc.ext.hp.com/veneer/veneer/pull/6087) [`f2b5da4724`](https://github.azc.ext.hp.com/veneer/veneer/commit/f2b5da4724f83541def45aebf2bc574e82c9f858) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - [FilePicker] Remove resize prop

- [#6090](https://github.azc.ext.hp.com/veneer/veneer/pull/6090) [`94b9a5752d`](https://github.azc.ext.hp.com/veneer/veneer/commit/94b9a5752d438e0e1dacaf105d617203731c1eec) Thanks [@tulio-silva](https://github.azc.ext.hp.com/tulio-silva)! - [Checkbox][RadioButton][Toogle] Responsiveness alignments

  - Improve responsiveness behavior in this group of components.

### Patch Changes

- [#6076](https://github.azc.ext.hp.com/veneer/veneer/pull/6076) [`8707c64a93`](https://github.azc.ext.hp.com/veneer/veneer/commit/8707c64a93b783928851275409dc00648689d9ac) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - [Tooltip] Fix RTL arrow positioning

* [#6076](https://github.azc.ext.hp.com/veneer/veneer/pull/6076) [`8707c64a93`](https://github.azc.ext.hp.com/veneer/veneer/commit/8707c64a93b783928851275409dc00648689d9ac) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - [Tooltip] Fix padding and border

- [#6034](https://github.azc.ext.hp.com/veneer/veneer/pull/6034) [`854ac795c8`](https://github.azc.ext.hp.com/veneer/veneer/commit/854ac795c894bd75e7f4a164fe6c13ebca33f460) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - [Table] Fix column selector reset to default not updating checkboxes

* [#6063](https://github.azc.ext.hp.com/veneer/veneer/pull/6063) [`e144dd5e18`](https://github.azc.ext.hp.com/veneer/veneer/commit/e144dd5e185e7e5a4e538575524b2a507eee9cf7) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - [ContextualMenu][Search][Select][Password] Update popover corner-radius to 12px

- [#6064](https://github.azc.ext.hp.com/veneer/veneer/pull/6064) [`da566fc4ef`](https://github.azc.ext.hp.com/veneer/veneer/commit/da566fc4ef41349f86ddec4138da66f16b4533e5) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - [Styles] Fix anchor outline flickering

  Anchor outlines would briefly flicker when clicking away from a clicked anchor.

* [#6075](https://github.azc.ext.hp.com/veneer/veneer/pull/6075) [`8ee6dc5de7`](https://github.azc.ext.hp.com/veneer/veneer/commit/8ee6dc5de792f0cf3db86b7a057d3060ce19aceb) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - [Pagination][Header] Prevent styles being shown in nextjs apps

* Updated dependencies [[`da566fc4ef`](https://github.azc.ext.hp.com/veneer/veneer/commit/da566fc4ef41349f86ddec4138da66f16b4533e5), [`8d2ffa0498`](https://github.azc.ext.hp.com/veneer/veneer/commit/8d2ffa0498a1f433144f68d1b399242b542f9ffb)]:
  - @veneer/styles@3.58.1
  - @veneer/theme@3.74.0
  - @veneer/highcharts-interface@3.59.2

## 3.94.0

### Minor Changes

- [#6024](https://github.azc.ext.hp.com/veneer/veneer/pull/6024) [`1d3dd55667da`](https://github.azc.ext.hp.com/veneer/veneer/commit/1d3dd55667da16f3ee9b8a601d2f527a460fbb49) Thanks [@joao-flores-de-leao](https://github.azc.ext.hp.com/joao-flores-de-leao)! - [Tag] Conserve borderRadius when sharp.

* [#6017](https://github.azc.ext.hp.com/veneer/veneer/pull/6017) [`0f9b6878adc8`](https://github.azc.ext.hp.com/veneer/veneer/commit/0f9b6878adc85db21c7766f47603b7ff9a12782e) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [TreeView] Remove unwanted IconCheckmark.

### Patch Changes

- [#5973](https://github.azc.ext.hp.com/veneer/veneer/pull/5973) [`2821359eb5fe`](https://github.azc.ext.hp.com/veneer/veneer/commit/2821359eb5fe52f4e199f6633f77d2cd00457257) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - [Select] Fix unwanted label shrinkage on focus

* [#6036](https://github.azc.ext.hp.com/veneer/veneer/pull/6036) [`b0a6982d08cc`](https://github.azc.ext.hp.com/veneer/veneer/commit/b0a6982d08cc39aded0b838e6d00fafea9da5999) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - [AppHeader] Only mark app header logo as clickable if it is

## 3.93.0

### Minor Changes

- [#5965](https://github.azc.ext.hp.com/veneer/veneer/pull/5965) [`dcd71c594`](https://github.azc.ext.hp.com/veneer/veneer/commit/dcd71c5947eff83a536c9ada156b4adb9c620f65) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - [Icon] Icons now sourced from @veneer/assets

## 3.92.0

### Minor Changes

- [#5981](https://github.azc.ext.hp.com/veneer/veneer/pull/5981) [`e098f9585`](https://github.azc.ext.hp.com/veneer/veneer/commit/e098f9585316553787341855b22614908e149945) Thanks [@ramon-prado](https://github.azc.ext.hp.com/ramon-prado)! - [Icon] Icons now sourced from @veneer/assets

* [#5934](https://github.azc.ext.hp.com/veneer/veneer/pull/5934) [`dda0a1319`](https://github.azc.ext.hp.com/veneer/veneer/commit/dda0a131946a0c935fb06cb6ad75d6e6f750652f) Thanks [@ramon-prado](https://github.azc.ext.hp.com/ramon-prado)! - [Components] Change properties types from string to node

- [#5931](https://github.azc.ext.hp.com/veneer/veneer/pull/5931) [`807caeaf2`](https://github.azc.ext.hp.com/veneer/veneer/commit/807caeaf2fe6908781815a40f8ca3db9fa2081ea) Thanks [@tulio-silva](https://github.azc.ext.hp.com/tulio-silva)! - [Icons] Veneer Icons now supports system colors or any hex/rgb string.

  [DatePicker] Fix Component visual bugs.

## 3.91.0

### Minor Changes

- [#5907](https://github.azc.ext.hp.com/veneer/veneer/pull/5907) [`165ed4b49`](https://github.azc.ext.hp.com/veneer/veneer/commit/165ed4b496ffd1e6fa1c3f3c17b920dc973633fd) Thanks [@walter-ferreira](https://github.azc.ext.hp.com/walter-ferreira)! - [Icons] Add Gesture Hand Raised and Person Posture

* [#5846](https://github.azc.ext.hp.com/veneer/veneer/pull/5846) [`7f865ceb5`](https://github.azc.ext.hp.com/veneer/veneer/commit/7f865ceb5558a37e6ba1f6f96930de4db95c92b3) Thanks [@walter-ferreira](https://github.azc.ext.hp.com/walter-ferreira)! - [Icon] Update Ellipsis Icons and Add Ellipsis Vertical icon

- [#5915](https://github.azc.ext.hp.com/veneer/veneer/pull/5915) [`646fce6d9`](https://github.azc.ext.hp.com/veneer/veneer/commit/646fce6d983305f21fcdfce3aa7bd9cdd6e9af9b) Thanks [@ramon-prado](https://github.azc.ext.hp.com/ramon-prado)! - [Icon] Add batch icons

  :new: `IconTextSuperscript`, `IconTextSubscript`

* [#5572](https://github.azc.ext.hp.com/veneer/veneer/pull/5572) [`028304e68`](https://github.azc.ext.hp.com/veneer/veneer/commit/028304e685a4185ba2406737379c1157cbf058ce) Thanks [@jedelston](https://github.azc.ext.hp.com/jedelston)! - [Table] Add translations for active state on sort by.

- [#5856](https://github.azc.ext.hp.com/veneer/veneer/pull/5856) [`b1032f2d4`](https://github.azc.ext.hp.com/veneer/veneer/commit/b1032f2d47ee87435435c80d2be842e1ab9136ba) Thanks [@maria-lima1](https://github.azc.ext.hp.com/maria-lima1)! - [Icons] Add Programmable Key Diamonds, Keyboard Brightness Low, Keyboard Brightness High, Laptop Screen Contrast and Laptop Screen Contrast Auto icons.

* [#5582](https://github.azc.ext.hp.com/veneer/veneer/pull/5582) [`baaad90c1`](https://github.azc.ext.hp.com/veneer/veneer/commit/baaad90c1f25f8decbf53ac66159d94332eb14c9) Thanks [@bruno-chanan](https://github.azc.ext.hp.com/bruno-chanan)! - [List][card][Accordion] Add new border and background props.
  The prop appearance is being deprecated use border or background props instead.

- [#5832](https://github.azc.ext.hp.com/veneer/veneer/pull/5832) [`4dd996151`](https://github.azc.ext.hp.com/veneer/veneer/commit/4dd996151fe979095e7e98b32f2203855600e132) Thanks [@maria-lima1](https://github.azc.ext.hp.com/maria-lima1)! - [Icons] Add Cube Points Play Circle and Cube Points Curved Play Circle Icons.

* [#5892](https://github.azc.ext.hp.com/veneer/veneer/pull/5892) [`0b5558d12`](https://github.azc.ext.hp.com/veneer/veneer/commit/0b5558d1295294f7812d0547431ce21940052fa6) Thanks [@ramon-prado](https://github.azc.ext.hp.com/ramon-prado)! - [Icons] Add HP PageWide Advantage

- [#5912](https://github.azc.ext.hp.com/veneer/veneer/pull/5912) [`608893733`](https://github.azc.ext.hp.com/veneer/veneer/commit/6088937333b4b9b94b395c8d6830185f3d2273b3) Thanks [@ramon-prado](https://github.azc.ext.hp.com/ramon-prado)! - [Icon] Share icon

### Patch Changes

- [#5906](https://github.azc.ext.hp.com/veneer/veneer/pull/5906) [`889c8f465`](https://github.azc.ext.hp.com/veneer/veneer/commit/889c8f465c8f4c6ceeeb30371986049411a43275) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - [Scrollbar] Fix scrollbar appearance on Chrome 121

## 3.90.0

### Minor Changes

- [#5846](https://github.azc.ext.hp.com/veneer/veneer/pull/5846) [`7f865ceb55`](https://github.azc.ext.hp.com/veneer/veneer/commit/7f865ceb5558a37e6ba1f6f96930de4db95c92b3) Thanks [@walter-ferreira](https://github.azc.ext.hp.com/walter-ferreira)! - [Icon] Update Ellipsis Icons and Add Ellipsis Vertical icon

* [#5856](https://github.azc.ext.hp.com/veneer/veneer/pull/5856) [`b1032f2d47`](https://github.azc.ext.hp.com/veneer/veneer/commit/b1032f2d47ee87435435c80d2be842e1ab9136ba) Thanks [@maria-lima1](https://github.azc.ext.hp.com/maria-lima1)! - [Icons] Add Programmable Key Diamonds, Keyboard Brightness Low, Keyboard Brightness High, Laptop Screen Contrast and Laptop Screen Contrast Auto icons.

- [#5582](https://github.azc.ext.hp.com/veneer/veneer/pull/5582) [`baaad90c1f`](https://github.azc.ext.hp.com/veneer/veneer/commit/baaad90c1f25f8decbf53ac66159d94332eb14c9) Thanks [@bruno-chanan](https://github.azc.ext.hp.com/bruno-chanan)! - [List][card][Accordion] Add new border and background props.
  The prop appearance is being deprecated use border or background props instead.

* [#5832](https://github.azc.ext.hp.com/veneer/veneer/pull/5832) [`4dd996151f`](https://github.azc.ext.hp.com/veneer/veneer/commit/4dd996151fe979095e7e98b32f2203855600e132) Thanks [@maria-lima1](https://github.azc.ext.hp.com/maria-lima1)! - [Icons] Add Cube Points Play Circle and Cube Points Curved Play Circle Icons.

### Patch Changes

- [#5882](https://github.azc.ext.hp.com/veneer/veneer/pull/5882) [`d741f01a8d`](https://github.azc.ext.hp.com/veneer/veneer/commit/d741f01a8dfaaa4ae96d325d00f023cee15445bd) Thanks [@veneer-bot](https://github.azc.ext.hp.com/veneer-bot)! - [Scrollbar] Fix scrollbar appearance on Chrome 121

## 3.89.0

### Minor Changes

- [#5643](https://github.azc.ext.hp.com/veneer/veneer/pull/5643) [`251da94e0`](https://github.azc.ext.hp.com/veneer/veneer/commit/251da94e0480b905d40ced57ec5519e3613e431f) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [Coachmark] Make `title`` and`description`` a div and ReactNode, this will allow users to pass any node to the component.

* [#5836](https://github.azc.ext.hp.com/veneer/veneer/pull/5836) [`809bea155`](https://github.azc.ext.hp.com/veneer/veneer/commit/809bea155d43958075a80592fa269eb89d7fad54) Thanks [@maria-lima1](https://github.azc.ext.hp.com/maria-lima1)! - [Icon] Update Ink Cartridge Help Sharp Lined Icon

- [#5831](https://github.azc.ext.hp.com/veneer/veneer/pull/5831) [`4ef92a8f5`](https://github.azc.ext.hp.com/veneer/veneer/commit/4ef92a8f5acc112b132fc75f90e60e29fc4cc412) Thanks [@maria-lima1](https://github.azc.ext.hp.com/maria-lima1)! - [Icons] Add Log Page Checklist icon

* [#5786](https://github.azc.ext.hp.com/veneer/veneer/pull/5786) [`5e83c2e09`](https://github.azc.ext.hp.com/veneer/veneer/commit/5e83c2e0958c5f6473a83452d89221a1d92f6367) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [Accordion] Translate chevron

- [#5833](https://github.azc.ext.hp.com/veneer/veneer/pull/5833) [`d50706a60`](https://github.azc.ext.hp.com/veneer/veneer/commit/d50706a606be5637e34a7bb9179c136539127cef) Thanks [@maria-lima1](https://github.azc.ext.hp.com/maria-lima1)! - [Icon] Add Monitor Warning and Monitor Warning Circle icons

* [#5801](https://github.azc.ext.hp.com/veneer/veneer/pull/5801) [`c0b9b4d13`](https://github.azc.ext.hp.com/veneer/veneer/commit/c0b9b4d136a2a5f63536d5fba9a873e002a09e70) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - [Checkbox] Fix keyboard trap on controlled checkbox

- [#5808](https://github.azc.ext.hp.com/veneer/veneer/pull/5808) [`f2af3cbdc`](https://github.azc.ext.hp.com/veneer/veneer/commit/f2af3cbdc730102c3e7dad8e00e9227e9970f475) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [Select] Update select multiple icons when hovering.

* [#5829](https://github.azc.ext.hp.com/veneer/veneer/pull/5829) [`6767e8c4d`](https://github.azc.ext.hp.com/veneer/veneer/commit/6767e8c4dd000b0f1ba4529288fb99da04aa0ec7) Thanks [@maria-lima1](https://github.azc.ext.hp.com/maria-lima1)! - [Icons] Add Sliders Square and Sliders Square Checkmark Circle Icons.

- [#5835](https://github.azc.ext.hp.com/veneer/veneer/pull/5835) [`a933e15ef`](https://github.azc.ext.hp.com/veneer/veneer/commit/a933e15ef60632caf6da1d978d1d0ee411e17eef) Thanks [@walter-ferreira](https://github.azc.ext.hp.com/walter-ferreira)! - [List] Added high density styles

* [#5817](https://github.azc.ext.hp.com/veneer/veneer/pull/5817) [`bfba5865a`](https://github.azc.ext.hp.com/veneer/veneer/commit/bfba5865aad051827f3e253346e2ff861f8f0d03) Thanks [@maria-lima1](https://github.azc.ext.hp.com/maria-lima1)! - [Icons] Add Printer Locked icon

- [#5620](https://github.azc.ext.hp.com/veneer/veneer/pull/5620) [`16451bf39`](https://github.azc.ext.hp.com/veneer/veneer/commit/16451bf3941b4fe1f9b98b23e33ca55079169c1e) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [SegmentedControl] Fix ArrowRight Navigation.

### Patch Changes

- [#5800](https://github.azc.ext.hp.com/veneer/veneer/pull/5800) [`94915652f`](https://github.azc.ext.hp.com/veneer/veneer/commit/94915652fdc7a57d648e5acf6cc06e019890517d) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - [Infra] Update @emotion/serialize imports to be from @emotion/core

* [#5834](https://github.azc.ext.hp.com/veneer/veneer/pull/5834) [`1ea724a26`](https://github.azc.ext.hp.com/veneer/veneer/commit/1ea724a267e8d05c6d08045959385811a7ce06b5) Thanks [@joao-flores-de-leao](https://github.azc.ext.hp.com/joao-flores-de-leao)! - [SideBar] Stroke and padding update for collapsable behavior

- [#5800](https://github.azc.ext.hp.com/veneer/veneer/pull/5800) [`94915652f`](https://github.azc.ext.hp.com/veneer/veneer/commit/94915652fdc7a57d648e5acf6cc06e019890517d) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - [Infra] Ensure third party type packages are marked as dependencies

## 3.88.0

### Minor Changes

- [#5602](https://github.azc.ext.hp.com/veneer/veneer/pull/5602) [`275ba6022`](https://github.azc.ext.hp.com/veneer/veneer/commit/275ba60225f37fdd4036935902c4e283ee9a24d6) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - [Icon] Deprecate IconWifi25, IconWifi50, IconWifi75

* [#5616](https://github.azc.ext.hp.com/veneer/veneer/pull/5616) [`2471849ee`](https://github.azc.ext.hp.com/veneer/veneer/commit/2471849eeaf711fbda2dedb44fe7e097b85c357f) Thanks [@joao-flores-de-leao](https://github.azc.ext.hp.com/joao-flores-de-leao)! - [Select] update of options on Safari now preserves scroll state

### Patch Changes

- [#5565](https://github.azc.ext.hp.com/veneer/veneer/pull/5565) [`caa0eb1d0`](https://github.azc.ext.hp.com/veneer/veneer/commit/caa0eb1d0d8bd3cacb4c10113599662a43f077a9) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - [Infra] Veneer is now built and tested with node 20

* [#5601](https://github.azc.ext.hp.com/veneer/veneer/pull/5601) [`016db5893`](https://github.azc.ext.hp.com/veneer/veneer/commit/016db5893bbb3d45c833c2abbe95a14f1e0102ea) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - [ContextualMenu] Fix active state when using anchorNode

* Updated dependencies [[`122765e2b`](https://github.azc.ext.hp.com/veneer/veneer/commit/122765e2bbd057601597ea64b60c567901b2fcaf)]:
  - @veneer/theme@3.73.0
  - @veneer/highcharts-interface@3.59.1

## 3.87.0

### Minor Changes

- [#5558](https://github.azc.ext.hp.com/veneer/veneer/pull/5558) [`3c2d28c05`](https://github.azc.ext.hp.com/veneer/veneer/commit/3c2d28c058be864186c6d41c24e7a4d0c5207d9e) Thanks [@ramon-prado](https://github.azc.ext.hp.com/ramon-prado)! - [Icons] Cubes, Ink Cartridges, Wifi, Stack Outlines

  :new: `IconCubeConveyorBelt`, `IconCubeDimensions`, `IconCubePerspective`, `IconCubeSideBackLeft`, `IconCubeSideBackRight`, `IconCubeSideBottom`, `IconCubeSideFrontLeft`, `IconCubeSideFrontRight`, `IconCubeSideTop`, `IconInkCartridge`, `IconInkCartridgeCheckmarkCircle`, `IconInkCartridgeHelp`, `IconInkCartridgeMinusCircle`, `IconInkCartridgePauseCircle`, `IconInkCartridgePlusCircle`, `IconInkCartridgeWarning`, `IconInkCartridgeWarningAlt`, `IconInkCartridgeXCircle`, `IconMeasurementDistance`, `IconStackOutline`, `IconStackOutlineHidden`, `IconStackOutlineHiddenPartialLeft`, `IconStackOutlineHiddenPartialRight`, `IconWifiSignal0`, `IconWifiSignal0Locked`, `IconWifiSignal100`, `IconWifiSignal100Locked`, `IconWifiSignal25`, `IconWifiSignal25Locked`, `IconWifiSignal50`, `IconWifiSignal50Locked`, `IconWifiSignal75`, `IconWifiSignal75Locked`, `IconWifiSignalDisconnected`, `IconWifiSignalOff`, `IconWifiSignalWarning`

* [#5585](https://github.azc.ext.hp.com/veneer/veneer/pull/5585) [`70481ae74`](https://github.azc.ext.hp.com/veneer/veneer/commit/70481ae748c89580f940b15bca73f8219bba2e95) Thanks [@bruno-chanan](https://github.azc.ext.hp.com/bruno-chanan)! - [Date Picker] Allow same day selection on both start/end dates.

- [#5589](https://github.azc.ext.hp.com/veneer/veneer/pull/5589) [`cd43e6401`](https://github.azc.ext.hp.com/veneer/veneer/commit/cd43e6401cbc61a0862ee5eead5f051283f28d49) Thanks [@ramon-prado](https://github.azc.ext.hp.com/ramon-prado)! - [Icons] Add Arrows Unify Circle

  :new: `IconArrowsUnifyCircle`

* [#5596](https://github.azc.ext.hp.com/veneer/veneer/pull/5596) [`5636556ba`](https://github.azc.ext.hp.com/veneer/veneer/commit/5636556ba00df7ceeb580f39cb047a42da541edf) Thanks [@ramon-prado](https://github.azc.ext.hp.com/ramon-prado)! - [Icons] Add Pause Ink Icon

  :new: `IconInkPauseCircle`

- [#5557](https://github.azc.ext.hp.com/veneer/veneer/pull/5557) [`db392cecd`](https://github.azc.ext.hp.com/veneer/veneer/commit/db392cecda8f03b29ddf15ae0652114250f8ab6a) Thanks [@ramon-prado](https://github.azc.ext.hp.com/ramon-prado)! - [InlineNotification] Make `onClose` accept undefined id

* [#5588](https://github.azc.ext.hp.com/veneer/veneer/pull/5588) [`2d4e9f281`](https://github.azc.ext.hp.com/veneer/veneer/commit/2d4e9f281c0c32ed3f910a461065f451b4e820cf) Thanks [@ramon-prado](https://github.azc.ext.hp.com/ramon-prado)! - [Icons] Add paper ream open icon

  :new: `IconPaperReamOpen`

### Patch Changes

- [#5544](https://github.azc.ext.hp.com/veneer/veneer/pull/5544) [`9ead481e3`](https://github.azc.ext.hp.com/veneer/veneer/commit/9ead481e318379e848cf0aee6b24545406b677c2) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - [ContextualMenu] Ensure contextual menu button has correct color when open

* [#5603](https://github.azc.ext.hp.com/veneer/veneer/pull/5603) [`0f5c8357e`](https://github.azc.ext.hp.com/veneer/veneer/commit/0f5c8357e964388e584502148dc8c5f32ef7883d) Thanks [@bruno-chanan](https://github.azc.ext.hp.com/bruno-chanan)! - [ContextualMenu] Fix active state when using anchorNode

- [#5544](https://github.azc.ext.hp.com/veneer/veneer/pull/5544) [`9ead481e3`](https://github.azc.ext.hp.com/veneer/veneer/commit/9ead481e318379e848cf0aee6b24545406b677c2) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - [NotificationCenter] Ensure notification center button has correct color when open

## 3.86.0

### Minor Changes

- [#5547](https://github.azc.ext.hp.com/veneer/veneer/pull/5547) [`6bf6b77a00`](https://github.azc.ext.hp.com/veneer/veneer/commit/6bf6b77a002e1b57000b6d91c49d45dc848159c9) Thanks [@bruno-chanan](https://github.azc.ext.hp.com/bruno-chanan)! - [Icon] Add new icons

  - 🆕 New icons: `IconCollection`, `IconTeleconference`

* [#5471](https://github.azc.ext.hp.com/veneer/veneer/pull/5471) [`f9552ce040`](https://github.azc.ext.hp.com/veneer/veneer/commit/f9552ce040ea717395da24f2d7c10967e6620c61) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - [Infra] Add `useSafeTimeout` hook

  Plus a linting rule to enforce its use over direct `setTimeout` calls.

  The `useSafeTimeout` hook creates a timeout which is guaranteed to be
  cleaned out on component unmount.

### Patch Changes

- [#5348](https://github.azc.ext.hp.com/veneer/veneer/pull/5348) [`9fd80ee1b6`](https://github.azc.ext.hp.com/veneer/veneer/commit/9fd80ee1b6e23e102389e6a6be690a51ecb35aff) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - [Infra] Installing veneer will no longer generate warnings about mismatched peer dependencies

* [#5480](https://github.azc.ext.hp.com/veneer/veneer/pull/5480) [`36cc88df1e`](https://github.azc.ext.hp.com/veneer/veneer/commit/36cc88df1e7de4ba220b9927c7f8575e4483317c) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - [ToastNotification] Remove ability for toasts to manage their own state

  This greatly simplifies their code. `ToastNotifications` should not be instantiated by themselves, but left to `ToastProvider` to create.

* Updated dependencies [[`f9aebab19c`](https://github.azc.ext.hp.com/veneer/veneer/commit/f9aebab19ca99145c8ea4362981dd8145d9d505d)]:
  - @veneer/highcharts-interface@3.59.0

## 3.85.0

### Minor Changes

- [#5455](https://github.azc.ext.hp.com/veneer/veneer/pull/5455) [`f90a410150`](https://github.azc.ext.hp.com/veneer/veneer/commit/f90a41015039222cf0babcabdfe99dfd8d57cfba) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [DatePicker] Add `monthYearNavigation` to range input.

* [#5468](https://github.azc.ext.hp.com/veneer/veneer/pull/5468) [`7fc61591b8`](https://github.azc.ext.hp.com/veneer/veneer/commit/7fc61591b8c6a09c8861790d192f7fba3ae6ad2a) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - [Logo] Add stacked variant of HP Instant Ink logo

- [#5414](https://github.azc.ext.hp.com/veneer/veneer/pull/5414) [`6dd9d0e3ad`](https://github.azc.ext.hp.com/veneer/veneer/commit/6dd9d0e3ad17950e76630024074f6d888c2be0c2) Thanks [@bruno-chanan](https://github.azc.ext.hp.com/bruno-chanan)! - [Tooltip] Arrow size and space modifications.

* [#5458](https://github.azc.ext.hp.com/veneer/veneer/pull/5458) [`ef69a228ae`](https://github.azc.ext.hp.com/veneer/veneer/commit/ef69a228ae588ff625a34b564fc2410370bfb172) Thanks [@bruno-chanan](https://github.azc.ext.hp.com/bruno-chanan)! - [Select] Update interactive states.

- [#5474](https://github.azc.ext.hp.com/veneer/veneer/pull/5474) [`ead2a3f60d`](https://github.azc.ext.hp.com/veneer/veneer/commit/ead2a3f60de18c41464293205c72ffd920a2bda0) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [TreeView] Update borderRadius on high density.

### Patch Changes

- [#5466](https://github.azc.ext.hp.com/veneer/veneer/pull/5466) [`11667f13bd`](https://github.azc.ext.hp.com/veneer/veneer/commit/11667f13bd262d2cffd5d8dc7c21fa617285fbb2) Thanks [@joao-flores-de-leao](https://github.azc.ext.hp.com/joao-flores-de-leao)! - [SideMenu] Opening animation avoids truncation of labels.

- Updated dependencies [[`7fc61591b8`](https://github.azc.ext.hp.com/veneer/veneer/commit/7fc61591b8c6a09c8861790d192f7fba3ae6ad2a), [`ead2a3f60d`](https://github.azc.ext.hp.com/veneer/veneer/commit/ead2a3f60de18c41464293205c72ffd920a2bda0)]:
  - @veneer/logos@3.2.0
  - @veneer/theme@3.72.0

## 3.84.0

### Minor Changes

- [#5412](https://github.azc.ext.hp.com/veneer/veneer/pull/5412) [`cd698732d9`](https://github.azc.ext.hp.com/veneer/veneer/commit/cd698732d9bc3a3f068690cd64927612c0d22887) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [Pagination] Add `responsiveBreakpoint` prop. It defines where the Pagination enter responsive mode.

* [#5386](https://github.azc.ext.hp.com/veneer/veneer/pull/5386) [`3e98039103`](https://github.azc.ext.hp.com/veneer/veneer/commit/3e980391031fcedcf920785bb933f5749f72e433) Thanks [@bruno-chanan](https://github.azc.ext.hp.com/bruno-chanan)! - [Password] Convert source files to typescript.

- [#5421](https://github.azc.ext.hp.com/veneer/veneer/pull/5421) [`bb3be63ef3`](https://github.azc.ext.hp.com/veneer/veneer/commit/bb3be63ef3d98e5f174ca9df208bf1f08bd867e3) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [TreeView] Add `minWidth: 256px` to component.

* [#5436](https://github.azc.ext.hp.com/veneer/veneer/pull/5436) [`9f527767b8`](https://github.azc.ext.hp.com/veneer/veneer/commit/9f527767b808397ba848841c430ffc4eb1ece956) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [Password] Update focus behavior. When clicking on the eye button, the password hides the icon and now loses focus.

- [#5424](https://github.azc.ext.hp.com/veneer/veneer/pull/5424) [`1ebd9c926d`](https://github.azc.ext.hp.com/veneer/veneer/commit/1ebd9c926dc637efb4695742ca5ae25094c7f5a3) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [Icons] Update placeholder icon when there is no shape available.

* [#5439](https://github.azc.ext.hp.com/veneer/veneer/pull/5439) [`b0819af6cd`](https://github.azc.ext.hp.com/veneer/veneer/commit/b0819af6cd1e0c8f60e0af947458c5689880fce0) Thanks [@ramon-prado](https://github.azc.ext.hp.com/ramon-prado)! - [Icons] Add tag title to clear funnel SVGs

- [#5320](https://github.azc.ext.hp.com/veneer/veneer/pull/5320) [`7e7914043e`](https://github.azc.ext.hp.com/veneer/veneer/commit/7e7914043eb969c91572d35c83ae386bd91db22f) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - [Table] Update sources to typescript

* [#5321](https://github.azc.ext.hp.com/veneer/veneer/pull/5321) [`75eb8dcc22`](https://github.azc.ext.hp.com/veneer/veneer/commit/75eb8dcc227903051751da0a9006a05a52206c0f) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [SideMenu] Convert source files to typescript.

- [#5357](https://github.azc.ext.hp.com/veneer/veneer/pull/5357) [`ae7b94ebf6`](https://github.azc.ext.hp.com/veneer/veneer/commit/ae7b94ebf69563458e210f3b4797aa0f52f3cc22) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [FilePicker] Convert source files to typescript.

* [#5437](https://github.azc.ext.hp.com/veneer/veneer/pull/5437) [`2b792f16f8`](https://github.azc.ext.hp.com/veneer/veneer/commit/2b792f16f8e74bc20e0c54b4480a13cf537110ea) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [InlineNotification] Remove 20px marginBottom from component root.

- [#5431](https://github.azc.ext.hp.com/veneer/veneer/pull/5431) [`8af0d73ca7`](https://github.azc.ext.hp.com/veneer/veneer/commit/8af0d73ca7957d9279e48aa3ad99c24a3a633415) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - [Pagination] Pagination component respects current locale

  The Pagination component will now format page and item numbers based on the locale from the current `DirectionProvider`.

* [#5380](https://github.azc.ext.hp.com/veneer/veneer/pull/5380) [`062428b77d`](https://github.azc.ext.hp.com/veneer/veneer/commit/062428b77d3cefa178fbe40c5a310c981f92319b) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [Stepper] Update sources to typescript.

- [#5433](https://github.azc.ext.hp.com/veneer/veneer/pull/5433) [`223e173389`](https://github.azc.ext.hp.com/veneer/veneer/commit/223e173389781e9b9785e80aaf50b74b2bef7100) Thanks [@joao-flores-de-leao](https://github.azc.ext.hp.com/joao-flores-de-leao)! - [List][accordion] Property gutter type updated for consistency.

### Patch Changes

- [#5435](https://github.azc.ext.hp.com/veneer/veneer/pull/5435) [`99c30e56e3`](https://github.azc.ext.hp.com/veneer/veneer/commit/99c30e56e3f50476e95fa0bf02aa3c326d889471) Thanks [@joao-flores-de-leao](https://github.azc.ext.hp.com/joao-flores-de-leao)! - [Accordion][list] Border radius adapts to high-density mode.

* [#5445](https://github.azc.ext.hp.com/veneer/veneer/pull/5445) [`d325eae3c4`](https://github.azc.ext.hp.com/veneer/veneer/commit/d325eae3c49593731c0cf97068dcb643033abbad) Thanks [@joao-flores-de-leao](https://github.azc.ext.hp.com/joao-flores-de-leao)! - [Coachmark] Border radius corrected for SD and HD.

* Updated dependencies [[`ab6deb6266`](https://github.azc.ext.hp.com/veneer/veneer/commit/ab6deb62662e42be1d4f18f5c6cf808536ac11b4)]:
  - @veneer/logos@3.1.1

## 3.83.1

### Patch Changes

- [#5451](https://github.azc.ext.hp.com/veneer/veneer/pull/5451) [`211566c978`](https://github.azc.ext.hp.com/veneer/veneer/commit/211566c97805d85365d078d9c2a5d5b2c099653a) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - [Infra] Ensure types are not exported in js

  Some earlier builds had types reexported from compiled javascript files as they were not marked explicitly as
  types.

## 3.83.0

### Minor Changes

- [#5304](https://github.azc.ext.hp.com/veneer/veneer/pull/5304) [`6ac33f1a7f`](https://github.azc.ext.hp.com/veneer/veneer/commit/6ac33f1a7f62debcaef13e7efd81b0fed45b69ac) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - [DatePicker] Update sources to typescript

  This involved updating a few types in the interface to harmonise them with the underlying third party libraries. There
  are no behavioural changes.

* [#5301](https://github.azc.ext.hp.com/veneer/veneer/pull/5301) [`7a21c5cb96`](https://github.azc.ext.hp.com/veneer/veneer/commit/7a21c5cb96a6d92ae64c37e1b4c3a20ba945eef2) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - [MenuList] Update menu list sources to typescript

  This change removes a number of properties on `MenuItem` and `MenuSection` that were only used internally.

- [#5392](https://github.azc.ext.hp.com/veneer/veneer/pull/5392) [`370e7dbaa4`](https://github.azc.ext.hp.com/veneer/veneer/commit/370e7dbaa4a3e96f0f877ffe06946ce2e6545007) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - [Button] `filled` prop of icons will be respected

  Previously, the `filled` prop of icons passed into a `Button` component was overridden by the hover state. This has been
  fixed so that if `filled` is set to `true`, the icon will remain filled even when the button is not hovered.

* [#5307](https://github.azc.ext.hp.com/veneer/veneer/pull/5307) [`93a7687c70`](https://github.azc.ext.hp.com/veneer/veneer/commit/93a7687c705912b57496f84c28d62161165b9025) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - [Flags] Update flag sources to use typescript

  This also updates the sources for the flags which updates about 24 flags and adds eight new ones.

- [#5301](https://github.azc.ext.hp.com/veneer/veneer/pull/5301) [`7a21c5cb96`](https://github.azc.ext.hp.com/veneer/veneer/commit/7a21c5cb96a6d92ae64c37e1b4c3a20ba945eef2) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - [ContextualMenu] Update sources to typescript

* [#5302](https://github.azc.ext.hp.com/veneer/veneer/pull/5302) [`2e2b4df516`](https://github.azc.ext.hp.com/veneer/veneer/commit/2e2b4df516f4782b373731eff02a705bc1d511d1) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - [Coachmark][toastnotification][Tooltip] Update sources to typescript.

- [#5387](https://github.azc.ext.hp.com/veneer/veneer/pull/5387) [`c74a54d4d5`](https://github.azc.ext.hp.com/veneer/veneer/commit/c74a54d4d5f06dc2e2c66f2047b9fed6030acb64) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - [Logo] HP Logo now defaults to blue background

* [#5393](https://github.azc.ext.hp.com/veneer/veneer/pull/5393) [`9a90b12f45`](https://github.azc.ext.hp.com/veneer/veneer/commit/9a90b12f4578536f10fda983fa0807afea1179d5) Thanks [@joao-flores-de-leao](https://github.azc.ext.hp.com/joao-flores-de-leao)! - [List] New dropShadow and outlined appearances.

- [#5345](https://github.azc.ext.hp.com/veneer/veneer/pull/5345) [`96a359817f`](https://github.azc.ext.hp.com/veneer/veneer/commit/96a359817f18067a7c56c2b22d6ed2856f9e5eb3) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - [DirectionProvider] Convert direction provider sources to typescript

* [#5328](https://github.azc.ext.hp.com/veneer/veneer/pull/5328) [`f5e53b8c03`](https://github.azc.ext.hp.com/veneer/veneer/commit/f5e53b8c03d9c9db358c9ff7889d8e29f4e38de8) Thanks [@bruno-chanan](https://github.azc.ext.hp.com/bruno-chanan)! - [Toggle] Convert source files to typescript.

- [#5263](https://github.azc.ext.hp.com/veneer/veneer/pull/5263) [`a36a264f63`](https://github.azc.ext.hp.com/veneer/veneer/commit/a36a264f632edc184d8dd01622b7595bd10dddff) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [Typescript][appheader] Convert source files to typescript.

* [#5404](https://github.azc.ext.hp.com/veneer/veneer/pull/5404) [`a7cc1eba63`](https://github.azc.ext.hp.com/veneer/veneer/commit/a7cc1eba6371fc48d500aeb3c1f7835a31cc326a) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [Icons] Add IconsBookPages to library.

- [#5336](https://github.azc.ext.hp.com/veneer/veneer/pull/5336) [`ba0c675581`](https://github.azc.ext.hp.com/veneer/veneer/commit/ba0c67558105d1997fbb654ff1ff758b09fb06a6) Thanks [@joao-flores-de-leao](https://github.azc.ext.hp.com/joao-flores-de-leao)! - [AnchorMenu] Component converted to typescript

* [#5332](https://github.azc.ext.hp.com/veneer/veneer/pull/5332) [`9993633591`](https://github.azc.ext.hp.com/veneer/veneer/commit/999363359191418529d365b57e3474b6b252c76a) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - [Select] Update sources to typescript

- [#5312](https://github.azc.ext.hp.com/veneer/veneer/pull/5312) [`c24a40f209`](https://github.azc.ext.hp.com/veneer/veneer/commit/c24a40f2094578faf9d217aa52832817d9d16f3c) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - [NotificationCenter] Update sources to typescript

### Patch Changes

- [#5409](https://github.azc.ext.hp.com/veneer/veneer/pull/5409) [`b6ac19a251`](https://github.azc.ext.hp.com/veneer/veneer/commit/b6ac19a251c62da6369a8fe86b01baa0d3406347) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - [NotificationCenter] Long notifications will no longer overlap read badges

* [#5406](https://github.azc.ext.hp.com/veneer/veneer/pull/5406) [`a562b7b45a`](https://github.azc.ext.hp.com/veneer/veneer/commit/a562b7b45a2ba18779195ce4f0fa73187074c0c8) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - [Chart] Re-add missing useChartContext export

- [#5417](https://github.azc.ext.hp.com/veneer/veneer/pull/5417) [`0cad46e0e0`](https://github.azc.ext.hp.com/veneer/veneer/commit/0cad46e0e03aa55e575622be2c0ac1d7f9392937) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - [Select] Select popover respects high contrast background

* [#5392](https://github.azc.ext.hp.com/veneer/veneer/pull/5392) [`370e7dbaa4`](https://github.azc.ext.hp.com/veneer/veneer/commit/370e7dbaa4a3e96f0f877ffe06946ce2e6545007) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - [NotificationCenter] Support buttons wrapped in `NotificationBadge`

  If a `NotificationCenter` is passed a `Button` wrapped in a `NotificationBadge`, it incorrectly passed its modified
  `Button` props to the `NotificationBadge`. It now correctly passes the props to the `Button` inside the `NotificationBadge`.

* Updated dependencies [[`2e2b4df516`](https://github.azc.ext.hp.com/veneer/veneer/commit/2e2b4df516f4782b373731eff02a705bc1d511d1)]:
  - @veneer/theme@3.71.1

## 3.82.0

### Minor Changes

- [#5333](https://github.azc.ext.hp.com/veneer/veneer/pull/5333) [`529244b5c`](https://github.azc.ext.hp.com/veneer/veneer/commit/529244b5c737321efd2e99bcacdabb4ab633e7ad) Thanks [@joao-flores-de-leao](https://github.azc.ext.hp.com/joao-flores-de-leao)! - [TreeView] Word break for long words.

* [#5358](https://github.azc.ext.hp.com/veneer/veneer/pull/5358) [`d6f599d88`](https://github.azc.ext.hp.com/veneer/veneer/commit/d6f599d8889f9f91af730617f22ef54ea2fdf64a) Thanks [@joao-flores-de-leao](https://github.azc.ext.hp.com/joao-flores-de-leao)! - [TextArea] Overflow behavior of label fixed.

- [#5375](https://github.azc.ext.hp.com/veneer/veneer/pull/5375) [`d99a0b42d`](https://github.azc.ext.hp.com/veneer/veneer/commit/d99a0b42d68b91039fc5d08804c7e64ad60f5b37) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - [Icon] Add new icons

  - 🆕 New icons: `IconProgrammableKey`, `IconShareCircle`

* [#5310](https://github.azc.ext.hp.com/veneer/veneer/pull/5310) [`088273039`](https://github.azc.ext.hp.com/veneer/veneer/commit/088273039fb285896ddf2c9eb169bca095d13eb5) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [RadioButton] Convert source files to typescript.

- [#5397](https://github.azc.ext.hp.com/veneer/veneer/pull/5397) [`8f0286084`](https://github.azc.ext.hp.com/veneer/veneer/commit/8f0286084602e9c733d467f829d816ffed681dab) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [Tokens] Consume new tokens package. If your project use tokens outside components, [consider reading this how to migrate guide](https://stackoverflow.hp.dev/articles/6485).

* [#5370](https://github.azc.ext.hp.com/veneer/veneer/pull/5370) [`cb55743f0`](https://github.azc.ext.hp.com/veneer/veneer/commit/cb55743f048f8cdbb97250bd447a7d551f4dfacd) Thanks [@joao-flores-de-leao](https://github.azc.ext.hp.com/joao-flores-de-leao)! - [DatePicker][textbox] Click on the trailing icon focus on the component.

### Patch Changes

- [#5351](https://github.azc.ext.hp.com/veneer/veneer/pull/5351) [`f89dfefc0`](https://github.azc.ext.hp.com/veneer/veneer/commit/f89dfefc0cf05bf78219059a11e3039e44a40d87) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - [Accordion] Update chevron icon color to background default

* [#5338](https://github.azc.ext.hp.com/veneer/veneer/pull/5338) [`2f80e9ffa`](https://github.azc.ext.hp.com/veneer/veneer/commit/2f80e9ffa70e971d59043ada0e611b99bdcd851b) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - [Infra] Update skeleton package

  This should offer a small performance improvement in the table loading skeleton

- [#5341](https://github.azc.ext.hp.com/veneer/veneer/pull/5341) [`f09362b7e`](https://github.azc.ext.hp.com/veneer/veneer/commit/f09362b7e24f433c1d4a5217c23f71db78ad2a41) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - [Chart] Chart components moved to `@veneer/highcharts-interface` package

  Chart components can still be imported from `@veneer/core` but will be moved in a future release.

- Updated dependencies [[`8f0286084`](https://github.azc.ext.hp.com/veneer/veneer/commit/8f0286084602e9c733d467f829d816ffed681dab)]:
  - @veneer/styles@3.58.0
  - @veneer/theme@3.71.0

## 3.81.1

### Patch Changes

- [#5371](https://github.azc.ext.hp.com/veneer/veneer/pull/5371) [`e3000a308`](https://github.azc.ext.hp.com/veneer/veneer/commit/e3000a30866e59f125cb822f6cbcdef36db2041c) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - [Infra] Hotfix to correct logos installation under `veneer/core`.

## 3.81.0

### Minor Changes

- [#5324](https://github.azc.ext.hp.com/veneer/veneer/pull/5324) [`d66af0d5d`](https://github.azc.ext.hp.com/veneer/veneer/commit/d66af0d5d31a8a9412c631d4e4896c07dd9eb271) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [Icon] Add new Icons to library:
  🆕 IconBandage, IconBirthdayCakeCandles, IconBuildingWithFlag, IconDuckCrayon, IconEarthAmericas, IconEarthAsiaOceania, IconEarthEuropeAfrica, IconFireworks, IconGraduationCap, IconHearthCard, IconHearthFlag, IconHearthSticker, IconMan, IconMazeSquare, IconPaintbrush, IconSchoolSupplies, IconSugarSkull, IconTulip, IconWoman.

* [#5278](https://github.azc.ext.hp.com/veneer/veneer/pull/5278) [`b8c443ed4`](https://github.azc.ext.hp.com/veneer/veneer/commit/b8c443ed49fc8df9e035f8fe6e37cc701d2d9522) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - [Logo] New `@veneer/logos` package

  The new `@veneer/logos` package contains SVG logos for the following brands:

  - HP
  - HP+ (with and without 'Print Plans')
  - Instant Ink (with and without logo)
  - Omen (default, horizontal and vertical alignment)
  - Poly
  - Veneer (with & without text)

  Each SVG contains four color variants

  - `singlecolor` or `multicolor`

  _and_

  - `onLight` or `onDark` background

  This can be referenced using fragment identifiers: `<img src="@veneer/logos/hp/hp.svg#singlecolor-onLight" />`.

  New React wrappers are available in `@veneer/core`. In order to comply with brand guidelines they have a slightly reduced
  API; it is now not possible to set a custom color or the disabled state on them. Otherwise they should be compatible with
  current usage. By default, these logos will now automatically respond to the current `ThemeProvider` and select the
  appropriate variant for the background.

  ⚠️ If required, the old logos in the `@veneer/core` package are still available as deprecated versions. For example, the old HP logo
  is available as `<DeprecatedLogoHp />`. However, these will be removed in an upcoming release.

  In order to use these logos you will need to have an appropriate loader configured for your bundler. For instance, in Webpack:

  ```js
  {
    module: {
      rules: [
        {
          test: /\.svg$/i,
          type: "asset/resource",
        },
      ];
    }
  }
  ```

  You are likely to already have a similar loader configured for Veneer fonts.

- [#5331](https://github.azc.ext.hp.com/veneer/veneer/pull/5331) [`8bb1a135e`](https://github.azc.ext.hp.com/veneer/veneer/commit/8bb1a135e44fdc1b0ebd4907f64a7637810e461d) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [SideBar] Convert source files to typescript.

* [#5335](https://github.azc.ext.hp.com/veneer/veneer/pull/5335) [`dff4fe454`](https://github.azc.ext.hp.com/veneer/veneer/commit/dff4fe454f7b5edcdaa911cdbb27b0e6be7d65b6) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [CssBaseline] Convert source files to typescript.

- [#5308](https://github.azc.ext.hp.com/veneer/veneer/pull/5308) [`22c82a311`](https://github.azc.ext.hp.com/veneer/veneer/commit/22c82a31145804a90853076fe39806a55658d2c2) Thanks [@ramon-prado](https://github.azc.ext.hp.com/ramon-prado)! - [Stepper] Fix spacing between label and circle

* [#5313](https://github.azc.ext.hp.com/veneer/veneer/pull/5313) [`f96d8ab47`](https://github.azc.ext.hp.com/veneer/veneer/commit/f96d8ab478a5e75eca5bf8e15a371daa705e62c4) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [Slider] Convert source files to typescript.

- [#5323](https://github.azc.ext.hp.com/veneer/veneer/pull/5323) [`8a1a3975c`](https://github.azc.ext.hp.com/veneer/veneer/commit/8a1a3975c9355ad7a139a9bb53e6f95d5a95a8fa) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [Tag] Convert source files to typescript.

* [#5287](https://github.azc.ext.hp.com/veneer/veneer/pull/5287) [`92713ca51`](https://github.azc.ext.hp.com/veneer/veneer/commit/92713ca51f73b0bcad0c81932ed94b801cbf4c8a) Thanks [@joao-flores-de-leao](https://github.azc.ext.hp.com/joao-flores-de-leao)! - [Breadcrumbs] Convert files to typescript.

- [#5318](https://github.azc.ext.hp.com/veneer/veneer/pull/5318) [`330c4a01a`](https://github.azc.ext.hp.com/veneer/veneer/commit/330c4a01a8771b77326df8fd53e02f7b0e617bff) Thanks [@joao-flores-de-leao](https://github.azc.ext.hp.com/joao-flores-de-leao)! - [Checkbox] Double trigger when keydown removed.

* [#5323](https://github.azc.ext.hp.com/veneer/veneer/pull/5323) [`8a1a3975c`](https://github.azc.ext.hp.com/veneer/veneer/commit/8a1a3975c9355ad7a139a9bb53e6f95d5a95a8fa) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [TreeView] Update TreeView sources to use typescript

- [#5335](https://github.azc.ext.hp.com/veneer/veneer/pull/5335) [`dff4fe454`](https://github.azc.ext.hp.com/veneer/veneer/commit/dff4fe454f7b5edcdaa911cdbb27b0e6be7d65b6) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [ButtonGroup] Convert source files to typescript.

* [#5305](https://github.azc.ext.hp.com/veneer/veneer/pull/5305) [`b9a2b76af`](https://github.azc.ext.hp.com/veneer/veneer/commit/b9a2b76af612a0340e710056249a637399e0cbd9) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - [Search][textbox][TextArea] Update sources to typescript

### Patch Changes

- [#5316](https://github.azc.ext.hp.com/veneer/veneer/pull/5316) [`5e00d4f67`](https://github.azc.ext.hp.com/veneer/veneer/commit/5e00d4f676fe375fadb86f7b90714a4faa79d0f5) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - [ThemeProvider] Simplified useTheme to improve performance

  The value returned by `useTheme` should now be stable and suitable for use as a dependency in a memo or callback.

- Updated dependencies [[`b8c443ed4`](https://github.azc.ext.hp.com/veneer/veneer/commit/b8c443ed49fc8df9e035f8fe6e37cc701d2d9522), [`dff4fe454`](https://github.azc.ext.hp.com/veneer/veneer/commit/dff4fe454f7b5edcdaa911cdbb27b0e6be7d65b6), [`5e00d4f67`](https://github.azc.ext.hp.com/veneer/veneer/commit/5e00d4f676fe375fadb86f7b90714a4faa79d0f5)]:
  - @veneer/logos@3.1.0
  - @veneer/styles@3.57.0
  - @veneer/theme@3.70.1

## 3.80.0

### Minor Changes

- [#5275](https://github.azc.ext.hp.com/veneer/veneer/pull/5275) [`b4410368b`](https://github.azc.ext.hp.com/veneer/veneer/commit/b4410368bb176685d70fb58042a8b1524854e9ab) Thanks [@jedelston](https://github.azc.ext.hp.com/jedelston)! - [SideMenu] Add `aria-label` to label.

* [#5270](https://github.azc.ext.hp.com/veneer/veneer/pull/5270) [`e8253fd92`](https://github.azc.ext.hp.com/veneer/veneer/commit/e8253fd9278bf4e2b3a8718b967e9f380c391c3f) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [SegmentedControl] Convert source files to typescript.

- [#5239](https://github.azc.ext.hp.com/veneer/veneer/pull/5239) [`f5f2bfe4e`](https://github.azc.ext.hp.com/veneer/veneer/commit/f5f2bfe4ef466187677c4ad2d80464fa12b97e1c) Thanks [@ramon-prado](https://github.azc.ext.hp.com/ramon-prado)! - [Pagination] Update pagination sources to use typescript

* [#5238](https://github.azc.ext.hp.com/veneer/veneer/pull/5238) [`e34df9275`](https://github.azc.ext.hp.com/veneer/veneer/commit/e34df92756dd2f3a5cd5ee249949c2b242b9ff4e) Thanks [@joao-flores-de-leao](https://github.azc.ext.hp.com/joao-flores-de-leao)! - [Checkbox] Update checkbox sources to use typescript

- [#5292](https://github.azc.ext.hp.com/veneer/veneer/pull/5292) [`3ccd9a593`](https://github.azc.ext.hp.com/veneer/veneer/commit/3ccd9a593c834d62758de93c5f7062c974e0dc4a) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - [Icon] Add icon batch

  - 🆕 New icons: `IconAtomicStructure`, `IconBaby`, `IconDecoratedEgg`, `IconPen`, `IconPuzzlePiece`

* [#5257](https://github.azc.ext.hp.com/veneer/veneer/pull/5257) [`25a6f8a4e`](https://github.azc.ext.hp.com/veneer/veneer/commit/25a6f8a4e536efb30e6ca54011342277849dc210) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [InlineNotification] Convert source files to typescript.

- [#5276](https://github.azc.ext.hp.com/veneer/veneer/pull/5276) [`22812ace1`](https://github.azc.ext.hp.com/veneer/veneer/commit/22812ace1fc5f2cd94a47870c011c824414bb9a2) Thanks [@jedelston](https://github.azc.ext.hp.com/jedelston)! - [Tooltip] Update `children` and `content` types.

* [#5220](https://github.azc.ext.hp.com/veneer/veneer/pull/5220) [`083e2bd4d`](https://github.azc.ext.hp.com/veneer/veneer/commit/083e2bd4dc0773bf433eaa9e05d863f8003e644d) Thanks [@joao-flores-de-leao](https://github.azc.ext.hp.com/joao-flores-de-leao)! - [Footer] Update footer sources to use typescript

- [#5254](https://github.azc.ext.hp.com/veneer/veneer/pull/5254) [`acf770ec2`](https://github.azc.ext.hp.com/veneer/veneer/commit/acf770ec25f3efd63ae837abf3515b16b843a2fd) Thanks [@ramon-prado](https://github.azc.ext.hp.com/ramon-prado)! - [Icon] Update applications icons

  - ♻️ Updated Icons: `IconApplication`, `IconApplicationCode`, `IconApplicationEye`, `IconApplicationGear`

* [#5262](https://github.azc.ext.hp.com/veneer/veneer/pull/5262) [`24fc1eeae`](https://github.azc.ext.hp.com/veneer/veneer/commit/24fc1eeae9bb6e9373b9df8538e0c6e2b31d5593) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [Modal] Convert sources files to typescript.

- [#5207](https://github.azc.ext.hp.com/veneer/veneer/pull/5207) [`9d936f1cf`](https://github.azc.ext.hp.com/veneer/veneer/commit/9d936f1cf02d21fda7d8a7971e581ac5eada5107) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - [Tabs] Update tabs sources to use typescript

* [#5285](https://github.azc.ext.hp.com/veneer/veneer/pull/5285) [`ffa3ce163`](https://github.azc.ext.hp.com/veneer/veneer/commit/ffa3ce163919b324e88b0288724a1e63875f17e8) Thanks [@bruno-chanan](https://github.azc.ext.hp.com/bruno-chanan)! - [ContextualMenu] Update interactive states.

- [#5216](https://github.azc.ext.hp.com/veneer/veneer/pull/5216) [`b821174f5`](https://github.azc.ext.hp.com/veneer/veneer/commit/b821174f50d8b0405d00ced511ec5f3e2a86d6a5) Thanks [@ramon-prado](https://github.azc.ext.hp.com/ramon-prado)! - [Group] Update group sources to use typescript

* [#5211](https://github.azc.ext.hp.com/veneer/veneer/pull/5211) [`20364c66d`](https://github.azc.ext.hp.com/veneer/veneer/commit/20364c66d34d1d6a74aab3ecb2fc943bf0a56c8d) Thanks [@bruno-chanan](https://github.azc.ext.hp.com/bruno-chanan)! - [Header] Convert source files to typescript.

- [#5267](https://github.azc.ext.hp.com/veneer/veneer/pull/5267) [`38f0130e0`](https://github.azc.ext.hp.com/veneer/veneer/commit/38f0130e07cccea689f505481465af67b6d7cc97) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [List] Convert source files to typescript.

* [#5271](https://github.azc.ext.hp.com/veneer/veneer/pull/5271) [`0e516d6d7`](https://github.azc.ext.hp.com/veneer/veneer/commit/0e516d6d7877ea10bd62368bbc129eb411382b07) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [NotificationBadge] Convert source files to typescript.

- [#5272](https://github.azc.ext.hp.com/veneer/veneer/pull/5272) [`942d2425d`](https://github.azc.ext.hp.com/veneer/veneer/commit/942d2425dcda46e9dc5bab73769273f55547f794) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [ProgressIndicator] Convert source files to typescript.

## 3.79.0

### Minor Changes

- [#5217](https://github.azc.ext.hp.com/veneer/veneer/pull/5217) [`0a2993b8b`](https://github.azc.ext.hp.com/veneer/veneer/commit/0a2993b8b4a3f2ad9846620c7897746b8d4ee3d3) Thanks [@ramon-prado](https://github.azc.ext.hp.com/ramon-prado)! - [Icon] Add batch icons

  🆕 `IconPointerSpeedFast`, `IconPointerSpeedSlow`, `IconPressureHigh`, `IconPressureLow`, `IconRabbit`, `IconTouchpadGesture`, `IconTurtle`, `IconUsbDongleCheckmarkCircle`,
  `IconUsbDongleInfo`, `IconUsbDongleOff`, `IconUsbDongleWarning`, `IconUsbDongleXCircle`

* [#5208](https://github.azc.ext.hp.com/veneer/veneer/pull/5208) [`45ab27a96`](https://github.azc.ext.hp.com/veneer/veneer/commit/45ab27a966a10b8cacb1e81c06c96c526aff5f9b) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - [Button] Update button sources to use typescript

- [#5242](https://github.azc.ext.hp.com/veneer/veneer/pull/5242) [`9c65304ff`](https://github.azc.ext.hp.com/veneer/veneer/commit/9c65304ffa1a682309a478548e074e0986152e4a) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - [Icon] Add icons to library

  - 🆕 New icons: `IconApiCloud`, `IconApiCloudBriefcase`, `IconApiCloudGear`, `IconApiCloudKey`, `IconPenTiltAngleNarrow`, `IconPenTiltAngleWide`,
    `IconPointerSpeed`, `IconPrinterUpgrade`, `IconScrollSpeedFast`, `IconScrollSpeedSlow`, `IconStylusPenPressure`

* [#5195](https://github.azc.ext.hp.com/veneer/veneer/pull/5195) [`a04e48a2d`](https://github.azc.ext.hp.com/veneer/veneer/commit/a04e48a2d1cf8ab04e35eaf1d92cd875235d1f7c) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - [Accordion] Update accordion sources to use typescript

- [#5225](https://github.azc.ext.hp.com/veneer/veneer/pull/5225) [`40b1a76bc`](https://github.azc.ext.hp.com/veneer/veneer/commit/40b1a76bcfc04be8690a91b05b885b61b6e6c869) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [Avatar] Convert source file to typescript.

### Patch Changes

- [#5222](https://github.azc.ext.hp.com/veneer/veneer/pull/5222) [`82a508b96`](https://github.azc.ext.hp.com/veneer/veneer/commit/82a508b96dbfba80d1beb0e3b6d83e3427d00b81) Thanks [@joao-flores-de-leao](https://github.azc.ext.hp.com/joao-flores-de-leao)! - [Password] Spacing of requirements fixed for consistency

## 3.78.0

### Minor Changes

- [#5196](https://github.azc.ext.hp.com/veneer/veneer/pull/5196) [`b9bc28b3a`](https://github.azc.ext.hp.com/veneer/veneer/commit/b9bc28b3a7936488d58cfa9331418242cf981b42) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - Update and add Icons to library.
  - 🆕 New icons: IconCloudDouble

* [#5197](https://github.azc.ext.hp.com/veneer/veneer/pull/5197) [`5d88bd479`](https://github.azc.ext.hp.com/veneer/veneer/commit/5d88bd4799a8690e867504c3b0c69b01ac0cac42) Thanks [@ramon-prado](https://github.azc.ext.hp.com/ramon-prado)! - [Coachmark] Fix arrow position when anchor element is small

  - smaller than 30px

- [#5133](https://github.azc.ext.hp.com/veneer/veneer/pull/5133) [`07c69d2db`](https://github.azc.ext.hp.com/veneer/veneer/commit/07c69d2db819b6f12a58ac04a848e985599b8483) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - [Card] Update card sources to use typescript

* [#5148](https://github.azc.ext.hp.com/veneer/veneer/pull/5148) [`4a0def970`](https://github.azc.ext.hp.com/veneer/veneer/commit/4a0def9701489420fe33926f72c6148f13770afa) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - [Icon] Update Icon sources to use typescript

- [#5188](https://github.azc.ext.hp.com/veneer/veneer/pull/5188) [`3aa384616`](https://github.azc.ext.hp.com/veneer/veneer/commit/3aa3846167f197f84abdf1237df814e667ee4de3) Thanks [@joao-flores-de-leao](https://github.azc.ext.hp.com/joao-flores-de-leao)! - [DatePicker] Add `portal` prop.

* [#5165](https://github.azc.ext.hp.com/veneer/veneer/pull/5165) [`daf147103`](https://github.azc.ext.hp.com/veneer/veneer/commit/daf1471034c067fd769f74c9fe437d12be46d2cb) Thanks [@ramon-prado](https://github.azc.ext.hp.com/ramon-prado)! - [TreeView] Update component with the new Utility Button

### Patch Changes

- Updated dependencies [[`07c69d2db`](https://github.azc.ext.hp.com/veneer/veneer/commit/07c69d2db819b6f12a58ac04a848e985599b8483)]:
  - @veneer/theme@3.70.0

## 3.77.0

### Minor Changes

- [#5160](https://github.azc.ext.hp.com/veneer/veneer/pull/5160) [`eec8b199c`](https://github.azc.ext.hp.com/veneer/veneer/commit/eec8b199c5a165f51ba7e041e6e919964e4d3527) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - Update and add Icons to library.
  - 🆕 New icons: IconDocumentCube, IconEyeClosed, IconHandCurrency, IconHandEarth, IconHourglass, IconInkNotebook, IconPackageRecycle, IconPersonMonitorDistance, IconPiggyBankCoin, IconPlaneGrid, IconPrinterGlobe, IconPrinterRibbon, IconShieldLock, IconStrikethrough
  - ♻ Updated: IconPower

* [#5141](https://github.azc.ext.hp.com/veneer/veneer/pull/5141) [`762d30f04`](https://github.azc.ext.hp.com/veneer/veneer/commit/762d30f04edd59e3e62d4b3aec8b2cecfdfbf64c) Thanks [@ramon-prado](https://github.azc.ext.hp.com/ramon-prado)! - [Table] Added new property `columnReorderFooterAlign`, it defines column options modal footer position e.g. `alignModalFooter="end"`
  [Modal] Added new property `alignFooter`, defines modal footer position

- [#5187](https://github.azc.ext.hp.com/veneer/veneer/pull/5187) [`31fc697ad`](https://github.azc.ext.hp.com/veneer/veneer/commit/31fc697ad9571521656b14de15b680f0a5f516f0) Thanks [@joao-flores-de-leao](https://github.azc.ext.hp.com/joao-flores-de-leao)! - [Stepper] Complete icon is now customizable with checkmark fallback

* [#5136](https://github.azc.ext.hp.com/veneer/veneer/pull/5136) [`c4a908529`](https://github.azc.ext.hp.com/veneer/veneer/commit/c4a9085296412dfccaddbafdc98f6331812bae8e) Thanks [@ramon-prado](https://github.azc.ext.hp.com/ramon-prado)! - [ListItem] Accept trailing and leading props even wrapped by react fragment

## 3.76.0

### Minor Changes

- [#5119](https://github.azc.ext.hp.com/veneer/veneer/pull/5119) [`81e802619`](https://github.azc.ext.hp.com/veneer/veneer/commit/81e802619aa21fd09b2020a6797866fb5a024992) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - [Table] ⚠️ It is now required to update `sortBy` in `TablePreferences` in response to the `onSort` callback, as the table will no longer control this state for you.

* [#5117](https://github.azc.ext.hp.com/veneer/veneer/pull/5117) [`f84468dee`](https://github.azc.ext.hp.com/veneer/veneer/commit/f84468deeac8d8303c26a0e5160c3e2445139359) Thanks [@ramon-prado](https://github.azc.ext.hp.com/ramon-prado)! - [SegmentedControl] Add `responsiveBreakpoint` prop.

- [#5112](https://github.azc.ext.hp.com/veneer/veneer/pull/5112) [`c988bba8d`](https://github.azc.ext.hp.com/veneer/veneer/commit/c988bba8d374ff370a34a23dd3dc5cdfc40bbed1) Thanks [@ramon-prado](https://github.azc.ext.hp.com/ramon-prado)! - [NotificationCenter] Add section borders

* [#5082](https://github.azc.ext.hp.com/veneer/veneer/pull/5082) [`9d0ed6dce`](https://github.azc.ext.hp.com/veneer/veneer/commit/9d0ed6dcebceb6d0ab3b23c0f55ff9672a9d778e) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [Table] Update component to consume system palette.

- [#5054](https://github.azc.ext.hp.com/veneer/veneer/pull/5054) [`29cc31858`](https://github.azc.ext.hp.com/veneer/veneer/commit/29cc3185807dac01d8c8fcc5e428fbb7da168c47) Thanks [@bruno-chanan](https://github.azc.ext.hp.com/bruno-chanan)! - [DatePicker] Update component to consume system palette.

### Patch Changes

- Updated dependencies [[`9d0ed6dce`](https://github.azc.ext.hp.com/veneer/veneer/commit/9d0ed6dcebceb6d0ab3b23c0f55ff9672a9d778e), [`29cc31858`](https://github.azc.ext.hp.com/veneer/veneer/commit/29cc3185807dac01d8c8fcc5e428fbb7da168c47)]:
  - @veneer/theme@3.69.0

## 3.75.0

### Minor Changes

- [#5084](https://github.azc.ext.hp.com/veneer/veneer/pull/5084) [`46e70c1cb`](https://github.azc.ext.hp.com/veneer/veneer/commit/46e70c1cb6f85833e9d10776a35c72c87089f8ca) Thanks [@louise](https://github.azc.ext.hp.com/louise)! - [Footer] Update component to consume system palette

* [#5064](https://github.azc.ext.hp.com/veneer/veneer/pull/5064) [`956863031`](https://github.azc.ext.hp.com/veneer/veneer/commit/9568630315e1da960b9311afe8fca392a142111f) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [NotificationCenter] Update component to consume system palette.

- [#5075](https://github.azc.ext.hp.com/veneer/veneer/pull/5075) [`cb3464297`](https://github.azc.ext.hp.com/veneer/veneer/commit/cb346429777f266803acde7b88a646a0eb07aa5c) Thanks [@joao-flores-de-leao](https://github.azc.ext.hp.com/joao-flores-de-leao)! - [SideMenu] Update borders to match system palette.

* [#5104](https://github.azc.ext.hp.com/veneer/veneer/pull/5104) [`884e4ab01`](https://github.azc.ext.hp.com/veneer/veneer/commit/884e4ab018338ff242035ce45dedb20ca9195e13) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [Password] Update requirements popover with new definitions.

- [#5071](https://github.azc.ext.hp.com/veneer/veneer/pull/5071) [`6042f61a2`](https://github.azc.ext.hp.com/veneer/veneer/commit/6042f61a2de8e408dd637ab7c7f2b170ec1c098c) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [Input] Remove Safari check for disabled state.

* [#5102](https://github.azc.ext.hp.com/veneer/veneer/pull/5102) [`6c948dacf`](https://github.azc.ext.hp.com/veneer/veneer/commit/6c948dacf05368d1c666496340a3c4120cbc940c) Thanks [@louise](https://github.azc.ext.hp.com/louise)! - [Icon] Add Icons to library

  - 🆕 New Icons: IconCircularMenu, IconCubeBoundary, IconCubeLegs, IconCubePointsBriefcase, IconCubePoints, IconMoveAlt, IconScreenCorners, IconStorageDriveDouble, IconStorageDriveSingle, IconTruckClock.

- [#5061](https://github.azc.ext.hp.com/veneer/veneer/pull/5061) [`77613f2c0`](https://github.azc.ext.hp.com/veneer/veneer/commit/77613f2c072b293d9a7724f054ce5eaa5c9f2d31) Thanks [@ramon-prado](https://github.azc.ext.hp.com/ramon-prado)! - [Avatar] Update component to consume new system palette

* [#5069](https://github.azc.ext.hp.com/veneer/veneer/pull/5069) [`5d91e8b77`](https://github.azc.ext.hp.com/veneer/veneer/commit/5d91e8b77f4e979cccbb2364917c08ba135d7c04) Thanks [@louise](https://github.azc.ext.hp.com/louise)! - [Stepper] Update component to consume system palette

- [#5077](https://github.azc.ext.hp.com/veneer/veneer/pull/5077) [`057c3662c`](https://github.azc.ext.hp.com/veneer/veneer/commit/057c3662cca720113355ed83264d70eca788bd17) Thanks [@ramon-prado](https://github.azc.ext.hp.com/ramon-prado)! - [SideMenu] Refactor to improve accessibility

* [#5058](https://github.azc.ext.hp.com/veneer/veneer/pull/5058) [`18e81e5f6`](https://github.azc.ext.hp.com/veneer/veneer/commit/18e81e5f6c974f0c6e7076d4f4b001282a72ad96) Thanks [@louise](https://github.azc.ext.hp.com/louise)! - [AnchorMenu] Update component to consume new system palette.

- [#5074](https://github.azc.ext.hp.com/veneer/veneer/pull/5074) [`33dc94360`](https://github.azc.ext.hp.com/veneer/veneer/commit/33dc943604404a893b71ccacdcd9c03065415539) Thanks [@joao-flores-de-leao](https://github.azc.ext.hp.com/joao-flores-de-leao)! - [Header] Update style to use Veneer system colors

* [#5106](https://github.azc.ext.hp.com/veneer/veneer/pull/5106) [`7d6bb2f7f`](https://github.azc.ext.hp.com/veneer/veneer/commit/7d6bb2f7f8e5e6b7f779e88781fb727989a7466e) Thanks [@ramon-prado](https://github.azc.ext.hp.com/ramon-prado)! - [Search] Update popover style

### Patch Changes

- [#5100](https://github.azc.ext.hp.com/veneer/veneer/pull/5100) [`638bd9a2d`](https://github.azc.ext.hp.com/veneer/veneer/commit/638bd9a2d9f4609b3182833667f3eb329566a2f3) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - [Input] Clicking on separated form labels will now focus the associated input

- Updated dependencies [[`46e70c1cb`](https://github.azc.ext.hp.com/veneer/veneer/commit/46e70c1cb6f85833e9d10776a35c72c87089f8ca), [`956863031`](https://github.azc.ext.hp.com/veneer/veneer/commit/9568630315e1da960b9311afe8fca392a142111f), [`cb3464297`](https://github.azc.ext.hp.com/veneer/veneer/commit/cb346429777f266803acde7b88a646a0eb07aa5c), [`77613f2c0`](https://github.azc.ext.hp.com/veneer/veneer/commit/77613f2c072b293d9a7724f054ce5eaa5c9f2d31), [`18e81e5f6`](https://github.azc.ext.hp.com/veneer/veneer/commit/18e81e5f6c974f0c6e7076d4f4b001282a72ad96), [`33dc94360`](https://github.azc.ext.hp.com/veneer/veneer/commit/33dc943604404a893b71ccacdcd9c03065415539)]:
  - @veneer/theme@3.68.0
  - @veneer/tokens@3.56.0

## 3.74.0

### Minor Changes

- [#5040](https://github.azc.ext.hp.com/veneer/veneer/pull/5040) [`e9cfff688`](https://github.azc.ext.hp.com/veneer/veneer/commit/e9cfff688e1d0eebddc30d194b6611528c10c2ff) Thanks [@kluivert-queiroz1](https://github.azc.ext.hp.com/kluivert-queiroz1)! - [Modal] Added `expanded` and `maxWidth` properties. The `expanded` prop will expand modal a 100% to the `maxWidth`. The `expanded` default value is `true` and the`maxWidth` default value is `calc(400px + ${tokens.space8 + tokens.space4} + ${tokens.space8 + tokens.space4})` to keep retro-compatibility.

* [#5033](https://github.azc.ext.hp.com/veneer/veneer/pull/5033) [`507bc8072`](https://github.azc.ext.hp.com/veneer/veneer/commit/507bc8072d78b38f4317f9df3c85b8aea45ff0fe) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [Button] Add filled state for `trailingIcon`.

- [#5062](https://github.azc.ext.hp.com/veneer/veneer/pull/5062) [`a4db097ef`](https://github.azc.ext.hp.com/veneer/veneer/commit/a4db097ef404d9af1dff98b15d9fedd8cfa7015a) Thanks [@bruno-chanan](https://github.azc.ext.hp.com/bruno-chanan)! - [Icons] Update IconLayoutPictureInPicture label

* [#5052](https://github.azc.ext.hp.com/veneer/veneer/pull/5052) [`7c9933a90`](https://github.azc.ext.hp.com/veneer/veneer/commit/7c9933a903aba7142ab751a539d2d08559b8a0e7) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [Card] Update component to consume new system palette.

- [#5057](https://github.azc.ext.hp.com/veneer/veneer/pull/5057) [`37014f12a`](https://github.azc.ext.hp.com/veneer/veneer/commit/37014f12a7bbac01eab278e1e9524d1202e0da19) Thanks [@bruno-chanan](https://github.azc.ext.hp.com/bruno-chanan)! - [Icons] Add new Global icons
  - 🆕 New icons: IconButtonPointer, IconIdCard, IconTable, IconOpenQuote, IconUsbDongle

* [#5034](https://github.azc.ext.hp.com/veneer/veneer/pull/5034) [`ebb45e8ad`](https://github.azc.ext.hp.com/veneer/veneer/commit/ebb45e8adbea883631e3e86d73559b31c76594a6) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [SegmentedControl] Add `expanded` property.

- [#5042](https://github.azc.ext.hp.com/veneer/veneer/pull/5042) [`f39eeaa87`](https://github.azc.ext.hp.com/veneer/veneer/commit/f39eeaa87db1df83da303d7e519dcb57d83375b5) Thanks [@ramon-prado](https://github.azc.ext.hp.com/ramon-prado)! - [Scrollbar] Update component to consume system palette

### Patch Changes

- Updated dependencies [[`7c9933a90`](https://github.azc.ext.hp.com/veneer/veneer/commit/7c9933a903aba7142ab751a539d2d08559b8a0e7)]:
  - @veneer/theme@3.67.0

## 3.73.0

### Minor Changes

- [#5015](https://github.azc.ext.hp.com/veneer/veneer/pull/5015) [`2cd53f78e`](https://github.azc.ext.hp.com/veneer/veneer/commit/2cd53f78ee463e580370e74021e16eb193aa4672) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [SideMenu] Add `noWrap` property and change normal behavior to break line when needed.
  ⚠️ If your project needs to show ellipsis, add `noWrap` prop to the component.

* [#5023](https://github.azc.ext.hp.com/veneer/veneer/pull/5023) [`073fa800d`](https://github.azc.ext.hp.com/veneer/veneer/commit/073fa800d866df620a86e09b21123e97ea8811b9) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [Select] Add system palette to component.

- [#5026](https://github.azc.ext.hp.com/veneer/veneer/pull/5026) [`a0ece9225`](https://github.azc.ext.hp.com/veneer/veneer/commit/a0ece92256e2c1d68e0837e939a0a280c5bf1dfa) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [Icons] Add and update icons.
  🆕 `IconBatteryEllipsis`, `IconBookPagesDouble`, `IconBookPagesReversedDouble`, `IconBookPagesReversedSingle`, `IconBookPagesSingle`, `IconClipboardEmpty`, `IconDialRound`, `IconFilePath`, `IconWifiMeter`

  ♻️ `IconExportFromFolder`, `IconFileManager`, `IconFolderAdd`, `IconFolderDuplicate`, `IconFolderOpen`, `IconFolderSearch`, `IconFolder`, `IconImportToFolder`, `IconLightBulb`, `IconNetworkFolder`

* [#5020](https://github.azc.ext.hp.com/veneer/veneer/pull/5020) [`34f5d652f`](https://github.azc.ext.hp.com/veneer/veneer/commit/34f5d652f3b5b94b0c4744e382fae07d0a29832d) Thanks [@ramon-prado](https://github.azc.ext.hp.com/ramon-prado)! - [Search] Update component to consume system palette

- [#5021](https://github.azc.ext.hp.com/veneer/veneer/pull/5021) [`2d06c71d0`](https://github.azc.ext.hp.com/veneer/veneer/commit/2d06c71d02021d16d49ccce022c121fe3208966c) Thanks [@louise](https://github.azc.ext.hp.com/louise)! - [SideBar] Update component to consume new system palette.

* [#5019](https://github.azc.ext.hp.com/veneer/veneer/pull/5019) [`3b25a8940`](https://github.azc.ext.hp.com/veneer/veneer/commit/3b25a8940e68dd345ba483870b34ae53a45b0990) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [AppHeader] Update component to consume new system colors.

- [#5013](https://github.azc.ext.hp.com/veneer/veneer/pull/5013) [`a392cde3e`](https://github.azc.ext.hp.com/veneer/veneer/commit/a392cde3ef3a08a9e8f90248cb6dc4eea2b37495) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [Pagination] Update component to consume system palette.

* [#5011](https://github.azc.ext.hp.com/veneer/veneer/pull/5011) [`265411af3`](https://github.azc.ext.hp.com/veneer/veneer/commit/265411af3870b6ef89b2bcc5f8c9750ab47dad81) Thanks [@joao-flores-de-leao](https://github.azc.ext.hp.com/joao-flores-de-leao)! - [Tabs] Redesign to new style

- [#5022](https://github.azc.ext.hp.com/veneer/veneer/pull/5022) [`8d1c8ca70`](https://github.azc.ext.hp.com/veneer/veneer/commit/8d1c8ca70fdb2716689db2027b9e2babd44c35ea) Thanks [@bruno-chanan](https://github.azc.ext.hp.com/bruno-chanan)! - [Coachmark] Update component to consume system palette.

### Patch Changes

- [#5027](https://github.azc.ext.hp.com/veneer/veneer/pull/5027) [`050004f9e`](https://github.azc.ext.hp.com/veneer/veneer/commit/050004f9ec3c21abf8e83457f0c2509abb49a498) Thanks [@joao-flores-de-leao](https://github.azc.ext.hp.com/joao-flores-de-leao)! - [Modal] Focus trap removed

- Updated dependencies [[`073fa800d`](https://github.azc.ext.hp.com/veneer/veneer/commit/073fa800d866df620a86e09b21123e97ea8811b9), [`2d06c71d0`](https://github.azc.ext.hp.com/veneer/veneer/commit/2d06c71d02021d16d49ccce022c121fe3208966c), [`a392cde3e`](https://github.azc.ext.hp.com/veneer/veneer/commit/a392cde3ef3a08a9e8f90248cb6dc4eea2b37495), [`8d1c8ca70`](https://github.azc.ext.hp.com/veneer/veneer/commit/8d1c8ca70fdb2716689db2027b9e2babd44c35ea)]:
  - @veneer/theme@3.66.0

## 3.72.0

### Minor Changes

- [#4991](https://github.azc.ext.hp.com/veneer/veneer/pull/4991) [`df81f5403`](https://github.azc.ext.hp.com/veneer/veneer/commit/df81f5403b02ca28fff2fb3a0ddfde6b4181fa40) Thanks [@kluivert-queiroz1](https://github.azc.ext.hp.com/kluivert-queiroz1)! - [Tooltip] Add `disabled` property.

* [#5006](https://github.azc.ext.hp.com/veneer/veneer/pull/5006) [`4ca0d8f63`](https://github.azc.ext.hp.com/veneer/veneer/commit/4ca0d8f63c903d12cf42c81b827591efdf613fcd) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [DatePicker] Add `portalContainer` to type file.

- [#5003](https://github.azc.ext.hp.com/veneer/veneer/pull/5003) [`a57f66aae`](https://github.azc.ext.hp.com/veneer/veneer/commit/a57f66aae9649aa92e4ebd5142b0cc2f2942bcf8) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [Card] Add `onClick` behavior and `component` property.

* [#5002](https://github.azc.ext.hp.com/veneer/veneer/pull/5002) [`3b5efe46d`](https://github.azc.ext.hp.com/veneer/veneer/commit/3b5efe46dbc896ec5f3106f5ee317b6e2688ea39) Thanks [@ramon-prado](https://github.azc.ext.hp.com/ramon-prado)! - [Icon] Adding Sharp version for Scissors icon.

- [#4994](https://github.azc.ext.hp.com/veneer/veneer/pull/4994) [`cf31bb313`](https://github.azc.ext.hp.com/veneer/veneer/commit/cf31bb313721df8a31402553be9652d0acff8031) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [Select] Add UtilityButton to clear option.

* [#4997](https://github.azc.ext.hp.com/veneer/veneer/pull/4997) [`68b855fa2`](https://github.azc.ext.hp.com/veneer/veneer/commit/68b855fa2dcdccf334f0a19dbb9c4bacdd9ce011) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [InlineNotification] Update component to consume system palette.

- [#4999](https://github.azc.ext.hp.com/veneer/veneer/pull/4999) [`e38cd6efd`](https://github.azc.ext.hp.com/veneer/veneer/commit/e38cd6efdc6e409b9ecec7d94bb0e753fb871c4f) Thanks [@bruno-chanan](https://github.azc.ext.hp.com/bruno-chanan)! - [ToastNotification] Update component to consume system palette.

* [#5010](https://github.azc.ext.hp.com/veneer/veneer/pull/5010) [`6903c284a`](https://github.azc.ext.hp.com/veneer/veneer/commit/6903c284a2bfc992fca6abb7bfcb6e4fe4fd6da3) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [DatePicker] Add UtilityButton to clearIcon and chevrons.

### Patch Changes

- Updated dependencies [[`e38cd6efd`](https://github.azc.ext.hp.com/veneer/veneer/commit/e38cd6efdc6e409b9ecec7d94bb0e753fb871c4f)]:
  - @veneer/theme@3.65.0

## 3.71.0

### Minor Changes

- [#4984](https://github.azc.ext.hp.com/veneer/veneer/pull/4984) [`c99f8c72d`](https://github.azc.ext.hp.com/veneer/veneer/commit/c99f8c72d4a945c05e485e7e0d8395523518027f) Thanks [@bruno-chanan](https://github.azc.ext.hp.com/bruno-chanan)! - [DatePicker] Increase input size on range to accomodate MM/DD/YYYY placeholder

* [#4965](https://github.azc.ext.hp.com/veneer/veneer/pull/4965) [`92e27fe6b`](https://github.azc.ext.hp.com/veneer/veneer/commit/92e27fe6bdc9c2e42899cdca4f2de8cb807d2bfe) Thanks [@bruno-chanan](https://github.azc.ext.hp.com/bruno-chanan)! - [Tooltip] Update component to consume system palette

- [#4963](https://github.azc.ext.hp.com/veneer/veneer/pull/4963) [`da5caf607`](https://github.azc.ext.hp.com/veneer/veneer/commit/da5caf607e23b6407d2a6b77d54b7f1a871e304a) Thanks [@ramon-prado](https://github.azc.ext.hp.com/ramon-prado)! - [List] Update component with system colors.

* [#4952](https://github.azc.ext.hp.com/veneer/veneer/pull/4952) [`e71499d3f`](https://github.azc.ext.hp.com/veneer/veneer/commit/e71499d3f57ed6ef3cf057420309219d8d1a3f7d) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [FilePicker] Update component to consume new system palette.

- [#4967](https://github.azc.ext.hp.com/veneer/veneer/pull/4967) [`8a08c099b`](https://github.azc.ext.hp.com/veneer/veneer/commit/8a08c099b37197c84f41862ebaef783f062e4638) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [Modal] Update component to consume system palette.

* [#4964](https://github.azc.ext.hp.com/veneer/veneer/pull/4964) [`10f31abf7`](https://github.azc.ext.hp.com/veneer/veneer/commit/10f31abf71a3239d5cdf5b972f3f480347d69233) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [NotificationBadge] Update component with new system palette.

- [#4978](https://github.azc.ext.hp.com/veneer/veneer/pull/4978) [`a847dbdc1`](https://github.azc.ext.hp.com/veneer/veneer/commit/a847dbdc15852abf8189abe20b5314c2c4e16dcd) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [Password] Update component to consume new system palette.

* [#4962](https://github.azc.ext.hp.com/veneer/veneer/pull/4962) [`0791e2737`](https://github.azc.ext.hp.com/veneer/veneer/commit/0791e2737dc41c818aa9810269b043e55466fdb1) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [Typography] Prevent potential faux bold/slant across browsers and OSs.

### Patch Changes

- [#4975](https://github.azc.ext.hp.com/veneer/veneer/pull/4975) [`5b570a835`](https://github.azc.ext.hp.com/veneer/veneer/commit/5b570a835ac9f98e755094c3c3931cf54670ca0a) Thanks [@louise](https://github.azc.ext.hp.com/louise)! - [Modal] Fix footer alignment

- Updated dependencies [[`92e27fe6b`](https://github.azc.ext.hp.com/veneer/veneer/commit/92e27fe6bdc9c2e42899cdca4f2de8cb807d2bfe), [`e71499d3f`](https://github.azc.ext.hp.com/veneer/veneer/commit/e71499d3f57ed6ef3cf057420309219d8d1a3f7d), [`8a08c099b`](https://github.azc.ext.hp.com/veneer/veneer/commit/8a08c099b37197c84f41862ebaef783f062e4638), [`a847dbdc1`](https://github.azc.ext.hp.com/veneer/veneer/commit/a847dbdc15852abf8189abe20b5314c2c4e16dcd), [`0791e2737`](https://github.azc.ext.hp.com/veneer/veneer/commit/0791e2737dc41c818aa9810269b043e55466fdb1)]:
  - @veneer/theme@3.64.0
  - @veneer/styles@3.56.0

## 3.70.0

### Minor Changes

- [#4907](https://github.azc.ext.hp.com/veneer/veneer/pull/4907) [`a1ab60253`](https://github.azc.ext.hp.com/veneer/veneer/commit/a1ab602532ddf8fc41709671b3f33fe1c5a45d81) Thanks [@jose-lima](https://github.azc.ext.hp.com/jose-lima)! - [Slider] Update component to consume system palette

* [#4903](https://github.azc.ext.hp.com/veneer/veneer/pull/4903) [`93d58e6b0`](https://github.azc.ext.hp.com/veneer/veneer/commit/93d58e6b0db9da2fc30082c407686a99b068b0df) Thanks [@louise](https://github.azc.ext.hp.com/louise)! - [SideMenu] Update style to use Veneer system colors

- [#4926](https://github.azc.ext.hp.com/veneer/veneer/pull/4926) [`977593e61`](https://github.azc.ext.hp.com/veneer/veneer/commit/977593e61eceac227f9b0783b6eea54e681297f2) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [Table] Ajudst column's width to `200px` when Table has filter and preferences width is smaller.

* [#4945](https://github.azc.ext.hp.com/veneer/veneer/pull/4945) [`413406351`](https://github.azc.ext.hp.com/veneer/veneer/commit/413406351c2befcdf89e29fd4af2f0997bfdf7b0) Thanks [@louise](https://github.azc.ext.hp.com/louise)! - Add Icons to library

  - 🆕 New Icons: IconArrowsMergeHorizontal, IconArrowsMergeVertical, IconArrowsSplitHorizontal, IconArrowsSplitVertical, IconBooks, IconCardWithDualNVMeDrive, IconCardWithQuadNVMeDrive, IconCardWithSingleNVMeDrive, IconCheckboxSelectAll, IconCopyPhoto, IconDegreesCelsius, IconDegreesFahrenheit, IconDevicesKeyboardMouse, IconDevicesLaptopKeyboardMouse, IconDocumentSearch, IconDownloadWarning, IconLayoutColumnLeft, IconMonitorAreaGraph, IconMonitorLineGraph, IconPersonGear, IconPhotoFrame, IconPhotoSlideshow, IconPrinterLargeFormat, IconPushpinVertical, IconScreensaverPhotos, IconShapes2D, IconShapes3D, IconUploadWarning, IconVideoCameraPlusCircle.

- [#4950](https://github.azc.ext.hp.com/veneer/veneer/pull/4950) [`87d187cd5`](https://github.azc.ext.hp.com/veneer/veneer/commit/87d187cd5ab77a882a22d2695415647af4515ec5) Thanks [@louise](https://github.azc.ext.hp.com/louise)! - Add and Update Icons

  - NEW ICONS: IconCardOnPCIeSlot, IconDashboardApplication, IconDocumentChart, IconEmptyPCIeSlot, IconPaste, IconPasteText, IconPencilDraw, IconPrintDoubleSided, IconPrintSingleSided, IconPrinterGear, IconRedactX, IconScissors, IconUSBCable, IconUSBCableSlashCircle.
  - UPDATED ICONS: IconMobileFax, IconPrintables.

* [#4934](https://github.azc.ext.hp.com/veneer/veneer/pull/4934) [`7f479330e`](https://github.azc.ext.hp.com/veneer/veneer/commit/7f479330e7ffeef95c7b06b1f75578266923bdfb) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [Select] Update popover width when resizing.

### Patch Changes

- [#4948](https://github.azc.ext.hp.com/veneer/veneer/pull/4948) [`a44c4e261`](https://github.azc.ext.hp.com/veneer/veneer/commit/a44c4e2612b77c770ee364f8fceb1bf6b188f95d) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - [Modal] Only call `onClose` if modal is open

* [#4929](https://github.azc.ext.hp.com/veneer/veneer/pull/4929) [`e7a73f948`](https://github.azc.ext.hp.com/veneer/veneer/commit/e7a73f948ed702746d1061adfc13eae6dba548f4) Thanks [@joao-flores-de-leao](https://github.azc.ext.hp.com/joao-flores-de-leao)! - [Table] Reset button is now triggered by all checkboxes updates

- [#4949](https://github.azc.ext.hp.com/veneer/veneer/pull/4949) [`d88b257e4`](https://github.azc.ext.hp.com/veneer/veneer/commit/d88b257e4d81a71931d50abc8c417549a20797b5) Thanks [@bruno-chanan](https://github.azc.ext.hp.com/bruno-chanan)! - [SideMenu] Update default responsive breakpoint

- Updated dependencies [[`a1ab60253`](https://github.azc.ext.hp.com/veneer/veneer/commit/a1ab602532ddf8fc41709671b3f33fe1c5a45d81), [`93d58e6b0`](https://github.azc.ext.hp.com/veneer/veneer/commit/93d58e6b0db9da2fc30082c407686a99b068b0df)]:
  - @veneer/theme@3.63.0

## 3.69.0

### Minor Changes

- [#4887](https://github.azc.ext.hp.com/veneer/veneer/pull/4887) [`fb3228bf3`](https://github.azc.ext.hp.com/veneer/veneer/commit/fb3228bf342daec26540d88cc354a80c141f11a6) Thanks [@louise](https://github.azc.ext.hp.com/louise)! - Update and add Icons to library.
  - 🆕 New icons: IconAlignPrintheadsPrint, IconArrowAdjustLeftRight, IconArrowAdjustUpDown, IconArrowDownLine, IconArrowLeftLine, IconArrowRightLine, IconArrowTrendDown, IconArrowTrendNeutral, IconArrowTrendUp, IconArrowUpLine, IconCatInCircle, IconCleanPrintheads, IconDevicesDuoPrinters, IconGridView, IconMultifunctionPrinter, IconPrinterFleet, IconPrintPhotos, IconSiteMap, IconSpreadsheet.
  - ♻ Updated: IconBatteryCheckmark, IconBatteryWarning, IconBell, IconBellOff, IconCalendar, IconCalendarClock, IconCalendarDay, IconCalendarLockedCurrent, IconCalendarLockedFuture, IconCalendarMonth, IconCalendarWarning, IconCalendarWeek, IconCertificate, IconCertificateWarning, IconDevicesLaptopPrinter, IconKeyboardCapsOn, IconKeyboardDelete, IconKeyboardShift, IconPcCloud, IconPcMode, IconPhoto, IconPolicies, IconPolicyAssigned, IconPolicyUnassigned.

* [#4915](https://github.azc.ext.hp.com/veneer/veneer/pull/4915) [`f648397cd`](https://github.azc.ext.hp.com/veneer/veneer/commit/f648397cdeda9288eb0fb17ba2429de96f65e86a) Thanks [@joao-flores-de-leao](https://github.azc.ext.hp.com/joao-flores-de-leao)! - [Avatar][anchormenu] Fix on the double focus when using keyboard navigation

- [#4760](https://github.azc.ext.hp.com/veneer/veneer/pull/4760) [`cae21572e`](https://github.azc.ext.hp.com/veneer/veneer/commit/cae21572e750bb05a4f21b7f8faa3104e9dca331) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [Typography] Forma DJR UI update
  🆕 Additions:

  New className `.salt` which applies new high-legibility CSS.
  When using `<i>` or `.italic` className, `Forma DJR UI Italic` will be used.
  New token `fontTextItalic`.

  ❌ Removals:

  Specific font for bold tags `<strong>`, `<b>`. Now, Forma DJR UI is the deafult font for it.
  Removed `letter-spacing: 'normal'` from `ar, bg, el, he, ja, ko, ru, sr, th, uk, zh` languages. It will be handled by `Forma DJR UI`.

  ⭐ Changes:

  Tokens:

  `fontTextRegular` from `Forma DJR Display` to `Forma DJR UI`.
  `fontTitleRegular` from `Forma DJR Display` to `Forma DJR UI`.
  All `letterSpacing` tokens have a new value `0`.

* [#4902](https://github.azc.ext.hp.com/veneer/veneer/pull/4902) [`b54a50186`](https://github.azc.ext.hp.com/veneer/veneer/commit/b54a50186b4d54457a72cb6f965c4ace231be4d7) Thanks [@louise](https://github.azc.ext.hp.com/louise)! - [Coachmark] Update component with the new Utility Button

- [#4898](https://github.azc.ext.hp.com/veneer/veneer/pull/4898) [`8b2c68ca6`](https://github.azc.ext.hp.com/veneer/veneer/commit/8b2c68ca6d356437e765f21c94ed388d8558b19c) Thanks [@jose-lima](https://github.azc.ext.hp.com/jose-lima)! - [Modal] Update component with the new Utility Button

* [#4873](https://github.azc.ext.hp.com/veneer/veneer/pull/4873) [`62e701cdb`](https://github.azc.ext.hp.com/veneer/veneer/commit/62e701cdb800838fa851f9b5dca4269a530e65d6) Thanks [@mateus-domingos](https://github.azc.ext.hp.com/mateus-domingos)! - [Search] Update component with the new Utility Button

- [#4861](https://github.azc.ext.hp.com/veneer/veneer/pull/4861) [`fd7f55d20`](https://github.azc.ext.hp.com/veneer/veneer/commit/fd7f55d20de1d39ce98e374b522043f4dd12b87b) Thanks [@louise](https://github.azc.ext.hp.com/louise)! - [ContextualMenu] Update style to use Veneer system colors

* [#4901](https://github.azc.ext.hp.com/veneer/veneer/pull/4901) [`da9707147`](https://github.azc.ext.hp.com/veneer/veneer/commit/da97071477185477051e09ad3feaaeeadc9b5189) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [PasswordRequirements] Add new property `requirementsPlacement` to control popover placement on `compact` mode.

  [HelperText] Add `hidden` value to `helperTextVisibility`.

### Patch Changes

- [#4906](https://github.azc.ext.hp.com/veneer/veneer/pull/4906) [`ea01d0def`](https://github.azc.ext.hp.com/veneer/veneer/commit/ea01d0def232bd1aea85f6ef4c36978d77ad4e9c) Thanks [@joao-flores-de-leao](https://github.azc.ext.hp.com/joao-flores-de-leao)! - [Modal][coachmark] Accessibility navigation now traps the focus on the modal or coachmark.

* [#4890](https://github.azc.ext.hp.com/veneer/veneer/pull/4890) [`eac7602b1`](https://github.azc.ext.hp.com/veneer/veneer/commit/eac7602b18aaf20c926fcb9546155459f8a84a01) Thanks [@joao-flores-de-leao](https://github.azc.ext.hp.com/joao-flores-de-leao)! - [Select] Select popover is responsive to window height.

* Updated dependencies [[`cae21572e`](https://github.azc.ext.hp.com/veneer/veneer/commit/cae21572e750bb05a4f21b7f8faa3104e9dca331), [`fd7f55d20`](https://github.azc.ext.hp.com/veneer/veneer/commit/fd7f55d20de1d39ce98e374b522043f4dd12b87b)]:
  - @veneer/styles@3.55.0
  - @veneer/tokens@3.55.0
  - @veneer/theme@3.62.0

## 3.68.0

### Minor Changes

- [#4860](https://github.azc.ext.hp.com/veneer/veneer/pull/4860) [`5bc9af735`](https://github.azc.ext.hp.com/veneer/veneer/commit/5bc9af7355b7c91fabc8e2059303fa9c2db77256) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [InlineNotification][toastnotification] Update close button to use UtilityButton

* [#4874](https://github.azc.ext.hp.com/veneer/veneer/pull/4874) [`ee3365743`](https://github.azc.ext.hp.com/veneer/veneer/commit/ee33657431631d57e7b32567bd9c42592c27b2ed) Thanks [@joao-flores-de-leao](https://github.azc.ext.hp.com/joao-flores-de-leao)! - [InlineNotification] ghost button changed to use consistent colors

- [#4867](https://github.azc.ext.hp.com/veneer/veneer/pull/4867) [`ce16337c0`](https://github.azc.ext.hp.com/veneer/veneer/commit/ce16337c0cf49943f005a55d23f1dc31039bd3d3) Thanks [@louise](https://github.azc.ext.hp.com/louise)! - Update and add Icons to library.
  - 🆕 New icons: IconAutoSense, IconEffectsWaveVertical, IconFanSoundOff, IconFanSpeed50, IconFanSpeed100, IconGearCheckmark, IconGridDashed, IconPhotoSizesRevert, IconSnowflakeRadiatingDendrite, IconSpeedometer.
  - ♻ Updated: IconLayout.

* [#4865](https://github.azc.ext.hp.com/veneer/veneer/pull/4865) [`00139ed76`](https://github.azc.ext.hp.com/veneer/veneer/commit/00139ed763d4871d844c8e3b4fa43d6a28088cc1) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [Treeview] Update component with new palette system

- [#4872](https://github.azc.ext.hp.com/veneer/veneer/pull/4872) [`12494eb03`](https://github.azc.ext.hp.com/veneer/veneer/commit/12494eb037bda784ad2d1559ff562c222d7c5334) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [HelperText] Update info and error icons

### Patch Changes

- [#4866](https://github.azc.ext.hp.com/veneer/veneer/pull/4866) [`54a70eb60`](https://github.azc.ext.hp.com/veneer/veneer/commit/54a70eb6068f4ad0d8532c56e840848d9965feb5) Thanks [@joao-flores-de-leao](https://github.azc.ext.hp.com/joao-flores-de-leao)! - [NotificationCenter] When navigating with keyboard the hoverable buttons will be focusable

* [#4878](https://github.azc.ext.hp.com/veneer/veneer/pull/4878) [`d45931229`](https://github.azc.ext.hp.com/veneer/veneer/commit/d45931229a4b2314e29ea220cb183b50dcec6cb8) Thanks [@jose-lima](https://github.azc.ext.hp.com/jose-lima)! - [Pagination] Fix the arrow button when is disabled

- [#4871](https://github.azc.ext.hp.com/veneer/veneer/pull/4871) [`eae21a175`](https://github.azc.ext.hp.com/veneer/veneer/commit/eae21a1754fdc56a2a86a8d8d325e854485d7617) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [Input] IOS support for disabled state

- Updated dependencies [[`00139ed76`](https://github.azc.ext.hp.com/veneer/veneer/commit/00139ed763d4871d844c8e3b4fa43d6a28088cc1)]:
  - @veneer/theme@3.61.0

## 3.67.0

### Minor Changes

- [#4846](https://github.azc.ext.hp.com/veneer/veneer/pull/4846) [`d8dd1afc0a`](https://github.azc.ext.hp.com/veneer/veneer/commit/d8dd1afc0a2cc0d7dfbba435ec9108fc775ba1f2) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [TextBox][textarea] Update components to consume system palette

* [#4845](https://github.azc.ext.hp.com/veneer/veneer/pull/4845) [`ab30f9b489`](https://github.azc.ext.hp.com/veneer/veneer/commit/ab30f9b4893f95688254168ced9ab57c096b5b78) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [Accordion] Update style to use Veneer system colors

- [#4852](https://github.azc.ext.hp.com/veneer/veneer/pull/4852) [`eebc484992`](https://github.azc.ext.hp.com/veneer/veneer/commit/eebc484992d1ce5e8b50745852bbe80957985ac3) Thanks [@joao-flores-de-leao](https://github.azc.ext.hp.com/joao-flores-de-leao)! - [AppHeader][breadcrumbs][Hyperlink][sidemenu][Tabs] Update components to have a accessibility keyboard navigation

* [#4834](https://github.azc.ext.hp.com/veneer/veneer/pull/4834) [`775392b5e7`](https://github.azc.ext.hp.com/veneer/veneer/commit/775392b5e754d40cebed1641a52db3ab3900f0a3) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [Typography] Define values for `<sub />` and `<sup />` tags

- [#4833](https://github.azc.ext.hp.com/veneer/veneer/pull/4833) [`9517985547`](https://github.azc.ext.hp.com/veneer/veneer/commit/9517985547cdd4c207af713d68d11d44d0301cd6) Thanks [@mateus-domingos](https://github.azc.ext.hp.com/mateus-domingos)! - [Password] Update component with the new Utility Button

### Patch Changes

- [#4832](https://github.azc.ext.hp.com/veneer/veneer/pull/4832) [`9284d0fec4`](https://github.azc.ext.hp.com/veneer/veneer/commit/9284d0fec4aa2babc6a7f028c5e804e0fe20ae5f) Thanks [@louise](https://github.azc.ext.hp.com/louise)! - [Modal] Fix footer orientation

* [#4835](https://github.azc.ext.hp.com/veneer/veneer/pull/4835) [`9d10a1dac3`](https://github.azc.ext.hp.com/veneer/veneer/commit/9d10a1dac389ac846e7287a10c83c4467ec33c37) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [Password] When password is external disabled, the component does not allow to see the password.

- [#4844](https://github.azc.ext.hp.com/veneer/veneer/pull/4844) [`8538869b36`](https://github.azc.ext.hp.com/veneer/veneer/commit/8538869b36cbdf6d1c617b445f54bb1049724105) Thanks [@mateus-domingos](https://github.azc.ext.hp.com/mateus-domingos)! - [SideMenu] Update spacing

- Updated dependencies [[`ab30f9b489`](https://github.azc.ext.hp.com/veneer/veneer/commit/ab30f9b4893f95688254168ced9ab57c096b5b78), [`775392b5e7`](https://github.azc.ext.hp.com/veneer/veneer/commit/775392b5e754d40cebed1641a52db3ab3900f0a3)]:
  - @veneer/theme@3.60.0
  - @veneer/styles@3.54.0

## 3.66.0

### Minor Changes

- [#4814](https://github.azc.ext.hp.com/veneer/veneer/pull/4814) [`a0b8a2f01`](https://github.azc.ext.hp.com/veneer/veneer/commit/a0b8a2f0193d70d9172ce2db5aea7c8dfb6f66fc) Thanks [@mateus-domingos](https://github.azc.ext.hp.com/mateus-domingos)! - [SideBar] Update component with the new Utility Button

* [#4795](https://github.azc.ext.hp.com/veneer/veneer/pull/4795) [`762356f84`](https://github.azc.ext.hp.com/veneer/veneer/commit/762356f84e55735a7a256572a0e4ba2652359818) Thanks [@louise](https://github.azc.ext.hp.com/louise)! - [Icons] Add icons to the library.
  - 🆕 New icons: IconColorPicker, IconFont, IconImageEditOriginalSize, IconImageEditPhotoExposure, IconImageEditPhotoShadows, IconImageEditPhotoSharpness, IconImageEditPhotoStraighten, IconLayout, IconPhotoSizes.

- [#4821](https://github.azc.ext.hp.com/veneer/veneer/pull/4821) [`3a7282856`](https://github.azc.ext.hp.com/veneer/veneer/commit/3a7282856cd24cb83d337f0818ce0dd83c2b4672) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [Pagination] Update component with the new Utility Button

* [#4793](https://github.azc.ext.hp.com/veneer/veneer/pull/4793) [`04a3cc164`](https://github.azc.ext.hp.com/veneer/veneer/commit/04a3cc164fc732ce38b9ced32f973ef6d940224e) Thanks [@joao-flores-de-leao](https://github.azc.ext.hp.com/joao-flores-de-leao)! - [ProgressIndicator] Update style to use Veneer system colors

### Patch Changes

- [#4799](https://github.azc.ext.hp.com/veneer/veneer/pull/4799) [`e68c47966`](https://github.azc.ext.hp.com/veneer/veneer/commit/e68c47966221903fd147c5c0c299d60a9aed7de6) Thanks [@mateus-domingos](https://github.azc.ext.hp.com/mateus-domingos)! - [SideMenuItem] Fix margin

* [#4750](https://github.azc.ext.hp.com/veneer/veneer/pull/4750) [`f889166ab`](https://github.azc.ext.hp.com/veneer/veneer/commit/f889166ab53b916d8d422486dad11269a620f9fb) Thanks [@louise](https://github.azc.ext.hp.com/louise)! - [Tabs] Update appearence of the gradient on the navigation button

- [#4796](https://github.azc.ext.hp.com/veneer/veneer/pull/4796) [`756f591cb`](https://github.azc.ext.hp.com/veneer/veneer/commit/756f591cb2fcfe0e76f5bee49e2bfc21b799f5ac) Thanks [@douglas-michaelsen](https://github.azc.ext.hp.com/douglas-michaelsen)! - [Table] Removing fixed placement `bottom-end` for ContextualMenu popover on Table action buttons. It will now use the default prop `bottom` from ContextualMenu or use the one passed for the Contextual Menus on Table row configuration.

* [#4794](https://github.azc.ext.hp.com/veneer/veneer/pull/4794) [`3823143b4`](https://github.azc.ext.hp.com/veneer/veneer/commit/3823143b40a48a2fbea669e966f223720c37229d) Thanks [@mateus-domingos](https://github.azc.ext.hp.com/mateus-domingos)! - [NotificationCenter] Fix ContextualMenu onClick when used inside NotificationCenter

* Updated dependencies [[`04a3cc164`](https://github.azc.ext.hp.com/veneer/veneer/commit/04a3cc164fc732ce38b9ced32f973ef6d940224e)]:
  - @veneer/theme@3.59.0

## 3.65.0

### Minor Changes

- [#4769](https://github.azc.ext.hp.com/veneer/veneer/pull/4769) [`c4c19e779`](https://github.azc.ext.hp.com/veneer/veneer/commit/c4c19e779c8330c1a1585bc82b9d21d64d350e42) Thanks [@louise](https://github.azc.ext.hp.com/louise)! - [Icon] Update and add icons to library.
  - 🆕 New icons: IconCalendarClock, IconCalendarWarning, IconCaptureText, IconChatText, IconConnectionAntenna, IconDisc, IconEquals, IconEqualsCircle, IconExportFromFolder, IconFireWire, IconIeee1394APort, IconImportToFolder, IconLaptopStars, IconLogPage, IconMonitorCheckmark, IconPods, IconPlugRj45, IconRemoteDrive, IconRibbonX, IconSasPort, IconSataPort, IconSignatureLine, IconStethoscope, IconStopSignHand, IconTuningForkAndWrench, IconUpdate, IconUsb20Port, IconUsb30, IconUsb30Port, IconUsbHub, IconUsbRootHub, IconYml.
  - ♻ Updated: IconCertificate, IconCertificateWarning, IconChat, IconPencil, IconUsb20.

* [#4772](https://github.azc.ext.hp.com/veneer/veneer/pull/4772) [`73cd8b641`](https://github.azc.ext.hp.com/veneer/veneer/commit/73cd8b64138838bfca611a3922e2a6a8d022d1fb) Thanks [@louise](https://github.azc.ext.hp.com/louise)! - [Icon] Update and add Icons to library.
  - 🆕 New icons: IconCornerRound, IconCornerSharp, IconDensityHigh, IconDensityStandard, IconDirectionLtr, IconDirectionRtl, IconImageEditPhotoContrastHigh, IconPrinterX, IconTextAlignJustify.
  - ♻ Updated: IconTablet, IconTextAlignCenter, IconTextAlignLeft, IconTextAlignRight.

- [#4621](https://github.azc.ext.hp.com/veneer/veneer/pull/4621) [`5bc8b1031`](https://github.azc.ext.hp.com/veneer/veneer/commit/5bc8b1031b61f47b67bbf6e0c3f35778c5da504c) Thanks [@douglas-michaelsen](https://github.azc.ext.hp.com/douglas-michaelsen)! - Refactoring RefAttributes and HTMLAttributes types for the remaining components. Also refactoring the related Storybook stories from js to tsx.

### Patch Changes

- [#4742](https://github.azc.ext.hp.com/veneer/veneer/pull/4742) [`bd02c96cc`](https://github.azc.ext.hp.com/veneer/veneer/commit/bd02c96cca1d17fb7fcb141f250c831ba5a256db) Thanks [@jedelston](https://github.azc.ext.hp.com/jedelston)! - [Toggle] Fix onChange typing

* [#4737](https://github.azc.ext.hp.com/veneer/veneer/pull/4737) [`7d33f5911`](https://github.azc.ext.hp.com/veneer/veneer/commit/7d33f5911ebfafceda6e9d5ee8d9fac3f216ff5d) Thanks [@bruno-chanan](https://github.azc.ext.hp.com/bruno-chanan)! - [Tag] Fix size, spacing and alignment

- [#4758](https://github.azc.ext.hp.com/veneer/veneer/pull/4758) [`1a1262556`](https://github.azc.ext.hp.com/veneer/veneer/commit/1a12625569494db10180c1f26a8d190d3d2686d8) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - [Password][search] Fix theme proptypes

* [#4693](https://github.azc.ext.hp.com/veneer/veneer/pull/4693) [`955a2ad6d`](https://github.azc.ext.hp.com/veneer/veneer/commit/955a2ad6d60f87cb17a943391c2783822240ff62) Thanks [@nicolas-renard](https://github.azc.ext.hp.com/nicolas-renard)! - [FilePicker] Fixing component to return to original state after cancelling action

- [#4768](https://github.azc.ext.hp.com/veneer/veneer/pull/4768) [`15c592c44`](https://github.azc.ext.hp.com/veneer/veneer/commit/15c592c44df71d8ace0b8fe2d163c4c5c3517a21) Thanks [@mateus-domingos](https://github.azc.ext.hp.com/mateus-domingos)! - [Password] Fix typing

- Updated dependencies [[`f54006e59`](https://github.azc.ext.hp.com/veneer/veneer/commit/f54006e59efbeea95f8b7749ab2ba77367587643)]:
  - @veneer/tokens@3.54.0
  - @veneer/theme@3.58.2

## 3.64.0

### Minor Changes

- [#4719](https://github.azc.ext.hp.com/veneer/veneer/pull/4719) [`737d3216b`](https://github.azc.ext.hp.com/veneer/veneer/commit/737d3216ba09565ce72fb503684a4509071f095f) Thanks [@bruno-chanan](https://github.azc.ext.hp.com/bruno-chanan)! - [Icons] Update and add new Global icons
  - 🆕 New icons: IconSantaClaus, IconMountainPeaks, IconCandelabra, IconCandyCane, IconFestiveTree, IconGingerbreadMan, IconRoundOrnament, IconSantaHat, IconSnowCloud, IconSnowflake, IconSnowman
  - ♻️ IconGift updated.

* [#4703](https://github.azc.ext.hp.com/veneer/veneer/pull/4703) [`9dd40c775`](https://github.azc.ext.hp.com/veneer/veneer/commit/9dd40c775064adec79e9c8194b56bf2f1b0521fe) Thanks [@douglas-michaelsen](https://github.azc.ext.hp.com/douglas-michaelsen)! - Reverting Select popover behavior to the same as it was previous to version 3.60.0 where new shadow levels were introduced.

### Patch Changes

- [#4687](https://github.azc.ext.hp.com/veneer/veneer/pull/4687) [`e6e34af47`](https://github.azc.ext.hp.com/veneer/veneer/commit/e6e34af47505de4814113194d8233236a541486f) Thanks [@louise](https://github.azc.ext.hp.com/louise)! - [Accordion] Remove hoverable interaction

  ⚠️ The prop `hoverable` is being deprecated as this type of interaction is not planned to exist.

## 3.63.0

### Minor Changes

- [#4671](https://github.azc.ext.hp.com/veneer/veneer/pull/4671) [`aaedc6b4f`](https://github.azc.ext.hp.com/veneer/veneer/commit/aaedc6b4f7509c99f70a7e1c1441fe84ac409b70) Thanks [@dmitriy-lazarev](https://github.azc.ext.hp.com/dmitriy-lazarev)! - [SideBar] Add `hideBackdrop` prop to hide backdrop in `overlay` behavior

* [#4658](https://github.azc.ext.hp.com/veneer/veneer/pull/4658) [`86eedcf63`](https://github.azc.ext.hp.com/veneer/veneer/commit/86eedcf631764da388c812f2f3a037c01ce45ff2) Thanks [@bruno-chanan](https://github.azc.ext.hp.com/bruno-chanan)! - [DatePicker] Add minDate, maxDate and isOutsideRange props

- [#4666](https://github.azc.ext.hp.com/veneer/veneer/pull/4666) [`50a2189ca`](https://github.azc.ext.hp.com/veneer/veneer/commit/50a2189ca1668f581916046d2ff61eca3b807631) Thanks [@mateus-domingos](https://github.azc.ext.hp.com/mateus-domingos)! - [Pagination] Add hideLastPage property to hide last page number

### Patch Changes

- [#4673](https://github.azc.ext.hp.com/veneer/veneer/pull/4673) [`41f2c67df`](https://github.azc.ext.hp.com/veneer/veneer/commit/41f2c67df671b696f4c868d124f4c38bcbc43212) Thanks [@nicolas-marques-garcia-renard](https://github.azc.ext.hp.com/nicolas-marques-garcia-renard)! - [Table] Adjust resize line on Modals

* [#4665](https://github.azc.ext.hp.com/veneer/veneer/pull/4665) [`ecd746e4f`](https://github.azc.ext.hp.com/veneer/veneer/commit/ecd746e4fe1f3b7dec7252417f73a4fd8eaf5f03) Thanks [@nicolas-marques-garcia-renard](https://github.azc.ext.hp.com/nicolas-marques-garcia-renard)! - [Pagination] Last second page is not visible to the user

- [#4682](https://github.azc.ext.hp.com/veneer/veneer/pull/4682) [`731645e49`](https://github.azc.ext.hp.com/veneer/veneer/commit/731645e49bd522ca772a1b7cd5caa54210c48055) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [Password][search] Update zIndex state on Popover

* [#4670](https://github.azc.ext.hp.com/veneer/veneer/pull/4670) [`5759f3f56`](https://github.azc.ext.hp.com/veneer/veneer/commit/5759f3f56e23ce40d30d972477cd0af59d18d445) Thanks [@mateus-domingos](https://github.azc.ext.hp.com/mateus-domingos)! - [Table] Fix functions typing
  [ContextualMenu] Fix functions typing

## 3.62.0

### Minor Changes

- [#4652](https://github.azc.ext.hp.com/veneer/veneer/pull/4652) [`8833ddb4b`](https://github.azc.ext.hp.com/veneer/veneer/commit/8833ddb4b744faedde24e1fbc4eef64bf891383d) Thanks [@mateus-domingos](https://github.azc.ext.hp.com/mateus-domingos)! - [Icon] Thanksgiving, multicam, and 5G

### Patch Changes

- [#4651](https://github.azc.ext.hp.com/veneer/veneer/pull/4651) [`826b18edd`](https://github.azc.ext.hp.com/veneer/veneer/commit/826b18eddd883878d85c1fb4d2b0280184a952c8) Thanks [@mateus-domingos](https://github.azc.ext.hp.com/mateus-domingos)! - [Breadcrumbs] Fix multiple-lines in smaller viewport.
  - ⚠️ The prop `truncateText` is being deprecated. Now the Breadcrumbs will always adapt automatically to smaller viewports.

* [#4653](https://github.azc.ext.hp.com/veneer/veneer/pull/4653) [`f89dbb819`](https://github.azc.ext.hp.com/veneer/veneer/commit/f89dbb8190dd194124a302e66cfc339c0c38388b) Thanks [@nicolas-marques-garcia-renard](https://github.azc.ext.hp.com/nicolas-marques-garcia-renard)! - [Icon] QR Code update

- [#4663](https://github.azc.ext.hp.com/veneer/veneer/pull/4663) [`ddbd99974`](https://github.azc.ext.hp.com/veneer/veneer/commit/ddbd99974798b95e1f75147fd89bd53ff5fd4dd7) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - [Infra] Fixing typings for Button `customStyle` prop.

## 3.61.0

### Minor Changes

- [#4636](https://github.azc.ext.hp.com/veneer/veneer/pull/4636) [`d719bcdc5`](https://github.azc.ext.hp.com/veneer/veneer/commit/d719bcdc5f623ab3ffafbf0c73277fc47dc1a158) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [Password] Add password requirements compact version with the new property `behavior="compact"`.
  [Inputs] Add `helperTextState` property.

* [#4624](https://github.azc.ext.hp.com/veneer/veneer/pull/4624) [`a165fc4ba`](https://github.azc.ext.hp.com/veneer/veneer/commit/a165fc4ba70cf6cbabe7a6b6e0a9e8cbef80ebcc) Thanks [@pedro-henrique-passos-leite](https://github.azc.ext.hp.com/pedro-henrique-passos-leite)! - [Icons] Update and add new Global icons
  - 🆕 New icons: IconCertificateWarning, IconShieldX, and IconWallOff.
  - ♻️ IconPlay updated.

- [#4583](https://github.azc.ext.hp.com/veneer/veneer/pull/4583) [`2e95ed4f1`](https://github.azc.ext.hp.com/veneer/veneer/commit/2e95ed4f1d403b8fc20b376355c890202a2f20f9) Thanks [@mateus-domingos](https://github.azc.ext.hp.com/mateus-domingos)! - [ContextualMenu] Add divider to contextual menu.
  - ⚠️ The ContextualMenu component was refactored in order to support sections. It has also received a new styling and
    changes on focus during navigation. The component still supports the old `options` prop. For the new implementation
    now the component uses children with new components `MenuList`, `MenuItem` and `MenuSection`. The anchor node now is
    passed on the prop `anchorNode`. For more details check the [Storybook example](https://pages.github.azc.ext.hp.com/veneer/design-system/storybook/3.61.0/?path=/story/components-contextualmenu-default--with-custom-menu-with-section)

* [#4626](https://github.azc.ext.hp.com/veneer/veneer/pull/4626) [`f5aafdd06`](https://github.azc.ext.hp.com/veneer/veneer/commit/f5aafdd06ec98fa52ff82e35163d5cdb84bc05a2) Thanks [@bruno-chanan](https://github.azc.ext.hp.com/bruno-chanan)! - [TextBox] Add min/max properties

### Patch Changes

- [#4627](https://github.azc.ext.hp.com/veneer/veneer/pull/4627) [`8c2028dec`](https://github.azc.ext.hp.com/veneer/veneer/commit/8c2028decf4ef27df1d390432bd04fc798b2f962) Thanks [@louise](https://github.azc.ext.hp.com/louise)! - Change icon appearance when pressed

* [#4625](https://github.azc.ext.hp.com/veneer/veneer/pull/4625) [`0068e7275`](https://github.azc.ext.hp.com/veneer/veneer/commit/0068e7275fd4aa51faa9dd545b56f7ed1feb1014) Thanks [@mateus-domingos](https://github.azc.ext.hp.com/mateus-domingos)! - [Modal] Fix spacing

* Updated dependencies [[`33670e428`](https://github.azc.ext.hp.com/veneer/veneer/commit/33670e4289574c355248486d846451f3fb0280ab)]:
  - @veneer/tokens@3.53.1
  - @veneer/theme@3.58.1

## 3.60.0

### Minor Changes

- [#4610](https://github.azc.ext.hp.com/veneer/veneer/pull/4610) [`fc71e0d8f`](https://github.azc.ext.hp.com/veneer/veneer/commit/fc71e0d8fa5eea515c64a9aaaf05dc74c6416111) Thanks [@bruno-chanan](https://github.azc.ext.hp.com/bruno-chanan)! - [Breadcrumb] Add compact mode

- [#4530](https://github.azc.ext.hp.com/veneer/veneer/pull/4530) [`c323577`](https://github.azc.ext.hp.com/veneer/veneer/commit/c323577de770bfb449b8605c06b2f193fa18b460) Thanks [@pedro-henrique-passos-leite](https://github.azc.ext.hp.com/pedro-henrique-passos-leite)! - [Shadows][system] Add shadows level system to Default Theme

* [#4606](https://github.azc.ext.hp.com/veneer/veneer/pull/4606) [`fd1013ee4`](https://github.azc.ext.hp.com/veneer/veneer/commit/fd1013ee4706b10cad0769f78acd70ca8a9c91df) Thanks [@pedro-henrique-passos-leite](https://github.azc.ext.hp.com/pedro-henrique-passos-leite)! - [Icons] Update and add new icons

  - 🆕 New Global icons: `IconEvergreenTrees` and `IconPersonalComputer`.
  - ♻️ Updated Global icons: `IconConferenceRoom`, `IconEvergreenTree`, and `IconHuman`.
  - 🆕 New Print icons: `IconEnhance` and `IconInkShipmentMissing`.
  - ♻️ Updated Print `IconAutoEnhance` icon.
  - 🆕 New PSSW icons: `IconCoffeeCup`, `IconObjectOutlineAuto`, `IconObjectOutlineManual`, and `IconQrCode`.
  - ♻️ Updated PSSW `IconBinoculars`, `IconServiceBell`, and `IconServiceBellActive` icons.
  - 🆕🎃 New PSSW Halloween icons: `IconCandyCorn`, `IconJackOLantern`, `IconMagicBroom`, `IconMagicHat`, `IconPeppermintLollipop`, `IconShorthairCat`, `IconSpider`, `IconSpiderWebCorner`, `IconSpiderWebFull`, `IconUpsideDownBat`.

- [#4584](https://github.azc.ext.hp.com/veneer/veneer/pull/4584) [`ba1f37b55`](https://github.azc.ext.hp.com/veneer/veneer/commit/ba1f37b555cf3ce9e27068f72785ab0ccb9adab6) Thanks [@bruno-chanan](https://github.azc.ext.hp.com/bruno-chanan)! - [Textbox] Change native input date icon

### Patch Changes

- [#4629](https://github.azc.ext.hp.com/veneer/veneer/pull/4629) [`0d88cf6ad`](https://github.azc.ext.hp.com/veneer/veneer/commit/0d88cf6adcee1415bc86fda5b4f1bf65ae44893c) Thanks [@douglas-michaelsen](https://github.azc.ext.hp.com/douglas-michaelsen)! - Fixing inputs height.

- Updated dependencies [[`83d8290ac`](https://github.azc.ext.hp.com/veneer/veneer/commit/83d8290ace6fc19ebe49e69fd4506fbb014b2297)]:
  - @veneer/theme@3.58.0

## 3.59.0

### Minor Changes

- [#4588](https://github.azc.ext.hp.com/veneer/veneer/pull/4588) [`2422f175d`](https://github.azc.ext.hp.com/veneer/veneer/commit/2422f175da86b6112a30573d16afcd78060fbb45) Thanks [@mateus-domingos](https://github.azc.ext.hp.com/mateus-domingos)! - [Icon] Support, Service Bell, Binoculars, and Trucks icons

* [#4589](https://github.azc.ext.hp.com/veneer/veneer/pull/4589) [`6f1cedaa0`](https://github.azc.ext.hp.com/veneer/veneer/commit/6f1cedaa010404f6bfe53bd658e7b4a6c0794a2f) Thanks [@douglas-michaelsen](https://github.azc.ext.hp.com/douglas-michaelsen)! - Refactoring RefAttributes and HTMLAttributes types for Button and Card components

- [#4567](https://github.azc.ext.hp.com/veneer/veneer/pull/4567) [`8f1718599`](https://github.azc.ext.hp.com/veneer/veneer/commit/8f17185999973630a4c87e334821d83f645efb0d) Thanks [@pedro-henrique-passos-leite](https://github.azc.ext.hp.com/pedro-henrique-passos-leite)! - [Colors] Implement new interactive state colors on `<Breadcrumbs />`, `<Checkbox />`, `<RadioButton />`, `<SegmentedControl />` and `<Toggle />` components

### Patch Changes

- [#4601](https://github.azc.ext.hp.com/veneer/veneer/pull/4601) [`ac7bcda61`](https://github.azc.ext.hp.com/veneer/veneer/commit/ac7bcda6117aad4737732d3c9a726b0e252b1fae) Thanks [@pedro-henrique-passos-leite](https://github.azc.ext.hp.com/pedro-henrique-passos-leite)! - [IconMarketplace] Update icon

* [#4571](https://github.azc.ext.hp.com/veneer/veneer/pull/4571) [`6c57a0feb`](https://github.azc.ext.hp.com/veneer/veneer/commit/6c57a0feb5827398fe4ed0c4007299d57fd264cc) Thanks [@pedro-henrique-passos-leite](https://github.azc.ext.hp.com/pedro-henrique-passos-leite)! - [Logo] Update default color to `colorBlack`

- [#4580](https://github.azc.ext.hp.com/veneer/veneer/pull/4580) [`006d7167e`](https://github.azc.ext.hp.com/veneer/veneer/commit/006d7167e1642307696dab28bc6921770fcf5433) Thanks [@louise](https://github.azc.ext.hp.com/louise)! - [Select] Add ellipsis for long labels

* [#4593](https://github.azc.ext.hp.com/veneer/veneer/pull/4593) [`4af467bb6`](https://github.azc.ext.hp.com/veneer/veneer/commit/4af467bb619e1d2c4df9233d4f681f8b01c82215) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - [CustomImage] fix proptype for customStyle

* Updated dependencies [[`6c57a0feb`](https://github.azc.ext.hp.com/veneer/veneer/commit/6c57a0feb5827398fe4ed0c4007299d57fd264cc), [`8f1718599`](https://github.azc.ext.hp.com/veneer/veneer/commit/8f17185999973630a4c87e334821d83f645efb0d), [`10d478d04`](https://github.azc.ext.hp.com/veneer/veneer/commit/10d478d044067cba5bc651e82fc0f92354711032)]:
  - @veneer/tokens@3.53.0
  - @veneer/theme@3.57.0

## 3.58.0

### Minor Changes

- [#4560](https://github.azc.ext.hp.com/veneer/veneer/pull/4560) [`f4819487e`](https://github.azc.ext.hp.com/veneer/veneer/commit/f4819487ea2205f10dbf5074265a3f21f46bc34a) Thanks [@bruno-chanan](https://github.azc.ext.hp.com/bruno-chanan)! - [TextBox] Support browser native date/time pickers

* [#4529](https://github.azc.ext.hp.com/veneer/veneer/pull/4529) [`7d845ff26`](https://github.azc.ext.hp.com/veneer/veneer/commit/7d845ff26baabc127a81d9458fc43a86156ff7bc) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [Modal] Add new prop `hasCustomScrollbarOnBody`.

- [#4541](https://github.azc.ext.hp.com/veneer/veneer/pull/4541) [`291551ceb`](https://github.azc.ext.hp.com/veneer/veneer/commit/291551cebbdbdbac9c4ca2e1836fca9b8fe59343) Thanks [@bruno-chanan](https://github.azc.ext.hp.com/bruno-chanan)! - [InputFields] Update "label" and "placeholder" color

* [#4520](https://github.azc.ext.hp.com/veneer/veneer/pull/4520) [`6430c2ff8`](https://github.azc.ext.hp.com/veneer/veneer/commit/6430c2ff816e245446892d25e2a172721b4ab4f8) Thanks [@louise](https://github.azc.ext.hp.com/louise)! - [Group] Add new component to library

- [#4555](https://github.azc.ext.hp.com/veneer/veneer/pull/4555) [`2eeac71ae`](https://github.azc.ext.hp.com/veneer/veneer/commit/2eeac71ae31fa4f4cbf4531ef73bd18bb197c8db) Thanks [@mateus-domingos](https://github.azc.ext.hp.com/mateus-domingos)! - [Icon] Shield Help, Calendar Locked, Hand w/Square, Gauges

* [#4173](https://github.azc.ext.hp.com/veneer/veneer/pull/4173) [`d2702e793`](https://github.azc.ext.hp.com/veneer/veneer/commit/d2702e7938363f6990cb5cab75b1cc98a31f9b64) Thanks [@shahzaib-khalid](https://github.azc.ext.hp.com/shahzaib-khalid)! - [Accordion] Add `previewArea` to header

- [#4559](https://github.azc.ext.hp.com/veneer/veneer/pull/4559) [`1411dee27`](https://github.azc.ext.hp.com/veneer/veneer/commit/1411dee278940b7f551759daa9bfe1fe45cc0d59) Thanks [@pedro-henrique-passos-leite](https://github.azc.ext.hp.com/pedro-henrique-passos-leite)! - [Icons] Update and add new icons

  - ♻️ Updated icons: `IconCopy`, `IconFunnel`, `IconFunnelClear`, and `IconMarketplace`.
  - 🆕 New Global icons: `IconRecord`, `IconTimer`, and `IconTimerWarningCircle`.
  - 🆕 New PSSW icons: `IconLive`, `IconObjectOutline`, `IconOpenInSeparateWindow`, `IconPdf`, `IconRotateClockwise`, and `IconRotateCounterclockwise`.
  - 🆕 New Print icon: `IconStartPrinter`.

### Patch Changes

- [#4546](https://github.azc.ext.hp.com/veneer/veneer/pull/4546) [`03a6ef33d`](https://github.azc.ext.hp.com/veneer/veneer/commit/03a6ef33da464044dded18916b82db72875df59f) Thanks [@bianca-camargo-machado1](https://github.azc.ext.hp.com/bianca-camargo-machado1)! - [TextArea] Fix typo on `resize` values and add properties description.

* [#4527](https://github.azc.ext.hp.com/veneer/veneer/pull/4527) [`d0712753f`](https://github.azc.ext.hp.com/veneer/veneer/commit/d0712753fd135c8be936f6ec42d88b77c47cb9dd) Thanks [@mateus-domingos](https://github.azc.ext.hp.com/mateus-domingos)! - [Label Small] Swap all the Caption Small in the components to Label Small

- [#4538](https://github.azc.ext.hp.com/veneer/veneer/pull/4538) [`2d11df024`](https://github.azc.ext.hp.com/veneer/veneer/commit/2d11df024bf08aeb951891f79e74045fe52a2dfd) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [SegmentedControl] Fix console errors

* [#4536](https://github.azc.ext.hp.com/veneer/veneer/pull/4536) [`7e96401ea`](https://github.azc.ext.hp.com/veneer/veneer/commit/7e96401ea0b63f44f42581c9c1cb65468c95f950) Thanks [@bianca-camargo-machado1](https://github.azc.ext.hp.com/bianca-camargo-machado1)! - [TreeView] Allow custom color for icons by its `color` property.

- [#4534](https://github.azc.ext.hp.com/veneer/veneer/pull/4534) [`983415bd0`](https://github.azc.ext.hp.com/veneer/veneer/commit/983415bd0885d92f3c52a622c39a2cf60385ecf2) Thanks [@bianca-camargo-machado1](https://github.azc.ext.hp.com/bianca-camargo-machado1)! - [Select] Avoid selecting disabled option by `Enter` key.

* [#4550](https://github.azc.ext.hp.com/veneer/veneer/pull/4550) [`604419e83`](https://github.azc.ext.hp.com/veneer/veneer/commit/604419e83d446a0610f632615b9d8bf06b51f3e7) Thanks [@pedro-henrique-passos-leite](https://github.azc.ext.hp.com/pedro-henrique-passos-leite)! - [ProgressIndicator] Extend HTML attributes

- [#4542](https://github.azc.ext.hp.com/veneer/veneer/pull/4542) [`0c0e60e1d`](https://github.azc.ext.hp.com/veneer/veneer/commit/0c0e60e1d13476fc8a99a46d617f98213262699d) Thanks [@louise](https://github.azc.ext.hp.com/louise)! - [Logo] Extending Custom Image types and fix `customStyle` prop.

- Updated dependencies [[`291551ceb`](https://github.azc.ext.hp.com/veneer/veneer/commit/291551cebbdbdbac9c4ca2e1836fca9b8fe59343)]:
  - @veneer/theme@3.56.0

## 3.57.1

## 3.57.0

### Minor Changes

- [#4515](https://github.azc.ext.hp.com/veneer/veneer/pull/4515) [`be4007ac3`](https://github.azc.ext.hp.com/veneer/veneer/commit/be4007ac3cd2ade4f196749d1716b9aa9a80ea9e) Thanks [@bruno-chanan](https://github.azc.ext.hp.com/bruno-chanan)! - [Table] add new prop `customNoItems`

* [#4499](https://github.azc.ext.hp.com/veneer/veneer/pull/4499) [`974a741c0`](https://github.azc.ext.hp.com/veneer/veneer/commit/974a741c05a352eeb13eac07bef07b69631bf06b) Thanks [@mateus-domingos](https://github.azc.ext.hp.com/mateus-domingos)! - - [Icons] Update `IconSpeakerMute` to the library.
  - [Icons] Add `IconRocket`, `IconSpeakerOff`, `IconSpeakerVolume0`, `IconSpeakerVolume25`, `IconSpeakerVolume50` and `IconSpeakerVolume100` to the library.

- [#4505](https://github.azc.ext.hp.com/veneer/veneer/pull/4505) [`150eebcfd`](https://github.azc.ext.hp.com/veneer/veneer/commit/150eebcfd5ae1af587dd8a17eef51a4d5ed8a324) Thanks [@bruno-chanan](https://github.azc.ext.hp.com/bruno-chanan)! - [Tag] Add component to the library

* [#4517](https://github.azc.ext.hp.com/veneer/veneer/pull/4517) [`9a4d596c1`](https://github.azc.ext.hp.com/veneer/veneer/commit/9a4d596c19b6a6e681e8bc839e8978ee6604fadf) Thanks [@pedro-henrique-passos-leite](https://github.azc.ext.hp.com/pedro-henrique-passos-leite)! - [Theme] Update theme values of the following colors: `colorDisabledBackground`, `colorNegativeActive`, `colorNegativeHover`, `colorPositiveActive`, `colorPositiveHover`, `colorWarningActive`, `colorWarningHover`.

  [Theme] New colors: `colorNegativeBackgroundLight`, `colorNeutral`, `colorNeutralActive`, `colorNeutralBackground`, `colorNeutralBackgroundLight`, `colorNeutralHover`, `colorPositiveBackgroundLight`, `colorStroke` and `colorWarningBackgroundLight`.

  - ⚠ Deprecated colors: `colorBorderOutlined`, `colorButtonDisabledForeground`, `colorDisabledBorder`, `colorErrorForeground`, `colorInputBorderFilledHover`, `colorNegativeForeground`, `colorNeutralFive`, `colorNeutralFour`, `colorNeutralOne`, `colorNeutralSix`, `colorNeutralThree` and `colorNeutralTwo`.

- [#4510](https://github.azc.ext.hp.com/veneer/veneer/pull/4510) [`73ff0b37e`](https://github.azc.ext.hp.com/veneer/veneer/commit/73ff0b37e1c012cb9da041dfcc7d11f8d35d741b) Thanks [@pedro-henrique-passos-leite](https://github.azc.ext.hp.com/pedro-henrique-passos-leite)! - [Button] Add Secondary and Ghost appearance to Positive, Warning, and Negative Buttons

  ⚠️ The values `positive`, `warning` and `negative` are deprecated on the `appearance` property. Use the `colorScheme` property instead.

  ```jsx
  <Button colorScheme="positive">Button Label</Button>

  <Button colorScheme="negative">Button Label</Button>

  <Button colorScheme="warning">Button Label</Button>
  ```

### Patch Changes

- [#4519](https://github.azc.ext.hp.com/veneer/veneer/pull/4519) [`8c4a9c1be`](https://github.azc.ext.hp.com/veneer/veneer/commit/8c4a9c1bede7528d946dfc4783ec9a589b8e1749) Thanks [@julihermes-silva](https://github.azc.ext.hp.com/julihermes-silva)! - [Icon] Fix some icons with name differently than specified in FIGMA

* [#4500](https://github.azc.ext.hp.com/veneer/veneer/pull/4500) [`296abb8e0`](https://github.azc.ext.hp.com/veneer/veneer/commit/296abb8e04530f156afd62216ab43f816a574c40) Thanks [@julihermes-silva](https://github.azc.ext.hp.com/julihermes-silva)! - [Datepicker] Fix range DatePicker focus state when closed

- [#4521](https://github.azc.ext.hp.com/veneer/veneer/pull/4521) [`ebd0f0bc3`](https://github.azc.ext.hp.com/veneer/veneer/commit/ebd0f0bc36a74bdf7547207c3da98c70495e6b33) Thanks [@mateus-domingos](https://github.azc.ext.hp.com/mateus-domingos)! - [Icon] Update IconVpn and IconVpnOff

* [#4503](https://github.azc.ext.hp.com/veneer/veneer/pull/4503) [`25b2d612d`](https://github.azc.ext.hp.com/veneer/veneer/commit/25b2d612df99e4f0af5a87a8b127906443289173) Thanks [@pedro-henrique-passos-leite](https://github.azc.ext.hp.com/pedro-henrique-passos-leite)! - [Toggle] Fix thumb position

- [#4512](https://github.azc.ext.hp.com/veneer/veneer/pull/4512) [`462a9884f`](https://github.azc.ext.hp.com/veneer/veneer/commit/462a9884ffec0e8943d2c6a18f60024c408e5536) Thanks [@mateus-domingos](https://github.azc.ext.hp.com/mateus-domingos)! - [Select] Move styling from Options to OptionsList

* [#4428](https://github.azc.ext.hp.com/veneer/veneer/pull/4428) [`99b04f922`](https://github.azc.ext.hp.com/veneer/veneer/commit/99b04f9220ed3cbeff0d484edf091a5e1501dc0e) Thanks [@douglas-michaelsen](https://github.azc.ext.hp.com/douglas-michaelsen)! - [Infra] Add `@veneer/analytics` and `@veneer/core-analytics` packages.

* Updated dependencies [[`9a4d596c1`](https://github.azc.ext.hp.com/veneer/veneer/commit/9a4d596c19b6a6e681e8bc839e8978ee6604fadf)]:
  - @veneer/theme@3.55.0

## 3.56.0

### Minor Changes

- [#4468](https://github.azc.ext.hp.com/veneer/veneer/pull/4468) [`4af2bdd09`](https://github.azc.ext.hp.com/veneer/veneer/commit/4af2bdd09467b390ed58ab633bc0abf1871182b8) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - Allow react nodes as helper text for form inputs

* [#4476](https://github.azc.ext.hp.com/veneer/veneer/pull/4476) [`e7aaa1f0c`](https://github.azc.ext.hp.com/veneer/veneer/commit/e7aaa1f0c95af5a6b7d9c713e28046b095c95bac) Thanks [@mateus-domingos](https://github.azc.ext.hp.com/mateus-domingos)! - - [Icons] Update `IconBios`, `IconContacts`, `IconHandStars`, `IconPhoneCallback` and `IconPhone` to the library.
  - [Icons] Add `IconApple`, `IconBiosNoPolicy`, `IconBiosPolicy`, `IconEarLeftDiagnostic`, `IconEarLeftId`, `IconEarLeft`, `IconEarRightAmplify`, `IconEarRightDiagnostic`, `IconEarRightId`, `IconEarRight`, `IconEvergreenTree`, `IconHandWithPlant`, `IconHuman`, `IconOptimize`, `IconOrcaWhale`, `IconPageA3`, `IconPageA4`, `IconPageLandscape`, `IconPagePortrait`, `IconPlanet`, `IconSun` and `IconWindow` to the library.

- [#4486](https://github.azc.ext.hp.com/veneer/veneer/pull/4486) [`e93c976d5`](https://github.azc.ext.hp.com/veneer/veneer/commit/e93c976d5763982e39eaee7a33410d2dc326a892) Thanks [@mateus-domingos](https://github.azc.ext.hp.com/mateus-domingos)! - - [Icons] Add `IconAutoFrame`, `IconBreadcrumb`, `IconCarFront`, `IconChevronDownCircle`, `IconChevronLeftCircle`, `IconChevronRightCircle`, `IconChevronUpCircle`, `IconCloudService`, `IconComputingEnvironment`, `IconConsole`, `IconEffectsBreathing`, `IconEffectsColorCycle`, `IconEffectsRipple`, `IconEffectsStatic`, `IconEffectsWave`, `IconEffects`, `IconGasoline` and `IconIntegration` to the library.

### Patch Changes

- [#4489](https://github.azc.ext.hp.com/veneer/veneer/pull/4489) [`efe7417fe`](https://github.azc.ext.hp.com/veneer/veneer/commit/efe7417fe9e0d3dace17b533391a54aaba3f4cd6) Thanks [@julihermes-silva](https://github.azc.ext.hp.com/julihermes-silva)! - [Datepicker] Removed unnecessary onChange call

* [#4485](https://github.azc.ext.hp.com/veneer/veneer/pull/4485) [`1b24c5ed3`](https://github.azc.ext.hp.com/veneer/veneer/commit/1b24c5ed3637604ec15e80c93a2eba01a0ed7805) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - Fix casing of tabIndex on scrollbar component

- [#4479](https://github.azc.ext.hp.com/veneer/veneer/pull/4479) [`d071c32d2`](https://github.azc.ext.hp.com/veneer/veneer/commit/d071c32d2e5a5766647b4ddd722a990238686f1e) Thanks [@julihermes-silva](https://github.azc.ext.hp.com/julihermes-silva)! - [Select] Now the options items are updated when the value prop is directly changed

* [#4474](https://github.azc.ext.hp.com/veneer/veneer/pull/4474) [`e0530ea60`](https://github.azc.ext.hp.com/veneer/veneer/commit/e0530ea60906f62e1ae2d106838c8d847742891e) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - Update tabs component typings to support generic types
  Mark tab id required in onChangeTab callback

- [#4461](https://github.azc.ext.hp.com/veneer/veneer/pull/4461) [`393980cfe`](https://github.azc.ext.hp.com/veneer/veneer/commit/393980cfef9c13810fb9c87306cfb131de9e2cbc) Thanks [@julihermes-silva](https://github.azc.ext.hp.com/julihermes-silva)! - [Buttons] Update spacing for Standard Density and High Density

* [#4478](https://github.azc.ext.hp.com/veneer/veneer/pull/4478) [`f1d8d4a80`](https://github.azc.ext.hp.com/veneer/veneer/commit/f1d8d4a807cb04808956ec2dc132dd92d3f2717e) Thanks [@louise](https://github.azc.ext.hp.com/louise)! - [SideMenu] Update colors to match Navigation Menu atoms and add pressed state.

* Updated dependencies [[`f1d8d4a80`](https://github.azc.ext.hp.com/veneer/veneer/commit/f1d8d4a807cb04808956ec2dc132dd92d3f2717e)]:
  - @veneer/theme@3.54.1

## 3.55.0

### Minor Changes

- [#4339](https://github.azc.ext.hp.com/veneer/veneer/pull/4339) [`e430ea1eb`](https://github.azc.ext.hp.com/veneer/veneer/commit/e430ea1eb366a7a70e65db0142d50098d0e73673) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [Scrollbar] Add `css-only` version of the component to library.

  ⚠️ If your project is using the deprecated `Scrollbar`, please update the import:
  `import { deprecated_ScrollBar as Scrollbar } from '@veneer/core'`;

### Patch Changes

- [#4454](https://github.azc.ext.hp.com/veneer/veneer/pull/4454) [`8c3754661`](https://github.azc.ext.hp.com/veneer/veneer/commit/8c37546610f20b51be4e676ac956d160f20f8613) Thanks [@mateus-domingos](https://github.azc.ext.hp.com/mateus-domingos)! - [Password] Remove `margin-top` when password requirements are hidden

* [#4448](https://github.azc.ext.hp.com/veneer/veneer/pull/4448) [`5fa5d041e`](https://github.azc.ext.hp.com/veneer/veneer/commit/5fa5d041ed7dc665c0b4474d11e4a461a3513475) Thanks [@jordan-matthew-edelston](https://github.azc.ext.hp.com/jordan-matthew-edelston)! - [ToastProvider] Add support to `HTMLElement` type on `domRoot` property

- [#4457](https://github.azc.ext.hp.com/veneer/veneer/pull/4457) [`52dc3fbdf`](https://github.azc.ext.hp.com/veneer/veneer/commit/52dc3fbdfb45fa7af0ec48c2c8e1b90002ca8d58) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - [SideMenu] Add CSS transition to expand icon

* [#4445](https://github.azc.ext.hp.com/veneer/veneer/pull/4445) [`f1d933969`](https://github.azc.ext.hp.com/veneer/veneer/commit/f1d93396905e41cc2ef3f8500727376b3cf1bfc2) Thanks [@louise](https://github.azc.ext.hp.com/louise)! - [FilePicker] Fix Label Overlapping

- [#4450](https://github.azc.ext.hp.com/veneer/veneer/pull/4450) [`c84230a9a`](https://github.azc.ext.hp.com/veneer/veneer/commit/c84230a9a5b27af8efcf908dce21432d9dc9d38f) Thanks [@mateus-domingos](https://github.azc.ext.hp.com/mateus-domingos)! - [Password] Fix input size

* [#4424](https://github.azc.ext.hp.com/veneer/veneer/pull/4424) [`867afe7b6`](https://github.azc.ext.hp.com/veneer/veneer/commit/867afe7b62ff3f106995b903bbe655c08b8ef753) Thanks [@mateus-domingos](https://github.azc.ext.hp.com/mateus-domingos)! - [DatePicker] Fix size and spacing of range version.

- [#4441](https://github.azc.ext.hp.com/veneer/veneer/pull/4441) [`ee1a39e21`](https://github.azc.ext.hp.com/veneer/veneer/commit/ee1a39e21fc78a9e57f0fa1c216b51697f45026d) Thanks [@pedro-henrique-passos-leite](https://github.azc.ext.hp.com/pedro-henrique-passos-leite)! - [Icons] Rename `IconNotebook` to `IconLaptop`.

* [#4462](https://github.azc.ext.hp.com/veneer/veneer/pull/4462) [`4a3b066e5`](https://github.azc.ext.hp.com/veneer/veneer/commit/4a3b066e5707403f30ce0ec6c16aa1251f5f12f9) Thanks [@mateus-domingos](https://github.azc.ext.hp.com/mateus-domingos)! - [App Header] Fix HP logo color

* Updated dependencies [[`e430ea1eb`](https://github.azc.ext.hp.com/veneer/veneer/commit/e430ea1eb366a7a70e65db0142d50098d0e73673)]:
  - @veneer/theme@3.54.0

## 3.54.0

### Minor Changes

- [#4409](https://github.azc.ext.hp.com/veneer/veneer/pull/4409) [`ce21565a5`](https://github.azc.ext.hp.com/veneer/veneer/commit/ce21565a58524a88889fb719deab92b0a827ba34) Thanks [@pedro-henrique-passos-leite](https://github.azc.ext.hp.com/pedro-henrique-passos-leite)! - - [Icons] Deprecate `IconTapTouch` for `IconGestureTap`.
  - [Icons] Deprecate `IconDevices` for `IconDevicesLaptopPrinter`.
  - [Icons] Add `IconDevicesLaptopMouse`, `IconEnvironmentalSound`, `IconGesturePress` and `IconMusicNote` to the library.

* [#4401](https://github.azc.ext.hp.com/veneer/veneer/pull/4401) [`ae3112e8e`](https://github.azc.ext.hp.com/veneer/veneer/commit/ae3112e8e9d689567b0b58a758e6aad5433608b0) Thanks [@pedro-henrique-passos-leite](https://github.azc.ext.hp.com/pedro-henrique-passos-leite)! - [AppHeader][sidemenu] Add custom `responsiveBreakpoint` prop

### Patch Changes

- [#4410](https://github.azc.ext.hp.com/veneer/veneer/pull/4410) [`28e7f55cf`](https://github.azc.ext.hp.com/veneer/veneer/commit/28e7f55cf417e92b0f3f31fac4b0d15e378dc722) Thanks [@mateus-domingos](https://github.azc.ext.hp.com/mateus-domingos)! - [Pagination] Add hover effect only for devices that support hover

* [#4398](https://github.azc.ext.hp.com/veneer/veneer/pull/4398) [`85823863f`](https://github.azc.ext.hp.com/veneer/veneer/commit/85823863f0af759da267a0aff188adcf8733f0be) Thanks [@julihermes-silva](https://github.azc.ext.hp.com/julihermes-silva)! - [DatePicker] Change clearIcon prop to `true` as default.

- [#4418](https://github.azc.ext.hp.com/veneer/veneer/pull/4418) [`bb4c6f597`](https://github.azc.ext.hp.com/veneer/veneer/commit/bb4c6f597d9be913a77c6ce8a126b0da21eb6edd) Thanks [@bianca-camargo-machado1](https://github.azc.ext.hp.com/bianca-camargo-machado1)! - [Icons] Update `IconGlobe` and `IconGlobeOff`.

* [#4411](https://github.azc.ext.hp.com/veneer/veneer/pull/4411) [`d66f6a4ff`](https://github.azc.ext.hp.com/veneer/veneer/commit/d66f6a4ffbd9d7ce7bce68ca3e94e44f040519aa) Thanks [@julihermes-silva](https://github.azc.ext.hp.com/julihermes-silva)! - [Table] Altered resize calc to properly calculate table offsets.

- [#4396](https://github.azc.ext.hp.com/veneer/veneer/pull/4396) [`e20224216`](https://github.azc.ext.hp.com/veneer/veneer/commit/e20224216317b79823c0667cda0ba7eb48058723) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - Mark value as required in OptionInterface

* [#4412](https://github.azc.ext.hp.com/veneer/veneer/pull/4412) [`30157e5b8`](https://github.azc.ext.hp.com/veneer/veneer/commit/30157e5b879774f8710ad903120ffbefa7364e18) Thanks [@bianca-camargo-machado1](https://github.azc.ext.hp.com/bianca-camargo-machado1)! - [Select] Fix unfocused option list using `NVDA` and after searching.

- [#4389](https://github.azc.ext.hp.com/veneer/veneer/pull/4389) [`7d5dffe8b`](https://github.azc.ext.hp.com/veneer/veneer/commit/7d5dffe8bc7e6bcab25de4b75e48cbe64246d8e6) Thanks [@pedro-henrique-passos-leite](https://github.azc.ext.hp.com/pedro-henrique-passos-leite)! - [SegmentedControl] Update `border-radius` value

## 3.53.0

### Minor Changes

- [#4379](https://github.azc.ext.hp.com/veneer/veneer/pull/4379) [`d600198ee`](https://github.azc.ext.hp.com/veneer/veneer/commit/d600198eeefe728c314b74c0068dbdecab461f37) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [Infra] Support React 18

* [#4377](https://github.azc.ext.hp.com/veneer/veneer/pull/4377) [`e6680bb20`](https://github.azc.ext.hp.com/veneer/veneer/commit/e6680bb20e3d25677105bc0f85b7453789191885) Thanks [@pedro-henrique-passos-leite](https://github.azc.ext.hp.com/pedro-henrique-passos-leite)! - [Icon] Add `IconEarbuds`, `IconSoundWavesLeft`, `IconSoundWavesRight`, `IconSurroundSound` and `IconSurroundSoundFront` to the library.

- [#4345](https://github.azc.ext.hp.com/veneer/veneer/pull/4345) [`bac885443`](https://github.azc.ext.hp.com/veneer/veneer/commit/bac885443d4cf4e2f25be400a201cf5469e6ea7b) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [Icon] Deprecate `IconPrinterCheck`, add `IconPrinterCheckmark` and update `IconPrinterHelp`, `IconPrinterInfo`, `IconPrinterMinus`, `IconPrinterPin` and `IconPrinterWarning`

* [#4376](https://github.azc.ext.hp.com/veneer/veneer/pull/4376) [`c5b1d10f6`](https://github.azc.ext.hp.com/veneer/veneer/commit/c5b1d10f695b8c0531f45499318dab1234ab805e) Thanks [@mateus-domingos](https://github.azc.ext.hp.com/mateus-domingos)! - [Icon] Add IconPriceTag to library.

- [#4348](https://github.azc.ext.hp.com/veneer/veneer/pull/4348) [`8c92c887c`](https://github.azc.ext.hp.com/veneer/veneer/commit/8c92c887c82381d4ac99fc31e15fa4bc536c6c7d) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [Icon] Deprecate `IconCheckCircle`, `IconBatteryCheck`, `IconShieldCheck`, `IconPrinterAdd` and add `IconCheckmarkCircle`, `IconBatteryCheckmark`, `IconShieldCheckmark`, `IconPrinterPlus`.

* [#4364](https://github.azc.ext.hp.com/veneer/veneer/pull/4364) [`12af3a1de`](https://github.azc.ext.hp.com/veneer/veneer/commit/12af3a1dee22464c7208e7ea8d6875a00c2a0146) Thanks [@mateus-domingos](https://github.azc.ext.hp.com/mateus-domingos)! - [Select] Fix crash when opening select when all options are disabled

- [#4359](https://github.azc.ext.hp.com/veneer/veneer/pull/4359) [`917b88a0c`](https://github.azc.ext.hp.com/veneer/veneer/commit/917b88a0cb41fc272ff0f824c4b87f396417a155) Thanks [@pedro-henrique-passos-leite](https://github.azc.ext.hp.com/pedro-henrique-passos-leite)! - [InlineNotification] Add support for React `node` on the `title` and `description` properties

### Patch Changes

- [#4355](https://github.azc.ext.hp.com/veneer/veneer/pull/4355) [`99211e448`](https://github.azc.ext.hp.com/veneer/veneer/commit/99211e448ad674959a986e3d80a642d906cf8ef5) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - Fix return type of useDirection

* [#4374](https://github.azc.ext.hp.com/veneer/veneer/pull/4374) [`8a90864b8`](https://github.azc.ext.hp.com/veneer/veneer/commit/8a90864b8370100d31efa84dca7f3094d3b07b19) Thanks [@bianca-camargo-machado1](https://github.azc.ext.hp.com/bianca-camargo-machado1)! - [Typography] Fix subtitleLarge spacing on small breakpoint

- [#4378](https://github.azc.ext.hp.com/veneer/veneer/pull/4378) [`dbaa87f2b`](https://github.azc.ext.hp.com/veneer/veneer/commit/dbaa87f2bb98a85d7e5fa1b562365169dcac9ae7) Thanks [@bianca-camargo-machado1](https://github.azc.ext.hp.com/bianca-camargo-machado1)! - [Infra] Update moment dependency to 2.29.4 due to security vulnerability

* [#4336](https://github.azc.ext.hp.com/veneer/veneer/pull/4336) [`a7438ba84`](https://github.azc.ext.hp.com/veneer/veneer/commit/a7438ba8494d7591a409cdeaa9eb7fce7fe83c06) Thanks [@julihermes-silva](https://github.azc.ext.hp.com/julihermes-silva)! - [DatePicker] Fix a bug at certain resolutions on trying to select a date, calendar shifts upwards instead.

- [#4384](https://github.azc.ext.hp.com/veneer/veneer/pull/4384) [`290177730`](https://github.azc.ext.hp.com/veneer/veneer/commit/29017773030577b70364dee9c5fc23455cec33b7) Thanks [@jordan-matthew-edelston](https://github.azc.ext.hp.com/jordan-matthew-edelston)! - [SideMenuItem] Make it listen changes of its expanded prop, to use in controlled mode

* [#4296](https://github.azc.ext.hp.com/veneer/veneer/pull/4296) [`0b166cee3`](https://github.azc.ext.hp.com/veneer/veneer/commit/0b166cee3a0d956b5d40334d87a9c276aaf896dc) Thanks [@mateus-domingos](https://github.azc.ext.hp.com/mateus-domingos)! - [Anchor Menu] Fix and improve behavior: - Highlight the first item on page load; - New property `defaultSelectedAnchor`; - Highlight the bottom linked section.

- [#4321](https://github.azc.ext.hp.com/veneer/veneer/pull/4321) [`188095da8`](https://github.azc.ext.hp.com/veneer/veneer/commit/188095da863bd6d293f16c939df6477e74e145fe) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - [TextBox] Add extra `type` prop types

* [#4385](https://github.azc.ext.hp.com/veneer/veneer/pull/4385) [`c85907ce8`](https://github.azc.ext.hp.com/veneer/veneer/commit/c85907ce8141739a18f89f437c204ecd92e4208e) Thanks [@julihermes-silva](https://github.azc.ext.hp.com/julihermes-silva)! - [FilePicker] Fixed a issue that FilePicker it`s showing on top of modal

- [#4369](https://github.azc.ext.hp.com/veneer/veneer/pull/4369) [`f78e174a5`](https://github.azc.ext.hp.com/veneer/veneer/commit/f78e174a5e24bbb4e82e6d7f721ee935d2e6b446) Thanks [@bianca-camargo-machado1](https://github.azc.ext.hp.com/bianca-camargo-machado1)! - [Typography] Fix Title Large on medium breakpoint

* [#4320](https://github.azc.ext.hp.com/veneer/veneer/pull/4320) [`d63b5c09b`](https://github.azc.ext.hp.com/veneer/veneer/commit/d63b5c09b860c4c2a03bd0813320c02389c1865f) Thanks [@jordan-matthew-edelston](https://github.azc.ext.hp.com/jordan-matthew-edelston)! - [SideMenuGroup] Improve a11y on navigation group labelling

* Updated dependencies [[`d600198ee`](https://github.azc.ext.hp.com/veneer/veneer/commit/d600198eeefe728c314b74c0068dbdecab461f37), [`8a90864b8`](https://github.azc.ext.hp.com/veneer/veneer/commit/8a90864b8370100d31efa84dca7f3094d3b07b19), [`50afeb501`](https://github.azc.ext.hp.com/veneer/veneer/commit/50afeb501dc76922aed6c5c4a913baf27cf50f5f), [`f78e174a5`](https://github.azc.ext.hp.com/veneer/veneer/commit/f78e174a5e24bbb4e82e6d7f721ee935d2e6b446)]:
  - @veneer/styles@3.53.0
  - @veneer/theme@3.53.0

## 3.52.0

### Minor Changes

- [#4255](https://github.azc.ext.hp.com/veneer/veneer/pull/4255) [`122e3a6b2`](https://github.azc.ext.hp.com/veneer/veneer/commit/122e3a6b2b66a8c5fec47010233dd4fba0bbeb3c) Thanks [@bianca-camargo-machado1](https://github.azc.ext.hp.com/bianca-camargo-machado1)! - Update typography to Forma DJR

  ⚠ `title-large--light`, `title-medium--light`, `title-regular--light`, `title-small--light`, `subtitle-large--light`, and `subtitle-regular--light` styles have been deprecated and it'll be removed in the next major release.

  ⚠ `fontFamilyLight` and `fontFamilyRegular`tokens have been deprecated and it'll be removed in the next major release.

  ⚠ The current fallback font for Middle East is Arial.

  🆕 New tokens: `fontTextRegular`, `fontTextMedium`, and `fontTitleRegular`.

  🎨 Updates on: `letterSpacing1`, `letterSpacing2`, `letterSpacing3`, `letterSpacing4` and `letterSpacing5` tokens.

### Patch Changes

- Updated dependencies [[`122e3a6b2`](https://github.azc.ext.hp.com/veneer/veneer/commit/122e3a6b2b66a8c5fec47010233dd4fba0bbeb3c)]:
  - @veneer/styles@3.52.0
  - @veneer/theme@3.52.0
  - @veneer/tokens@3.52.0

## 3.51.0

### Minor Changes

- [#4304](https://github.azc.ext.hp.com/veneer/veneer/pull/4304) [`eccb98bb7`](https://github.azc.ext.hp.com/veneer/veneer/commit/eccb98bb775cf7d2090445b62bc27c233127824a) Thanks [@julihermes-silva](https://github.azc.ext.hp.com/julihermes-silva)! - [DatePicker] Change flip prop to enable dynamic positioning

* [#4281](https://github.azc.ext.hp.com/veneer/veneer/pull/4281) [`2d1eb79cc`](https://github.azc.ext.hp.com/veneer/veneer/commit/2d1eb79cc577bab574255049d166db16e2f2914f) Thanks [@pedro-henrique-passos-leite](https://github.azc.ext.hp.com/pedro-henrique-passos-leite)! - - Adds `<IconCalendarDay />`, `<IconCalendarMonth />`, `<IconCalendarWeek />`, `<IconPackageDelivered />`, `<IconPackagePacked />`, `<IconPackageShipped />`, `<IconShoppingCartCheckmark />`, and `<IconVpnOff />`.
  - Updates `<IconShoppingCart />` and `<IconVpn />`.

- [#4277](https://github.azc.ext.hp.com/veneer/veneer/pull/4277) [`2ccacbf20`](https://github.azc.ext.hp.com/veneer/veneer/commit/2ccacbf2040ae1b1ce210982b443ba66fb5dc369) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - [Table] Fix Table Resize feature after `loading` state changes

* [#4306](https://github.azc.ext.hp.com/veneer/veneer/pull/4306) [`3f2159f9e`](https://github.azc.ext.hp.com/veneer/veneer/commit/3f2159f9e973a74bbd6521c49f583f6aa13be5f5) Thanks [@mateus-domingos](https://github.azc.ext.hp.com/mateus-domingos)! - [FilePicker] Add props documentation

- [#4312](https://github.azc.ext.hp.com/veneer/veneer/pull/4312) [`de0e083cb`](https://github.azc.ext.hp.com/veneer/veneer/commit/de0e083cbbf1ea3ed30b8d4f1fb316918f4c66c6) Thanks [@bianca-camargo-machado1](https://github.azc.ext.hp.com/bianca-camargo-machado1)! - [Icon] Add new `IconPrinterAdd`, `IconPrinterShield`, and `IconRecycle` and update `IconNvmeDrive`.

### Patch Changes

- Updated dependencies [[`33bc2310e`](https://github.azc.ext.hp.com/veneer/veneer/commit/33bc2310ea69abda290ebda789ce55fb7af27f2d)]:
  - @veneer/theme@3.51.0

## 3.50.0

### Minor Changes

- [#4248](https://github.azc.ext.hp.com/veneer/veneer/pull/4248) [`82284e5bc`](https://github.azc.ext.hp.com/veneer/veneer/commit/82284e5bc1bf0f080c622d8b268a4d54bdb84801) Thanks [@pedro-henrique-passos-leite](https://github.azc.ext.hp.com/pedro-henrique-passos-leite)! - [Icon] Add IconSortUpDown

* [#4249](https://github.azc.ext.hp.com/veneer/veneer/pull/4249) [`87765f787`](https://github.azc.ext.hp.com/veneer/veneer/commit/87765f78778f2afbed3c66c5126fd47e6a2aac4d) Thanks [@pedro-henrique-passos-leite](https://github.azc.ext.hp.com/pedro-henrique-passos-leite)! - [Icons] Update IconIso and IconIsoOff

- [#4246](https://github.azc.ext.hp.com/veneer/veneer/pull/4246) [`b15aff76b`](https://github.azc.ext.hp.com/veneer/veneer/commit/b15aff76bc5e6632da8392b57da966cec1c0515d) Thanks [@pedro-henrique-passos-leite](https://github.azc.ext.hp.com/pedro-henrique-passos-leite)! - [Icon] Update IconIdCardInfo/IconInfo and add IconGhostWaveWall

* [#4257](https://github.azc.ext.hp.com/veneer/veneer/pull/4257) [`a80cfbf77`](https://github.azc.ext.hp.com/veneer/veneer/commit/a80cfbf777e1c5c26735db278576e3ba7b8a1963) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [Table] Add Resize touch support.

- [#4241](https://github.azc.ext.hp.com/veneer/veneer/pull/4241) [`0bc137b21`](https://github.azc.ext.hp.com/veneer/veneer/commit/0bc137b216938cb5043ec12ebe442d0aacc38b1b) Thanks [@mateus-domingos](https://github.azc.ext.hp.com/mateus-domingos)! - [FilePicker] Add useControlled hook

* [#4247](https://github.azc.ext.hp.com/veneer/veneer/pull/4247) [`1b7c562d1`](https://github.azc.ext.hp.com/veneer/veneer/commit/1b7c562d111f0ffcc917a705108ba37b48dc3a31) Thanks [@mateus-domingos](https://github.azc.ext.hp.com/mateus-domingos)! - [Select] Change the type definition for the 'name' property

## 3.49.1

### Patch Changes

- [#4259](https://github.azc.ext.hp.com/veneer/veneer/pull/4259) [`6512e4312`](https://github.azc.ext.hp.com/veneer/veneer/commit/6512e43121e390996f76370b584cf857acf4134a) Thanks [@mateus-domingos](https://github.azc.ext.hp.com/mateus-domingos)! - [Tabs] Move scrollBy behavior to CSS

## 3.49.0

### Minor Changes

- [#4219](https://github.azc.ext.hp.com/veneer/veneer/pull/4219) [`7aa71fc4c`](https://github.azc.ext.hp.com/veneer/veneer/commit/7aa71fc4c88c0dcaf2030ca8b8627e0cf9b2979e) Thanks [@bianca-camargo-machado1](https://github.azc.ext.hp.com/bianca-camargo-machado1)! - [Select] Open select using printable key

* [#4225](https://github.azc.ext.hp.com/veneer/veneer/pull/4225) [`ed8a0d1e0`](https://github.azc.ext.hp.com/veneer/veneer/commit/ed8a0d1e018f109b21bc4a625b6035d852e53a8c) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [Icon] Add ADV, Devices, Diagnose, Printables and Scan. Deprecate DocumentPhone in favor of MobileFax.

- [#4210](https://github.azc.ext.hp.com/veneer/veneer/pull/4210) [`2cf1071fb`](https://github.azc.ext.hp.com/veneer/veneer/commit/2cf1071fb75d521468990714138edc06a454f44a) Thanks [@eduardo-lima](https://github.azc.ext.hp.com/eduardo-lima)! - [Table] Resize feature

* [#4163](https://github.azc.ext.hp.com/veneer/veneer/pull/4163) [`61ac2bc7a`](https://github.azc.ext.hp.com/veneer/veneer/commit/61ac2bc7a1229b0ce8ab4d0ee77f1a649ae15599) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - [Select] Improve type definitions: `onChange.option` as required, `value` as required, allow boolean values, and `onChange` returns the same type of Select values

## 3.48.1

### Patch Changes

- [#4221](https://github.azc.ext.hp.com/veneer/veneer/pull/4221) [`edb764cc2`](https://github.azc.ext.hp.com/veneer/veneer/commit/edb764cc2d4ae032db6fefd1a2d9932f6bd168ba) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - [Table] Update disableResetToDefault property to optional

## 3.48.0

### Minor Changes

- [#4199](https://github.azc.ext.hp.com/veneer/veneer/pull/4199) [`bb700404b`](https://github.azc.ext.hp.com/veneer/veneer/commit/bb700404bff662e26234a475609353d1eee7e857) Thanks [@bianca-camargo-machado1](https://github.azc.ext.hp.com/bianca-camargo-machado1)! - [Icon] Add Collaboration icon

* [#4192](https://github.azc.ext.hp.com/veneer/veneer/pull/4192) [`1f12c4449`](https://github.azc.ext.hp.com/veneer/veneer/commit/1f12c4449cf50be48aa88afb7fc5ae59b1d69ef8) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [Icons] Add sharp version of IconLockCircle.

- [#4200](https://github.azc.ext.hp.com/veneer/veneer/pull/4200) [`ec11cedc5`](https://github.azc.ext.hp.com/veneer/veneer/commit/ec11cedc51af4f1b7f715193590b45e4cfff9372) Thanks [@pedro-henrique-passos-leite](https://github.azc.ext.hp.com/pedro-henrique-passos-leite)! - [Select] Fix input focus logic

* [#4186](https://github.azc.ext.hp.com/veneer/veneer/pull/4186) [`60592ecc6`](https://github.azc.ext.hp.com/veneer/veneer/commit/60592ecc647be369a51edc2666f9a67a67fccebe) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [Table] Add new property `disableResetToDefault` that will control the disabled state of the button.
  ⚠️ Due to performance issues, the Table can no longer control this state. Now the `disableResetToDefault` prop and `onResetToDefault` callback will be under `preferences`, so please update your code.

- [#4194](https://github.azc.ext.hp.com/veneer/veneer/pull/4194) [`69db9431b`](https://github.azc.ext.hp.com/veneer/veneer/commit/69db9431bacc86f2a4dbafdcb331898d2cd9fff0) Thanks [@bianca-camargo-machado1](https://github.azc.ext.hp.com/bianca-camargo-machado1)! - [Icon] Add Caret Left, Caret Right, Caret Up and rename Caret to Caret Down

* [#4211](https://github.azc.ext.hp.com/veneer/veneer/pull/4211) [`c3dd63289`](https://github.azc.ext.hp.com/veneer/veneer/commit/c3dd63289e5298fa8b45ee518eb043630cab50b0) Thanks [@mateus-domingos](https://github.azc.ext.hp.com/mateus-domingos)! - [Search] Fix suggestion list closing after selecting an option

- [#4197](https://github.azc.ext.hp.com/veneer/veneer/pull/4197) [`06b1b2954`](https://github.azc.ext.hp.com/veneer/veneer/commit/06b1b295493d1fe68db7d51c95eb365e23351ac0) Thanks [@bianca-camargo-machado1](https://github.azc.ext.hp.com/bianca-camargo-machado1)! - [Icon] Update Bluetooth, Bluetooth Off, Camera and Camera Off. Add Chip, CPUCorei3, CPUCorei5, CPUCorei7, CPUCorei9, Fingerprint Reader, Optical Drive, PCIEfull, Smartcard Reader and SSD icons.

## 3.47.0

### Minor Changes

- [#4174](https://github.azc.ext.hp.com/veneer/veneer/pull/4174) [`a900ee97d`](https://github.azc.ext.hp.com/veneer/veneer/commit/a900ee97d78741e40a65d4356c56fbf3364fe464) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [Security] Update dependencies listed on Dependabot alerts

* [#4178](https://github.azc.ext.hp.com/veneer/veneer/pull/4178) [`a3d2482de`](https://github.azc.ext.hp.com/veneer/veneer/commit/a3d2482dea6bf2cac53b39bc7bdd2a872693d5d0) Thanks [@bianca-camargo-machado1](https://github.azc.ext.hp.com/bianca-camargo-machado1)! - [Icon] Fix Modifier size of icons: Calendar Ink, Calendar Wrench, Monitor Search, Supplies, Battery Check and Calendar Clock

- [#4180](https://github.azc.ext.hp.com/veneer/veneer/pull/4180) [`4b81083f6`](https://github.azc.ext.hp.com/veneer/veneer/commit/4b81083f619872776032ba0480b72f5cb1d87323) Thanks [@bianca-camargo-machado1](https://github.azc.ext.hp.com/bianca-camargo-machado1)! - [Icon] Updates for Cable Warning, Envelope, Envelope Minus Circle, Envelope Plus Circle, Microphone Warning, Monitor Warning, Wifi Disconnected and Wifi Warning

* [#4176](https://github.azc.ext.hp.com/veneer/veneer/pull/4176) [`85295a295`](https://github.azc.ext.hp.com/veneer/veneer/commit/85295a29580db1e3740c006569b651f915e52597) Thanks [@pedro-henrique-passos-leite](https://github.azc.ext.hp.com/pedro-henrique-passos-leite)! - [Button] Deprecate `tertiary` Button appearance in favor of `ghost` appearance

- [#4177](https://github.azc.ext.hp.com/veneer/veneer/pull/4177) [`286293cb8`](https://github.azc.ext.hp.com/veneer/veneer/commit/286293cb89185e894fd09e1799b18275d54fad95) Thanks [@bianca-camargo-machado1](https://github.azc.ext.hp.com/bianca-camargo-machado1)! - [Icon] Icons in Print Category - Filled versions

      ⚠ The old "IconRibbon" is "IconRibbonCheckmark" now and "IconRibbon" has a new SVG

### Patch Changes

- Updated dependencies [[`85295a295`](https://github.azc.ext.hp.com/veneer/veneer/commit/85295a29580db1e3740c006569b651f915e52597)]:
  - @veneer/theme@3.47.0

## 3.46.0

### Minor Changes

- [#4150](https://github.azc.ext.hp.com/veneer/veneer/pull/4150) [`649d3eb20`](https://github.azc.ext.hp.com/veneer/veneer/commit/649d3eb201240443c8bc5549b1a5d13dd4e978b2) Thanks [@bianca-camargo-machado1](https://github.azc.ext.hp.com/bianca-camargo-machado1)! - [Icon] Add IconCaret and IconCircle and update IconAsterisk, IconGear and IconCalendar

* [#4143](https://github.azc.ext.hp.com/veneer/veneer/pull/4143) [`b11b0a1fb`](https://github.azc.ext.hp.com/veneer/veneer/commit/b11b0a1fb4a5d48972ae9f156c8cb3536eed832b) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - [ToastNotification] Mark addToast, removeToast, toasts and updateToast as required

- [#4155](https://github.azc.ext.hp.com/veneer/veneer/pull/4155) [`c483ebea0`](https://github.azc.ext.hp.com/veneer/veneer/commit/c483ebea06e7fbbdfca146af7783b9d62cd60ad2) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [Table] Enhance column reorder performance

## 3.45.1

### Patch Changes

- [#4149](https://github.azc.ext.hp.com/veneer/veneer/pull/4149) [`d14e35715`](https://github.azc.ext.hp.com/veneer/veneer/commit/d14e3571594bf1f55c5204ecb7273df9c819c54a) Thanks [@bianca-camargo-machado1](https://github.azc.ext.hp.com/bianca-camargo-machado1)! - [Icon] Fix the "Eye" in lined state

## 3.45.0

### Minor Changes

- [#4121](https://github.azc.ext.hp.com/veneer/veneer/pull/4121) [`a0abd3f23`](https://github.azc.ext.hp.com/veneer/veneer/commit/a0abd3f23f712bc0a749e3503af45a762b0fd617) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - [TextBox] Add email, url and number as valid types to inputs

- [#4124](https://github.azc.ext.hp.com/veneer/veneer/pull/4124) [`b7ab1d6aa`](https://github.azc.ext.hp.com/veneer/veneer/commit/b7ab1d6aac15bdbf5929a26f7c22291daba8d90c) Thanks [@eduardo-lima](https://github.azc.ext.hp.com/eduardo-lima)! - [Table] Add table cells with icon story to storybook

* [#4115](https://github.azc.ext.hp.com/veneer/veneer/pull/4115) [`ecbcbd6ad`](https://github.azc.ext.hp.com/veneer/veneer/commit/ecbcbd6ad82874ee01d57e590ec8cb6fd5b3664f) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - [Table] Add rerenderColumnsOnLoad prop

- [#4116](https://github.azc.ext.hp.com/veneer/veneer/pull/4116) [`45cde3755`](https://github.azc.ext.hp.com/veneer/veneer/commit/45cde3755f3947e2abbdfbe07e9719e701d9be97) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [Stepper] Step changing size when label is longer.

* [#4117](https://github.azc.ext.hp.com/veneer/veneer/pull/4117) [`78bba6f22`](https://github.azc.ext.hp.com/veneer/veneer/commit/78bba6f226c696685c52262a906bb0dd1718d155) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [Icons] Update IconBatteryWarning and IconChatAlt

- [#4132](https://github.azc.ext.hp.com/veneer/veneer/pull/4132) [`78035de07`](https://github.azc.ext.hp.com/veneer/veneer/commit/78035de07539893eef280fea0e3c45935b47414d) Thanks [@eduardo-lima](https://github.azc.ext.hp.com/eduardo-lima)! - [Icon] Add new batch of icons

* [#4123](https://github.azc.ext.hp.com/veneer/veneer/pull/4123) [`c9993574b`](https://github.azc.ext.hp.com/veneer/veneer/commit/c9993574bf284502de9e4dc6eb368d3ac28d525a) Thanks [@bianca-camargo-machado1](https://github.azc.ext.hp.com/bianca-camargo-machado1)! - [IconCreditCard] Fix sharp lined SVG

- [#4120](https://github.azc.ext.hp.com/veneer/veneer/pull/4120) [`e6211325f`](https://github.azc.ext.hp.com/veneer/veneer/commit/e6211325f1f30ca83eaf53b5845f8a3e87d93446) Thanks [@bianca-camargo-machado1](https://github.azc.ext.hp.com/bianca-camargo-machado1)! - [Icon] Update filled state for open shape icons

* [#4108](https://github.azc.ext.hp.com/veneer/veneer/pull/4108) [`6a54a2fca`](https://github.azc.ext.hp.com/veneer/veneer/commit/6a54a2fca45f5fa31b013d076625df85508430cf) Thanks [@eduardo-lima](https://github.azc.ext.hp.com/eduardo-lima)! - [Icon] Added and updated Speaker, Microphone and Wifi related icons. Wifi icon renamed to Wifi100.

- [#4118](https://github.azc.ext.hp.com/veneer/veneer/pull/4118) [`c0dddb8d4`](https://github.azc.ext.hp.com/veneer/veneer/commit/c0dddb8d463fef243c58daffbad034c2b006a52d) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [Typography] Add new type style "Label Small".

### Patch Changes

- Updated dependencies [[`c0dddb8d4`](https://github.azc.ext.hp.com/veneer/veneer/commit/c0dddb8d463fef243c58daffbad034c2b006a52d)]:
  - @veneer/styles@3.45.0

## 3.44.0

### Minor Changes

- [#4059](https://github.azc.ext.hp.com/veneer/veneer/pull/4059) [`99e043d7f`](https://github.azc.ext.hp.com/veneer/veneer/commit/99e043d7fd635ec7b33280fd24585ea56f22e384) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [Infra] Update dependencies due to security vulnerabilities.

* [#4080](https://github.azc.ext.hp.com/veneer/veneer/pull/4080) [`d80130cea`](https://github.azc.ext.hp.com/veneer/veneer/commit/d80130ceae1ec618293c6c70f9cf3f7030b59be2) Thanks [@eduardo-lima](https://github.azc.ext.hp.com/eduardo-lima)! - [Tabs] Prevent contained mode with attached type

- [#4078](https://github.azc.ext.hp.com/veneer/veneer/pull/4078) [`f88a426ce`](https://github.azc.ext.hp.com/veneer/veneer/commit/f88a426ce9b47b0c8b293b4ae41bd0992ada7083) Thanks [@eduardo-lima](https://github.azc.ext.hp.com/eduardo-lima)! - [Button] Add props documentation

* [#4069](https://github.azc.ext.hp.com/veneer/veneer/pull/4069) [`5e421fad2`](https://github.azc.ext.hp.com/veneer/veneer/commit/5e421fad2198567a7586924443a320b32baf998f) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [Avatar] Add props documentation.

- [#4097](https://github.azc.ext.hp.com/veneer/veneer/pull/4097) [`0409e9a8d`](https://github.azc.ext.hp.com/veneer/veneer/commit/0409e9a8d379cbb6ce0129d12070b68b2dabf1f7) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [Icon] Add IconPlaceholder to library.

* [#4037](https://github.azc.ext.hp.com/veneer/veneer/pull/4037) [`c52b563e2`](https://github.azc.ext.hp.com/veneer/veneer/commit/c52b563e2fd784574c9f59157afd7c9887db375e) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [FilePicker] Add clear button.

- [#4038](https://github.azc.ext.hp.com/veneer/veneer/pull/4038) [`212ccb0b4`](https://github.azc.ext.hp.com/veneer/veneer/commit/212ccb0b43cf977b8cd4501135389f0ab53d9778) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [HelperText] Update type style

* [#4101](https://github.azc.ext.hp.com/veneer/veneer/pull/4101) [`17e87db5a`](https://github.azc.ext.hp.com/veneer/veneer/commit/17e87db5a2988880cba88d0e607fc07261a4e094) Thanks [@bianca-camargo-machado1](https://github.azc.ext.hp.com/bianca-camargo-machado1)! - [Avatar] Add button and link support

- [#4102](https://github.azc.ext.hp.com/veneer/veneer/pull/4102) [`47a678da3`](https://github.azc.ext.hp.com/veneer/veneer/commit/47a678da37111c76c60ee2aa14c5cbed7e530b97) Thanks [@eduardo-lima](https://github.azc.ext.hp.com/eduardo-lima)! - [Icon] Update export pattern.

  ⚠️ This change shouldn't affect your use of import, but in case of any issues related to it in this version, please contact us.

* [#4092](https://github.azc.ext.hp.com/veneer/veneer/pull/4092) [`77f88d5`](https://github.azc.ext.hp.com/veneer/veneer/commit/77f88d5dba04a18ac4554973631fff70b82dd799) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [NotificationCenter] Create new unread visual cue.

* [#4093](https://github.azc.ext.hp.com/veneer/veneer/pull/4093) [`1f4eba7e6`](https://github.azc.ext.hp.com/veneer/veneer/commit/1f4eba7e64713f25428e84c5d9521e84e5a1e77d) Thanks [@eduardo-lima](https://github.azc.ext.hp.com/eduardo-lima)! - [Icon] Update Folder and FolderOpen icons.

- [#4055](https://github.azc.ext.hp.com/veneer/veneer/pull/4055) [`45a9fd76d`](https://github.azc.ext.hp.com/veneer/veneer/commit/45a9fd76da7407dfca686ca00004c6af5ff64b19) Thanks [@bianca-camargo-machado1](https://github.azc.ext.hp.com/bianca-camargo-machado1)! - [Search] Fix Chinese composition on Firefox

* [#4076](https://github.azc.ext.hp.com/veneer/veneer/pull/4076) [`1b84b4993`](https://github.azc.ext.hp.com/veneer/veneer/commit/1b84b499346be0e49f1d60651429e3bf6f7b3475) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [Breadcrumbs] Add props documentation.

- [#4067](https://github.azc.ext.hp.com/veneer/veneer/pull/4067) [`669f17af6`](https://github.azc.ext.hp.com/veneer/veneer/commit/669f17af678d40b94e55435ac8882647765ed9be) Thanks [@eduardo-lima](https://github.azc.ext.hp.com/eduardo-lima)! - [Select] Add props documentation for Select component

### Patch Changes

- Updated dependencies [[`17e87db5a`](https://github.azc.ext.hp.com/veneer/veneer/commit/17e87db5a2988880cba88d0e607fc07261a4e094)]:
  - @veneer/theme@3.44.0

## 3.43.0

### Minor Changes

- [#4070](https://github.azc.ext.hp.com/veneer/veneer/pull/4070) [`4c82d0f44`](https://github.azc.ext.hp.com/veneer/veneer/commit/4c82d0f44ec29ce1813a3a8b15a8f4ffd3ce3271) Thanks [@eduardo-lima](https://github.azc.ext.hp.com/eduardo-lima)! - [Icon] Icons added: MicrophoneWarning and MonitorWarning. Icon updated: CableWarning.

## 3.42.1

### Patch Changes

- [#4062](https://github.azc.ext.hp.com/veneer/veneer/pull/4062) [`c38266495`](https://github.azc.ext.hp.com/veneer/veneer/commit/c38266495b124542bf2aa3672b1758092e79497f) Thanks [@bianca-camargo-machado1](https://github.azc.ext.hp.com/bianca-camargo-machado1)! - [Icon] Export new icons: IconFactoryReset, IconFileManager, IconIso, IconIsoOff, IconLockAccount, IconPcMode, IconProxy, IconResetPassword and IconUsbThumbdriveOff

## 3.42.0

### Minor Changes

- [#4022](https://github.azc.ext.hp.com/veneer/veneer/pull/4022) [`2048f41e9`](https://github.azc.ext.hp.com/veneer/veneer/commit/2048f41e9fec486f902207294590fbd08b571dcf) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [AppHeader] Fix label style

* [#4018](https://github.azc.ext.hp.com/veneer/veneer/pull/4018) [`046199102`](https://github.azc.ext.hp.com/veneer/veneer/commit/04619910218eb5d827c6a80b509b19e6e7a7fd28) Thanks [@eduardo-lima](https://github.azc.ext.hp.com/eduardo-lima)! - [Search] Fix home/end keys text navigation using Search's input when without suggestions

- [#4039](https://github.azc.ext.hp.com/veneer/veneer/pull/4039) [`48780a0ef`](https://github.azc.ext.hp.com/veneer/veneer/commit/48780a0ef41d408601525fb5e2cfdf002ae7484e) Thanks [@bianca-camargo-machado1](https://github.azc.ext.hp.com/bianca-camargo-machado1)! - [ContextualMenu][select] Accept custom icon node without displayName

* [#4026](https://github.azc.ext.hp.com/veneer/veneer/pull/4026) [`231d53e08`](https://github.azc.ext.hp.com/veneer/veneer/commit/231d53e0873774b212fcedc0e3c79bcea2278936) Thanks [@eduardo-lima](https://github.azc.ext.hp.com/eduardo-lima)! - [Table] Added `controlArea` and `actionArea` props to TableHeader's conditional render check

- [#4036](https://github.azc.ext.hp.com/veneer/veneer/pull/4036) [`048edafde`](https://github.azc.ext.hp.com/veneer/veneer/commit/048edafde891ddcff85cb8fa20847a5961bc05b4) Thanks [@eduardo-lima](https://github.azc.ext.hp.com/eduardo-lima)! - Export useMediaQuery hook

* [#4033](https://github.azc.ext.hp.com/veneer/veneer/pull/4033) [`783f47507`](https://github.azc.ext.hp.com/veneer/veneer/commit/783f47507bbb7bcf65dec3920002ea948811e305) Thanks [@eduardo-lima](https://github.azc.ext.hp.com/eduardo-lima)! - [Select] Fix "enter" key on Search and arrow keys navigation

- [#4023](https://github.azc.ext.hp.com/veneer/veneer/pull/4023) [`af56d2e90`](https://github.azc.ext.hp.com/veneer/veneer/commit/af56d2e90a08f94ac75bab56c8008d3d99956d95) Thanks [@eduardo-lima](https://github.azc.ext.hp.com/eduardo-lima)! - [Icon] Added Lock Account, Proxy, Reset Password, VPN, ISO, ISO Off, PC Mode, File Manager, Factory Reset and USB Thumbdrive Off icons. Update VPN and USB Thumbdrive icons.

## 3.41.0

### Minor Changes

- [#3909](https://github.azc.ext.hp.com/veneer/veneer/pull/3909) [`0ff6decee`](https://github.azc.ext.hp.com/veneer/veneer/commit/0ff6decee9906e0ec8946110d46813a2010204fb) Thanks [@wil-linssen](https://github.azc.ext.hp.com/wil-linssen)! - [FilePicker] Add the drag and drop feature

* [#3993](https://github.azc.ext.hp.com/veneer/veneer/pull/3993) [`6010a23e0`](https://github.azc.ext.hp.com/veneer/veneer/commit/6010a23e081b4fcc95ee48f237136808d4f9ea7e) Thanks [@douglas-michaelsen](https://github.azc.ext.hp.com/douglas-michaelsen)! - Fixing the TextArea export.

- [#4006](https://github.azc.ext.hp.com/veneer/veneer/pull/4006) [`615f9344a`](https://github.azc.ext.hp.com/veneer/veneer/commit/615f9344a82b682d52fda90263eb322f8724bb3b) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [Table] Add new callback `onResetToDefault` and disable reset to default button when columns are in `defaultOrder`.

* [#4009](https://github.azc.ext.hp.com/veneer/veneer/pull/4009) [`0257d4ed0`](https://github.azc.ext.hp.com/veneer/veneer/commit/0257d4ed0c2f8713890e80db71887e62009da0e7) Thanks [@bianca-camargo-machado1](https://github.azc.ext.hp.com/bianca-camargo-machado1)! - [Icon] Add PrinterMinus and PrinterWarning and update PrinterCheck, PrinterInfo and PrinterHelp

- [#4007](https://github.azc.ext.hp.com/veneer/veneer/pull/4007) [`2bd8eb6e8`](https://github.azc.ext.hp.com/veneer/veneer/commit/2bd8eb6e812b4d8b30748010ca2eb7a82cb56e28) Thanks [@bianca-camargo-machado1](https://github.azc.ext.hp.com/bianca-camargo-machado1)! - [Input][textbox][Search] Fix composition on controlled mode

* [#4002](https://github.azc.ext.hp.com/veneer/veneer/pull/4002) [`14ef98cd0`](https://github.azc.ext.hp.com/veneer/veneer/commit/14ef98cd019ad6d9d8a7eac9236167ed3c3a1e30) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - [Accordion] Update PropTypes to reflect typescript definitions (items.content, items.header.centralArea, items.header.endArea and items.header.startArea, from PropTypes.element to PropTypes.node)

- [#4011](https://github.azc.ext.hp.com/veneer/veneer/pull/4011) [`26e7f9ede`](https://github.azc.ext.hp.com/veneer/veneer/commit/26e7f9ede5d23d343556995920f46040635297a9) Thanks [@bianca-camargo-machado1](https://github.azc.ext.hp.com/bianca-camargo-machado1)! - Update IconPeople, IconPerson, IconPersonAssist, IconShieldPerson, IconBusinessPerson and IconPersonPlus

* [#3986](https://github.azc.ext.hp.com/veneer/veneer/pull/3986) [`7b0ba25ba`](https://github.azc.ext.hp.com/veneer/veneer/commit/7b0ba25ba94ee1387656139e056a4e03df0449b6) Thanks [@bianca-camargo-machado1](https://github.azc.ext.hp.com/bianca-camargo-machado1)! - [Stepper] Fix step theme object

- [#4000](https://github.azc.ext.hp.com/veneer/veneer/pull/4000) [`088016d74`](https://github.azc.ext.hp.com/veneer/veneer/commit/088016d743672811d8783385a888ce50229f2193) Thanks [@eduardo-lima](https://github.azc.ext.hp.com/eduardo-lima)! - Thumbs Up icon round variants updated and added sharp variants

* [#3999](https://github.azc.ext.hp.com/veneer/veneer/pull/3999) [`1c2fa1d90`](https://github.azc.ext.hp.com/veneer/veneer/commit/1c2fa1d904882a5acdfa2cc3b15964e08164f8c3) Thanks [@eduardo-lima](https://github.azc.ext.hp.com/eduardo-lima)! - Added Empty Circle and Person Circle icons. Updated Slash Circle, Clock, Document, Warning, Check Circle, Pause Circle and X Circle icons.

- [#3941](https://github.azc.ext.hp.com/veneer/veneer/pull/3941) [`2a1ed4ff9`](https://github.azc.ext.hp.com/veneer/veneer/commit/2a1ed4ff97a7a9c00d4d1cb9edb9c4935fa5e425) Thanks [@douglas-michaelsen](https://github.azc.ext.hp.com/douglas-michaelsen)! - Adding Changesets support for versioning and changelog generation.

* [#3989](https://github.azc.ext.hp.com/veneer/veneer/pull/3989) [`fe9508f19`](https://github.azc.ext.hp.com/veneer/veneer/commit/fe9508f198dc70c679be553506f40a4a36ab82f9) Thanks [@bianca-camargo-machado1](https://github.azc.ext.hp.com/bianca-camargo-machado1)! - [Flag] Avoid replacing default black color by the themes variables

- [#3971](https://github.azc.ext.hp.com/veneer/veneer/pull/3971) [`eb45fd712`](https://github.azc.ext.hp.com/veneer/veneer/commit/eb45fd712fa6f318d5207c7886885ae70b9d356c) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - [ContextualMenu] Add condition to avoid option objects (options prop) containing values of type string and number at the same time

  [Pagination] Update the pageSizeOptions.value to only accept type number

* [#3981](https://github.azc.ext.hp.com/veneer/veneer/pull/3981) [`98217951e`](https://github.azc.ext.hp.com/veneer/veneer/commit/98217951ef29a01d0ef878925b4d545486474645) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - Adding icons to lib: IconCableWarning, IconCameraOff, IconChair, IconMarker, IconRemoteControl, IconSprayBottle, IconTemperatureCold, IconTemperatureHot

### Patch Changes

- Updated dependencies [[`7b0ba25ba`](https://github.azc.ext.hp.com/veneer/veneer/commit/7b0ba25ba94ee1387656139e056a4e03df0449b6)]:
  - @veneer/theme@3.41.0
