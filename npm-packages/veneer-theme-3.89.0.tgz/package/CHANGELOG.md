# @veneer/theme

## 3.89.0

### Minor Changes

- [#6976](https://github.azc.ext.hp.com/veneer/veneer/pull/6976) [`dc378eb`](https://github.azc.ext.hp.com/veneer/veneer/commit/dc378eb376bf82f7e71e321edc23b500059161da) Thanks [@joao-flores-de-leao](https://github.azc.ext.hp.com/joao-flores-de-leao)! - [DatePicker]
  [FilePicker]
  [Password]
  [Search]
  [TextArea]
  [TextBox]
  - Restructure of the components -> Inputs are now more independent.
  - Enhanced documentation -> typescript and inherited props were validate and corrected.
  - Accessibility conformance -> Restructure of the component impact on the DOM and more relationship between inputs, labels and helper texts.
  - Redesign FilePicker to match other inputs design.
  - Separate Range DatePicker inputs interaction for better accessibility.
  - For more information, check our latest announcement on our website https://veneer.hpbp.io/

### Patch Changes

- [#6978](https://github.azc.ext.hp.com/veneer/veneer/pull/6978) [`f3bf166`](https://github.azc.ext.hp.com/veneer/veneer/commit/f3bf166dff615e06e7514a1fd816c5b9d3ef8e61) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - [Infra] Ensure compatibility with React 19 types

## 3.88.1

### Patch Changes

- [#6994](https://github.azc.ext.hp.com/veneer/veneer/pull/6994) [`21bbbe7`](https://github.azc.ext.hp.com/veneer/veneer/commit/21bbbe7cb586b75429040ca456ffa6bad5295806) Thanks [@joao-flores-de-leao](https://github.azc.ext.hp.com/joao-flores-de-leao)! - [Foundation] Update foundation packages.

## 3.88.0

### Minor Changes

- [#6961](https://github.azc.ext.hp.com/veneer/veneer/pull/6961) [`d578284`](https://github.azc.ext.hp.com/veneer/veneer/commit/d57828456aeba1c86d52fd7b14ffad4bf5348446) Thanks [@pedro-soares](https://github.azc.ext.hp.com/pedro-soares)! - [Infra] Update @veneer/assets to 3.20 and @veneer/semantics to 3.13

  `stroke.default` is now `stroke.decorative.default`. Please update with your customizing it on `extendedSemantics()`.

## 3.87.0

### Minor Changes

- [#6350](https://github.azc.ext.hp.com/veneer/veneer/pull/6350) [`d89d31f`](https://github.azc.ext.hp.com/veneer/veneer/commit/d89d31f0dd76cc0ae9695f700742eeae66153f0b) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [Table] Remove onSelectAll.

- [#6907](https://github.azc.ext.hp.com/veneer/veneer/pull/6907) [`3867b4e`](https://github.azc.ext.hp.com/veneer/veneer/commit/3867b4e7aed56ca7db80d598baab738c54a5c2e5) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [Typography] `useTheme` now provides all typography helpers.

- [#6350](https://github.azc.ext.hp.com/veneer/veneer/pull/6350) [`d89d31f`](https://github.azc.ext.hp.com/veneer/veneer/commit/d89d31f0dd76cc0ae9695f700742eeae66153f0b) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [SideMenu] Remove toggle, toggleImagePath and deprecated appearances.

## 3.86.0

### Minor Changes

- [#6860](https://github.azc.ext.hp.com/veneer/veneer/pull/6860) [`200772f`](https://github.azc.ext.hp.com/veneer/veneer/commit/200772f3cb7a2973f4cca40e199f58727b3808c1) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [ThemeProvider] Remove `inputBackground`. Our design team opted to have all forms controls with withe background as default. Please stop using this prop since it wont work and theres no way to set transparent. We recommend you stick with white background.

## 3.85.0

### Minor Changes

- [#6759](https://github.azc.ext.hp.com/veneer/veneer/pull/6759) [`20e1aec`](https://github.azc.ext.hp.com/veneer/veneer/commit/20e1aec2ed38d20e74894f7824c4894e1f25e46a) Thanks [@walter-ferreira](https://github.azc.ext.hp.com/walter-ferreira)! - [Typography] Added new classes for `body-regular`, `label-regular` and `caption-regular`.

- [#6786](https://github.azc.ext.hp.com/veneer/veneer/pull/6786) [`6f36500`](https://github.azc.ext.hp.com/veneer/veneer/commit/6f36500ebe55a9e32eb8da64cb95699807e4e87c) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [Infra] Update @veneer/assets to 3.17 and @veneer/semantics to 3.12

## 3.84.0

### Minor Changes

- [#6739](https://github.azc.ext.hp.com/veneer/veneer/pull/6739) [`7fd2719`](https://github.azc.ext.hp.com/veneer/veneer/commit/7fd27194e649cf25a0ad37de4f249a462c737bb5) Thanks [@pedro-soares](https://github.azc.ext.hp.com/pedro-soares)! - [Foundation] Update @veneer/assets to 3.16.0 and update @veneer/semantics to 3.11.0

## 3.83.0

### Minor Changes

- [#6690](https://github.azc.ext.hp.com/veneer/veneer/pull/6690) [`648c69b`](https://github.azc.ext.hp.com/veneer/veneer/commit/648c69bf1c9246ddbea4835439b17208740683bf) Thanks [@anderson-freitas](https://github.azc.ext.hp.com/anderson-freitas)! - [Foundation] Update @veneer/assets to 3.15.0 and update @veneer/semantics to 3.10.0

## 3.82.0

### Minor Changes

- [`88d6465`](https://github.azc.ext.hp.com/veneer/veneer/commit/88d64655c51745115eb75ce9322f934ddfaf5d60) Thanks [@pedro-soares](https://github.azc.ext.hp.com/pedro-soares)! - Removing deprecated React methods to avoid warnings.

- [`9ee153f`](https://github.azc.ext.hp.com/veneer/veneer/commit/9ee153fcdc13f03e341205c556fb24e157583aef) Thanks [@walter-ferreira](https://github.azc.ext.hp.com/walter-ferreira)! - [Foundation] Update @veneer/assets to 3.14.0, update @veneer/primitives to 3.63.0 and update @veneer/semantics to 3.9.0

## 3.81.0

### Minor Changes

- [#6598](https://github.azc.ext.hp.com/veneer/veneer/pull/6598) [`818db74`](https://github.azc.ext.hp.com/veneer/veneer/commit/818db74ae3486ffe550c5d40c45d621906d6d027) Thanks [@anderson-freitas](https://github.azc.ext.hp.com/anderson-freitas)! - [Foundation] Update @veneer/assets to 3.13.0, update @veneer/primitives to 3.62.0 and update @veneer/semantics to 3.8.0

## 3.80.0

### Minor Changes

- [#6475](https://github.azc.ext.hp.com/veneer/veneer/pull/6475) [`e0bfd76`](https://github.azc.ext.hp.com/veneer/veneer/commit/e0bfd76f1da8e9d01a11ac14046bd751448f8fc6) Thanks [@anderson-freitas](https://github.azc.ext.hp.com/anderson-freitas)! - [TextArea] Adjust bottom padding for the textBox with inline label for round shapes and sharp for SD density.Adjust bottom padding for the textBox with inline label for round shapes and sharp for SD density.

## 3.79.0

### Minor Changes

- [#6448](https://github.azc.ext.hp.com/veneer/veneer/pull/6448) [`2ca77c0`](https://github.azc.ext.hp.com/veneer/veneer/commit/2ca77c0ba1efe9d8321e73c93994531f593f16ee) Thanks [@pedro-soares](https://github.azc.ext.hp.com/pedro-soares)! - [Foundation] Update @veneer/assets to 3.9.0, update @veneer/primitives to 3.61.1 and update @veneer/semantics to 3.7.0

## 3.78.0

### Minor Changes

- [#6396](https://github.azc.ext.hp.com/veneer/veneer/pull/6396) [`aa84d22`](https://github.azc.ext.hp.com/veneer/veneer/commit/aa84d221a14b82cd929f71f4d596e033f1759180) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [Foundation] Update @veneer/assets to 3.8.0, update @veneer/primitives to 3.61.0 and update @veneer/semantics to 3.6.0

- [#6298](https://github.azc.ext.hp.com/veneer/veneer/pull/6298) [`a984c97`](https://github.azc.ext.hp.com/veneer/veneer/commit/a984c976285393889a3ba9c53ca312fb765b49dc) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - [React] Update minimum supported react to 16.14.0

  This is in preparation for a future update to React 17; it is strongly recommended to update to React 18.

## 3.77.0

### Minor Changes

- [#6257](https://github.azc.ext.hp.com/veneer/veneer/pull/6257) [`e4c6c7d`](https://github.azc.ext.hp.com/veneer/veneer/commit/e4c6c7dcffd168e43a487edd8a19e6a400bb5a07) Thanks [@joao-flores-de-leao](https://github.azc.ext.hp.com/joao-flores-de-leao)! - [TextBox/Input] Adjust paddings on pill shape.

- [#6257](https://github.azc.ext.hp.com/veneer/veneer/pull/6257) [`e4c6c7d`](https://github.azc.ext.hp.com/veneer/veneer/commit/e4c6c7dcffd168e43a487edd8a19e6a400bb5a07) Thanks [@joao-flores-de-leao](https://github.azc.ext.hp.com/joao-flores-de-leao)! - [Select] Adjust paddings on pill shape.
  [TextArea] Adjust paddings on pill shape.

- [#6257](https://github.azc.ext.hp.com/veneer/veneer/pull/6257) [`e4c6c7d`](https://github.azc.ext.hp.com/veneer/veneer/commit/e4c6c7dcffd168e43a487edd8a19e6a400bb5a07) Thanks [@joao-flores-de-leao](https://github.azc.ext.hp.com/joao-flores-de-leao)! - [SideMenu] Adjust paddings on pill shape.

### Patch Changes

- [#6308](https://github.azc.ext.hp.com/veneer/veneer/pull/6308) [`3b5e8b3`](https://github.azc.ext.hp.com/veneer/veneer/commit/3b5e8b300e4875622d5c26a9cf9e73ddd8ca8ebd) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - [Infra] Update @veneer/semantics to 3.5.0

## 3.76.0

### Minor Changes

- [#6088](https://github.azc.ext.hp.com/veneer/veneer/pull/6088) [`8fa272d`](https://github.azc.ext.hp.com/veneer/veneer/commit/8fa272d76c16b0d17576c0cfcc6b42f33c5d4bcf) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - Veneer packages have moved to a new repository on Nexus.

  In order to simplify Veneer's release process, Veneer packages are only published to the GitHub repository (https://npm.github.azc.ext.hp.com).

  To support users who need to use Nexus, there is a new Nexus repository (https://nexus-int.corp.hpicloud.net/repository/veneer-proxy/) that mirrors the GitHub repository.

  If you are using Nexus, and are unable to switch to GitHub, please update your configuration to point at this new repository.

## 3.75.0

### Minor Changes

- [#6098](https://github.azc.ext.hp.com/veneer/veneer/pull/6098) [`6df1339`](https://github.azc.ext.hp.com/veneer/veneer/commit/6df133991ed07ebc73497ec6749374944d313fc0) Thanks [@walter-ferreira](https://github.azc.ext.hp.com/walter-ferreira)! - Add Pill Shape support and updated Select component

- [#6135](https://github.azc.ext.hp.com/veneer/veneer/pull/6135) [`ff06fd3`](https://github.azc.ext.hp.com/veneer/veneer/commit/ff06fd324e5fdd74155f0cb9f40636d319d1a179) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - Remove inverted theme

## 3.74.0

### Minor Changes

- [`8d2ffa0498`](https://github.azc.ext.hp.com/veneer/veneer/commit/8d2ffa0498a1f433144f68d1b399242b542f9ffb) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [Theme] Update colors.

## 3.73.0

### Minor Changes

- [#5398](https://github.azc.ext.hp.com/veneer/veneer/pull/5398) [`122765e2b`](https://github.azc.ext.hp.com/veneer/veneer/commit/122765e2bbd057601597ea64b60c567901b2fcaf) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - [Infra] Internal code structure changed

  In order to normalise our build steps, internal code structure of the shipped `@veneer/flags` and `@veneer/theme` packages has changed.

  If you are currently importing from the root (e.g. `import { ThemeProvider} from '@veneer/theme'`) then no change is required.

  If you are importing from specific files (which is not recommended), you will need to add `dist` to the root of the import, e.g. `import ThemeProvider from '@vener/theme/dist/theme_provider'`.

## 3.72.0

### Minor Changes

- [#5474](https://github.azc.ext.hp.com/veneer/veneer/pull/5474) [`ead2a3f60d`](https://github.azc.ext.hp.com/veneer/veneer/commit/ead2a3f60de18c41464293205c72ffd920a2bda0) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [TreeView] Update borderRadius on high density.

## 3.71.1

### Patch Changes

- [#5302](https://github.azc.ext.hp.com/veneer/veneer/pull/5302) [`2e2b4df516`](https://github.azc.ext.hp.com/veneer/veneer/commit/2e2b4df516f4782b373731eff02a705bc1d511d1) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - [Coachmark][toastnotification][Tooltip] Update sources to typescript.

## 3.71.0

### Minor Changes

- [#5397](https://github.azc.ext.hp.com/veneer/veneer/pull/5397) [`8f0286084`](https://github.azc.ext.hp.com/veneer/veneer/commit/8f0286084602e9c733d467f829d816ffed681dab) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [Tokens] Consume new tokens package. If your project use tokens outside components, [consider reading this how to migrate guide](https://stackoverflow.hp.dev/articles/6485).

## 3.70.1

### Patch Changes

- [#5316](https://github.azc.ext.hp.com/veneer/veneer/pull/5316) [`5e00d4f67`](https://github.azc.ext.hp.com/veneer/veneer/commit/5e00d4f676fe375fadb86f7b90714a4faa79d0f5) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - [ThemeProvider] Simplified useTheme to improve performance

  The value returned by `useTheme` should now be stable and suitable for use as a dependency in a memo or callback.

## 3.70.0

### Minor Changes

- [#5133](https://github.azc.ext.hp.com/veneer/veneer/pull/5133) [`07c69d2db`](https://github.azc.ext.hp.com/veneer/veneer/commit/07c69d2db819b6f12a58ac04a848e985599b8483) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - [Card] Update card sources to use typescript

## 3.69.0

### Minor Changes

- [#5082](https://github.azc.ext.hp.com/veneer/veneer/pull/5082) [`9d0ed6dce`](https://github.azc.ext.hp.com/veneer/veneer/commit/9d0ed6dcebceb6d0ab3b23c0f55ff9672a9d778e) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [Table] Update component to consume system palette.

* [#5054](https://github.azc.ext.hp.com/veneer/veneer/pull/5054) [`29cc31858`](https://github.azc.ext.hp.com/veneer/veneer/commit/29cc3185807dac01d8c8fcc5e428fbb7da168c47) Thanks [@bruno-chanan](https://github.azc.ext.hp.com/bruno-chanan)! - [DatePicker] Update component to consume system palette.

## 3.68.0

### Minor Changes

- [#5084](https://github.azc.ext.hp.com/veneer/veneer/pull/5084) [`46e70c1cb`](https://github.azc.ext.hp.com/veneer/veneer/commit/46e70c1cb6f85833e9d10776a35c72c87089f8ca) Thanks [@louise](https://github.azc.ext.hp.com/louise)! - [Footer] Update component to consume system palette

* [#5064](https://github.azc.ext.hp.com/veneer/veneer/pull/5064) [`956863031`](https://github.azc.ext.hp.com/veneer/veneer/commit/9568630315e1da960b9311afe8fca392a142111f) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [NotificationCenter] Update component to consume system palette.

- [#5075](https://github.azc.ext.hp.com/veneer/veneer/pull/5075) [`cb3464297`](https://github.azc.ext.hp.com/veneer/veneer/commit/cb346429777f266803acde7b88a646a0eb07aa5c) Thanks [@joao-flores-de-leao](https://github.azc.ext.hp.com/joao-flores-de-leao)! - [SideMenu] Update borders to match system palette.

* [#5061](https://github.azc.ext.hp.com/veneer/veneer/pull/5061) [`77613f2c0`](https://github.azc.ext.hp.com/veneer/veneer/commit/77613f2c072b293d9a7724f054ce5eaa5c9f2d31) Thanks [@ramon-prado](https://github.azc.ext.hp.com/ramon-prado)! - [Avatar] Update component to consume new system palette

- [#5058](https://github.azc.ext.hp.com/veneer/veneer/pull/5058) [`18e81e5f6`](https://github.azc.ext.hp.com/veneer/veneer/commit/18e81e5f6c974f0c6e7076d4f4b001282a72ad96) Thanks [@louise](https://github.azc.ext.hp.com/louise)! - [AnchorMenu] Update component to consume new system palette.

* [#5074](https://github.azc.ext.hp.com/veneer/veneer/pull/5074) [`33dc94360`](https://github.azc.ext.hp.com/veneer/veneer/commit/33dc943604404a893b71ccacdcd9c03065415539) Thanks [@joao-flores-de-leao](https://github.azc.ext.hp.com/joao-flores-de-leao)! - [Header] Update style to use Veneer system colors

### Patch Changes

- Updated dependencies [[`956863031`](https://github.azc.ext.hp.com/veneer/veneer/commit/9568630315e1da960b9311afe8fca392a142111f)]:
  - @veneer/tokens@3.56.0

## 3.67.0

### Minor Changes

- [#5052](https://github.azc.ext.hp.com/veneer/veneer/pull/5052) [`7c9933a90`](https://github.azc.ext.hp.com/veneer/veneer/commit/7c9933a903aba7142ab751a539d2d08559b8a0e7) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [Card] Update component to consume new system palette.

## 3.66.0

### Minor Changes

- [#5023](https://github.azc.ext.hp.com/veneer/veneer/pull/5023) [`073fa800d`](https://github.azc.ext.hp.com/veneer/veneer/commit/073fa800d866df620a86e09b21123e97ea8811b9) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [Select] Add system palette to component.

* [#5021](https://github.azc.ext.hp.com/veneer/veneer/pull/5021) [`2d06c71d0`](https://github.azc.ext.hp.com/veneer/veneer/commit/2d06c71d02021d16d49ccce022c121fe3208966c) Thanks [@louise](https://github.azc.ext.hp.com/louise)! - [SideBar] Update component to consume new system palette.

- [#5013](https://github.azc.ext.hp.com/veneer/veneer/pull/5013) [`a392cde3e`](https://github.azc.ext.hp.com/veneer/veneer/commit/a392cde3ef3a08a9e8f90248cb6dc4eea2b37495) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [Pagination] Update component to consume system palette.

* [#5022](https://github.azc.ext.hp.com/veneer/veneer/pull/5022) [`8d1c8ca70`](https://github.azc.ext.hp.com/veneer/veneer/commit/8d1c8ca70fdb2716689db2027b9e2babd44c35ea) Thanks [@bruno-chanan](https://github.azc.ext.hp.com/bruno-chanan)! - [Coachmark] Update component to consume system palette.

## 3.65.0

### Minor Changes

- [#4999](https://github.azc.ext.hp.com/veneer/veneer/pull/4999) [`e38cd6efd`](https://github.azc.ext.hp.com/veneer/veneer/commit/e38cd6efdc6e409b9ecec7d94bb0e753fb871c4f) Thanks [@bruno-chanan](https://github.azc.ext.hp.com/bruno-chanan)! - [ToastNotification] Update component to consume system palette.

## 3.64.0

### Minor Changes

- [#4965](https://github.azc.ext.hp.com/veneer/veneer/pull/4965) [`92e27fe6b`](https://github.azc.ext.hp.com/veneer/veneer/commit/92e27fe6bdc9c2e42899cdca4f2de8cb807d2bfe) Thanks [@bruno-chanan](https://github.azc.ext.hp.com/bruno-chanan)! - [Tooltip] Update component to consume system palette

* [#4952](https://github.azc.ext.hp.com/veneer/veneer/pull/4952) [`e71499d3f`](https://github.azc.ext.hp.com/veneer/veneer/commit/e71499d3f57ed6ef3cf057420309219d8d1a3f7d) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [FilePicker] Update component to consume new system palette.

- [#4967](https://github.azc.ext.hp.com/veneer/veneer/pull/4967) [`8a08c099b`](https://github.azc.ext.hp.com/veneer/veneer/commit/8a08c099b37197c84f41862ebaef783f062e4638) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [Modal] Update component to consume system palette.

* [#4978](https://github.azc.ext.hp.com/veneer/veneer/pull/4978) [`a847dbdc1`](https://github.azc.ext.hp.com/veneer/veneer/commit/a847dbdc15852abf8189abe20b5314c2c4e16dcd) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [Password] Update component to consume new system palette.

## 3.63.0

### Minor Changes

- [#4907](https://github.azc.ext.hp.com/veneer/veneer/pull/4907) [`a1ab60253`](https://github.azc.ext.hp.com/veneer/veneer/commit/a1ab602532ddf8fc41709671b3f33fe1c5a45d81) Thanks [@jose-lima](https://github.azc.ext.hp.com/jose-lima)! - [Slider] Update component to consume system palette

* [#4903](https://github.azc.ext.hp.com/veneer/veneer/pull/4903) [`93d58e6b0`](https://github.azc.ext.hp.com/veneer/veneer/commit/93d58e6b0db9da2fc30082c407686a99b068b0df) Thanks [@louise](https://github.azc.ext.hp.com/louise)! - [SideMenu] Update style to use Veneer system colors

## 3.62.0

### Minor Changes

- [#4861](https://github.azc.ext.hp.com/veneer/veneer/pull/4861) [`fd7f55d20`](https://github.azc.ext.hp.com/veneer/veneer/commit/fd7f55d20de1d39ce98e374b522043f4dd12b87b) Thanks [@louise](https://github.azc.ext.hp.com/louise)! - [ContextualMenu] Update style to use Veneer system colors

### Patch Changes

- Updated dependencies [[`cae21572e`](https://github.azc.ext.hp.com/veneer/veneer/commit/cae21572e750bb05a4f21b7f8faa3104e9dca331)]:
  - @veneer/tokens@3.55.0

## 3.61.0

### Minor Changes

- [#4865](https://github.azc.ext.hp.com/veneer/veneer/pull/4865) [`00139ed76`](https://github.azc.ext.hp.com/veneer/veneer/commit/00139ed763d4871d844c8e3b4fa43d6a28088cc1) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [Treeview] Update component with new palette system

## 3.60.0

### Minor Changes

- [#4845](https://github.azc.ext.hp.com/veneer/veneer/pull/4845) [`ab30f9b489`](https://github.azc.ext.hp.com/veneer/veneer/commit/ab30f9b4893f95688254168ced9ab57c096b5b78) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [Accordion] Update style to use Veneer system colors

## 3.59.0

### Minor Changes

- [#4793](https://github.azc.ext.hp.com/veneer/veneer/pull/4793) [`04a3cc164`](https://github.azc.ext.hp.com/veneer/veneer/commit/04a3cc164fc732ce38b9ced32f973ef6d940224e) Thanks [@joao-flores-de-leao](https://github.azc.ext.hp.com/joao-flores-de-leao)! - [ProgressIndicator] Update style to use Veneer system colors

## 3.58.2

### Patch Changes

- Updated dependencies [[`f54006e59`](https://github.azc.ext.hp.com/veneer/veneer/commit/f54006e59efbeea95f8b7749ab2ba77367587643)]:
  - @veneer/tokens@3.54.0

## 3.58.1

### Patch Changes

- Updated dependencies [[`33670e428`](https://github.azc.ext.hp.com/veneer/veneer/commit/33670e4289574c355248486d846451f3fb0280ab)]:
  - @veneer/tokens@3.53.1

## 3.58.0

### Minor Changes

- [#4607](https://github.azc.ext.hp.com/veneer/veneer/pull/4607) [`83d8290ac`](https://github.azc.ext.hp.com/veneer/veneer/commit/83d8290ace6fc19ebe49e69fd4506fbb014b2297) Thanks [@pedro-henrique-passos-leite](https://github.azc.ext.hp.com/pedro-henrique-passos-leite)! - [ThemeProvider] Add `customSemantics` prop to enable theme customization

## 3.57.0

### Minor Changes

- [#4567](https://github.azc.ext.hp.com/veneer/veneer/pull/4567) [`8f1718599`](https://github.azc.ext.hp.com/veneer/veneer/commit/8f17185999973630a4c87e334821d83f645efb0d) Thanks [@pedro-henrique-passos-leite](https://github.azc.ext.hp.com/pedro-henrique-passos-leite)! - [Theme][systemcolors] Add `theme.color` object from `@veneer/system` package.

* [#4582](https://github.azc.ext.hp.com/veneer/veneer/pull/4582) [`10d478d04`](https://github.azc.ext.hp.com/veneer/veneer/commit/10d478d044067cba5bc651e82fc0f92354711032) Thanks [@pedro-henrique-passos-leite](https://github.azc.ext.hp.com/pedro-henrique-passos-leite)! - [Theme] Add `@veneer/system` dependency

### Patch Changes

- Updated dependencies [[`6c57a0feb`](https://github.azc.ext.hp.com/veneer/veneer/commit/6c57a0feb5827398fe4ed0c4007299d57fd264cc)]:
  - @veneer/tokens@3.53.0

## 3.56.0

### Minor Changes

- [#4541](https://github.azc.ext.hp.com/veneer/veneer/pull/4541) [`291551ceb`](https://github.azc.ext.hp.com/veneer/veneer/commit/291551cebbdbdbac9c4ca2e1836fca9b8fe59343) Thanks [@bruno-chanan](https://github.azc.ext.hp.com/bruno-chanan)! - [InputFields] Update "label" and "placeholder" color

## 3.55.0

### Minor Changes

- [#4517](https://github.azc.ext.hp.com/veneer/veneer/pull/4517) [`9a4d596c1`](https://github.azc.ext.hp.com/veneer/veneer/commit/9a4d596c19b6a6e681e8bc839e8978ee6604fadf) Thanks [@pedro-henrique-passos-leite](https://github.azc.ext.hp.com/pedro-henrique-passos-leite)! - [Theme] Update theme values of the following colors: `colorDisabledBackground`, `colorNegativeActive`, `colorNegativeHover`, `colorPositiveActive`, `colorPositiveHover`, `colorWarningActive`, `colorWarningHover`.

  [Theme] New colors: `colorNegativeBackgroundLight`, `colorNeutral`, `colorNeutralActive`, `colorNeutralBackground`, `colorNeutralBackgroundLight`, `colorNeutralHover`, `colorPositiveBackgroundLight`, `colorStroke` and `colorWarningBackgroundLight`.

  - ⚠ Deprecated colors: `colorBorderOutlined`, `colorButtonDisabledForeground`, `colorDisabledBorder`, `colorErrorForeground`, `colorInputBorderFilledHover`, `colorNegativeForeground`, `colorNeutralFive`, `colorNeutralFour`, `colorNeutralOne`, `colorNeutralSix`, `colorNeutralThree` and `colorNeutralTwo`.

## 3.54.1

### Patch Changes

- [#4478](https://github.azc.ext.hp.com/veneer/veneer/pull/4478) [`f1d8d4a80`](https://github.azc.ext.hp.com/veneer/veneer/commit/f1d8d4a807cb04808956ec2dc132dd92d3f2717e) Thanks [@louise](https://github.azc.ext.hp.com/louise)! - [SideMenu] Update colors to match Navigation Menu atoms and add pressed state.

## 3.54.0

### Minor Changes

- [#4339](https://github.azc.ext.hp.com/veneer/veneer/pull/4339) [`e430ea1eb`](https://github.azc.ext.hp.com/veneer/veneer/commit/e430ea1eb366a7a70e65db0142d50098d0e73673) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [Scrollbar] Add `css-only` version of the component to library.

  ⚠️ If your project is using the deprecated `Scrollbar`, please update the import:
  `import { deprecated_ScrollBar as Scrollbar } from '@veneer/core'`;

## 3.53.0

### Minor Changes

- [#4379](https://github.azc.ext.hp.com/veneer/veneer/pull/4379) [`d600198ee`](https://github.azc.ext.hp.com/veneer/veneer/commit/d600198eeefe728c314b74c0068dbdecab461f37) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [Infra] Support React 18

### Patch Changes

- [#4356](https://github.azc.ext.hp.com/veneer/veneer/pull/4356) [`50afeb501`](https://github.azc.ext.hp.com/veneer/veneer/commit/50afeb501dc76922aed6c5c4a913baf27cf50f5f) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - Fix return type of `createComponentTheme`

## 3.52.0

### Minor Changes

- [#4255](https://github.azc.ext.hp.com/veneer/veneer/pull/4255) [`122e3a6b2`](https://github.azc.ext.hp.com/veneer/veneer/commit/122e3a6b2b66a8c5fec47010233dd4fba0bbeb3c) Thanks [@bianca-camargo-machado1](https://github.azc.ext.hp.com/bianca-camargo-machado1)! - Update typography to Forma DJR

  ⚠ `title-large--light`, `title-medium--light`, `title-regular--light`, `title-small--light`, `subtitle-large--light`, and `subtitle-regular--light` styles have been deprecated and it'll be removed in the next major release.

  ⚠ `fontFamilyLight` and `fontFamilyRegular`tokens have been deprecated and it'll be removed in the next major release.

  ⚠ The current fallback font for Middle East is Arial.

  🆕 New tokens: `fontTextRegular`, `fontTextMedium`, and `fontTitleRegular`.

  🎨 Updates on: `letterSpacing1`, `letterSpacing2`, `letterSpacing3`, `letterSpacing4` and `letterSpacing5` tokens.

### Patch Changes

- Updated dependencies [[`122e3a6b2`](https://github.azc.ext.hp.com/veneer/veneer/commit/122e3a6b2b66a8c5fec47010233dd4fba0bbeb3c)]:
  - @veneer/tokens@3.52.0

## 3.51.0

### Minor Changes

- [#4292](https://github.azc.ext.hp.com/veneer/veneer/pull/4292) [`33bc2310e`](https://github.azc.ext.hp.com/veneer/veneer/commit/33bc2310ea69abda290ebda789ce55fb7af27f2d) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - [Theme] Enhance `useTheme` return typed value

## 3.47.0

### Minor Changes

- [#4176](https://github.azc.ext.hp.com/veneer/veneer/pull/4176) [`85295a295`](https://github.azc.ext.hp.com/veneer/veneer/commit/85295a29580db1e3740c006569b651f915e52597) Thanks [@pedro-henrique-passos-leite](https://github.azc.ext.hp.com/pedro-henrique-passos-leite)! - [Button] Deprecate `tertiary` Button appearance in favor of `ghost` appearance

## 3.44.0

### Minor Changes

- [#4101](https://github.azc.ext.hp.com/veneer/veneer/pull/4101) [`17e87db5a`](https://github.azc.ext.hp.com/veneer/veneer/commit/17e87db5a2988880cba88d0e607fc07261a4e094) Thanks [@bianca-camargo-machado1](https://github.azc.ext.hp.com/bianca-camargo-machado1)! - [Avatar] Add button and link support

## 3.41.0

### Minor Changes

- [#3986](https://github.azc.ext.hp.com/veneer/veneer/pull/3986) [`7b0ba25ba`](https://github.azc.ext.hp.com/veneer/veneer/commit/7b0ba25ba94ee1387656139e056a4e03df0449b6) Thanks [@bianca-camargo-machado1](https://github.azc.ext.hp.com/bianca-camargo-machado1)! - [Stepper] Fix step theme object
