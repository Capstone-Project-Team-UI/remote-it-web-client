# @veneer/theme

## Installation

The `@veneer/theme` package is available in a private NPM registry under the `@veneer` scope. For more details check the [documentation page](http://veneer.design) to get started.

```bash
npm install --save @veneer/theme
```

or

```bash
yarn add @veneer/theme
```

## Theme

Currently, the `@veneer/theme` provides `ThemeProvider`, `ThemeContext`, `useTheme` and `withTheme` functions. Also, this functions are being exported from `@veneer/core`.

#### Usage

##### ThemeProvider

```js
import React from 'react';
import { ThemeContext, ThemeProvider, withTheme } from '@veneer/theme';
import { Button } from '@veneer/core';

export default function ThemeProvider() {
  return (
    <ThemeProvider mode="dark">
      <Button>Example</Button>
    </ThemeProvider>
  );
}
```

##### ThemeContext

```js
import * from 'react';
import { FlagBR, FlagUS } from '@veneer/flags';
import { ThemeContext } from '@veneer/core';

export default function ThemeContext() {

  const { shape } = React.useContext(ThemeContext);

  return (
    <div>
      {shape === 'round' && <div>Round</div>}
    </div>
  )
}
```

##### useTheme

###### This hook returns the current density, mode and shape applied to the ThemeProvider and its theme values.

```js
import * from 'react';
import { useTheme } from '@veneer/theme';

const Component = React.forwardRef((props, ref) => {
/**
* useTheme() returns the default theme.
* If you pass a component name, it returns a specific component theme (e.g. useTheme('Button'))
*/
const theme = useTheme()

  return (
    <div styles={myStyles(theme)}>
      // your code
    </div>
  );
});

Component.propTypes = {
  ...propTypes,
};

Component.defaultProps = {
  ...defaultProps,
};

Component.displayName = 'Component';

export default Component;
```

##### withTheme

```js
import * from 'react';
import { withTheme } from '@veneer/theme';

const Component = React.forwardRef((props, ref) => {
  return (
    <div>
    </div>
  );
});

Component.propTypes = {
  ...propTypes,
};

Component.defaultProps = {
  ...defaultProps,
};

Component.displayName = 'Component';

export default withTheme(Component);
```
