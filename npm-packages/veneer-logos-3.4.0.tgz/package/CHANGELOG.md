# @veneer/logos

## 3.4.0

### Minor Changes

- [#6732](https://github.azc.ext.hp.com/veneer/veneer/pull/6732) [`33a9147`](https://github.azc.ext.hp.com/veneer/veneer/commit/33a914752f8683ae4065380d1622a23def3e94e4) Thanks [@anderson-freitas](https://github.azc.ext.hp.com/anderson-freitas)! - [Logos] Add Hp Progress Mark, HyperX, ZByHp, Forest First, Poly (Poly Logomark) logos

## 3.3.0

### Minor Changes

- [#6088](https://github.azc.ext.hp.com/veneer/veneer/pull/6088) [`8fa272d`](https://github.azc.ext.hp.com/veneer/veneer/commit/8fa272d76c16b0d17576c0cfcc6b42f33c5d4bcf) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - Veneer packages have moved to a new repository on Nexus.

  In order to simplify Veneer's release process, Veneer packages are only published to the GitHub repository (https://npm.github.azc.ext.hp.com).

  To support users who need to use Nexus, there is a new Nexus repository (https://nexus-int.corp.hpicloud.net/repository/veneer-proxy/) that mirrors the GitHub repository.

  If you are using Nexus, and are unable to switch to GitHub, please update your configuration to point at this new repository.

## 3.2.0

### Minor Changes

- [#5468](https://github.azc.ext.hp.com/veneer/veneer/pull/5468) [`7fc61591b8`](https://github.azc.ext.hp.com/veneer/veneer/commit/7fc61591b8c6a09c8861790d192f7fba3ae6ad2a) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - [Logo] Add stacked variant of HP Instant Ink logo

## 3.1.1

### Patch Changes

- [#5419](https://github.azc.ext.hp.com/veneer/veneer/pull/5419) [`ab6deb6266`](https://github.azc.ext.hp.com/veneer/veneer/commit/ab6deb62662e42be1d4f18f5c6cf808536ac11b4) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - [Logo] Update Veneer logo colors

## 3.1.0

### Minor Changes

- [#5278](https://github.azc.ext.hp.com/veneer/veneer/pull/5278) [`b8c443ed4`](https://github.azc.ext.hp.com/veneer/veneer/commit/b8c443ed49fc8df9e035f8fe6e37cc701d2d9522) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - [Logo] New `@veneer/logos` package

  The new `@veneer/logos` package contains SVG logos for the following brands:

  - HP
  - HP+ (with and without 'Print Plans')
  - Instant Ink (with and without logo)
  - Omen (default, horizontal and vertical alignment)
  - Poly
  - Veneer (with & without text)

  Each SVG contains four color variants

  - `singlecolor` or `multicolor`

  _and_

  - `onLight` or `onDark` background

  This can be referenced using fragment identifiers: `<img src="@veneer/logos/hp/hp.svg#singlecolor-onLight" />`.

  New React wrappers are available in `@veneer/core`. In order to comply with brand guidelines they have a slightly reduced
  API; it is now not possible to set a custom color or the disabled state on them. Otherwise they should be compatible with
  current usage. By default, these logos will now automatically respond to the current `ThemeProvider` and select the
  appropriate variant for the background.

  ⚠️ If required, the old logos in the `@veneer/core` package are still available as deprecated versions. For example, the old HP logo
  is available as `<DeprecatedLogoHp />`. However, these will be removed in an upcoming release.

  In order to use these logos you will need to have an appropriate loader configured for your bundler. For instance, in Webpack:

  ```js
  {
    module: {
      rules: [
        {
          test: /\.svg$/i,
          type: "asset/resource",
        },
      ];
    }
  }
  ```

  You are likely to already have a similar loader configured for Veneer fonts.
