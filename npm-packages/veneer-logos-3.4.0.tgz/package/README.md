# @veneer/logos

## Installation

The `@veneer/logs` package is available in a private NPM registry under the `@veneer` scope. For more details check the [documentation page](http://veneer.design) to get started.

```bash
npm install --save @veneer/logos
```

or

```bash
yarn add @veneer/logos
```

## Logos

`@veneer/logos` package contains SVG logos for the following brands:

- HP
- HP+ (with and without 'Print Plans')
- Instant Ink (with and without logo)
- Omen (default, horizontal and vertical alignment)
- Poly
- Veneer (with and without text)

Each SVG contains four color variants

`singlecolor` or `multicolor`

and

`onLight` or `onDark` background

This can be referenced using fragment identifiers: `<img src="@veneer/logos/hp/hp.svg#singlecolor-onLight" />`.

New React wrappers are available in `@veneer/core`. By default, these logos will now automatically respond to the current ThemeProvider and select the
appropriate variant for the background.

In order to use these logos you will need to have an appropriate loader configured for your bundler. For instance, in Webpack:

```js
{
  module: {
    rules: [
      {
        test: /\.svg$/i,
        type: 'asset/resource',
      },
    ];
  }
}
```

You are likely to already have a similar loader configured for Veneer fonts.

## Documentation

If you're looking for `@veneer/logos` documentation, check out:

- [Veneer](https://veneer.hp.com/)
