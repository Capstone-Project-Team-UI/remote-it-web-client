# @veneer/highcharts-interface

## 3.68.0

### Minor Changes

- [#7072](https://github.azc.ext.hp.com/veneer/veneer/pull/7072) [`af63547`](https://github.azc.ext.hp.com/veneer/veneer/commit/af635477de14fd78198e7ccf6a210e5c1aa255b6) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [Chart] Add Accessibility module.

- [#7068](https://github.azc.ext.hp.com/veneer/veneer/pull/7068) [`d14e822`](https://github.azc.ext.hp.com/veneer/veneer/commit/d14e82241dbc798183feba372d65381907674f42) Thanks [@walter-ferreira](https://github.azc.ext.hp.com/walter-ferreira)! - Fixed `Line Chart` data label left positioning

### Patch Changes

- [#6978](https://github.azc.ext.hp.com/veneer/veneer/pull/6978) [`f3bf166`](https://github.azc.ext.hp.com/veneer/veneer/commit/f3bf166dff615e06e7514a1fd816c5b9d3ef8e61) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - [Infra] Ensure compatibility with React 19 types

- Updated dependencies [[`f3bf166`](https://github.azc.ext.hp.com/veneer/veneer/commit/f3bf166dff615e06e7514a1fd816c5b9d3ef8e61), [`dc378eb`](https://github.azc.ext.hp.com/veneer/veneer/commit/dc378eb376bf82f7e71e321edc23b500059161da)]:
  - @veneer/theme@3.89.0

## 3.67.3

### Patch Changes

- [#6994](https://github.azc.ext.hp.com/veneer/veneer/pull/6994) [`21bbbe7`](https://github.azc.ext.hp.com/veneer/veneer/commit/21bbbe7cb586b75429040ca456ffa6bad5295806) Thanks [@joao-flores-de-leao](https://github.azc.ext.hp.com/joao-flores-de-leao)! - [Foundation] Update foundation packages.

- Updated dependencies [[`21bbbe7`](https://github.azc.ext.hp.com/veneer/veneer/commit/21bbbe7cb586b75429040ca456ffa6bad5295806)]:
  - @veneer/theme@3.88.1

## 3.67.2

### Patch Changes

- Updated dependencies [[`d578284`](https://github.azc.ext.hp.com/veneer/veneer/commit/d57828456aeba1c86d52fd7b14ffad4bf5348446)]:
  - @veneer/theme@3.88.0

## 3.67.1

### Patch Changes

- Updated dependencies [[`d89d31f`](https://github.azc.ext.hp.com/veneer/veneer/commit/d89d31f0dd76cc0ae9695f700742eeae66153f0b), [`3867b4e`](https://github.azc.ext.hp.com/veneer/veneer/commit/3867b4e7aed56ca7db80d598baab738c54a5c2e5), [`d89d31f`](https://github.azc.ext.hp.com/veneer/veneer/commit/d89d31f0dd76cc0ae9695f700742eeae66153f0b)]:
  - @veneer/theme@3.87.0

## 3.67.0

### Minor Changes

- [#6880](https://github.azc.ext.hp.com/veneer/veneer/pull/6880) [`90cfc30`](https://github.azc.ext.hp.com/veneer/veneer/commit/90cfc30e09889218a03215886f5defdffe66160f) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [Chart] Depreacte `lineargauge`.

### Patch Changes

- Updated dependencies [[`200772f`](https://github.azc.ext.hp.com/veneer/veneer/commit/200772f3cb7a2973f4cca40e199f58727b3808c1)]:
  - @veneer/theme@3.86.0

## 3.66.0

### Minor Changes

- [#6804](https://github.azc.ext.hp.com/veneer/veneer/pull/6804) [`233be59`](https://github.azc.ext.hp.com/veneer/veneer/commit/233be59b14c009ce9c3aaea6092bc292d202fccf) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [Infra] In order to allow users to upgrade Highcharts, it is now a `peerDependency` of `@veneer/highcharts-interface`. To continue using the same version, you will need to add `highcharts@9.3.2` to your project dependencies. If you wish to upgrade, you may add `highcharts@11.4.8` instead.

## 3.65.3

### Patch Changes

- Updated dependencies [[`20e1aec`](https://github.azc.ext.hp.com/veneer/veneer/commit/20e1aec2ed38d20e74894f7824c4894e1f25e46a), [`6f36500`](https://github.azc.ext.hp.com/veneer/veneer/commit/6f36500ebe55a9e32eb8da64cb95699807e4e87c)]:
  - @veneer/theme@3.85.0

## 3.65.2

### Patch Changes

- Updated dependencies [[`7fd2719`](https://github.azc.ext.hp.com/veneer/veneer/commit/7fd27194e649cf25a0ad37de4f249a462c737bb5)]:
  - @veneer/theme@3.84.0

## 3.65.1

### Patch Changes

- Updated dependencies [[`648c69b`](https://github.azc.ext.hp.com/veneer/veneer/commit/648c69bf1c9246ddbea4835439b17208740683bf)]:
  - @veneer/theme@3.83.0

## 3.65.0

### Minor Changes

- [`88d6465`](https://github.azc.ext.hp.com/veneer/veneer/commit/88d64655c51745115eb75ce9322f934ddfaf5d60) Thanks [@pedro-soares](https://github.azc.ext.hp.com/pedro-soares)! - Removing deprecated React methods to avoid warnings.

- [`9ee153f`](https://github.azc.ext.hp.com/veneer/veneer/commit/9ee153fcdc13f03e341205c556fb24e157583aef) Thanks [@walter-ferreira](https://github.azc.ext.hp.com/walter-ferreira)! - [Foundation] Update @veneer/assets to 3.14.0, update @veneer/primitives to 3.63.0 and update @veneer/semantics to 3.9.0

- [`997cb2a`](https://github.azc.ext.hp.com/veneer/veneer/commit/997cb2adb06be0e91339020359776a3a9c09e5cd) Thanks [@anderson-freitas](https://github.azc.ext.hp.com/anderson-freitas)! - [Chart] Axis line color update

### Patch Changes

- Updated dependencies [[`88d6465`](https://github.azc.ext.hp.com/veneer/veneer/commit/88d64655c51745115eb75ce9322f934ddfaf5d60), [`9ee153f`](https://github.azc.ext.hp.com/veneer/veneer/commit/9ee153fcdc13f03e341205c556fb24e157583aef)]:
  - @veneer/theme@3.82.0

## 3.64.0

### Minor Changes

- [#6598](https://github.azc.ext.hp.com/veneer/veneer/pull/6598) [`818db74`](https://github.azc.ext.hp.com/veneer/veneer/commit/818db74ae3486ffe550c5d40c45d621906d6d027) Thanks [@anderson-freitas](https://github.azc.ext.hp.com/anderson-freitas)! - [Foundation] Update @veneer/assets to 3.13.0, update @veneer/primitives to 3.62.0 and update @veneer/semantics to 3.8.0

### Patch Changes

- Updated dependencies [[`818db74`](https://github.azc.ext.hp.com/veneer/veneer/commit/818db74ae3486ffe550c5d40c45d621906d6d027)]:
  - @veneer/theme@3.81.0

## 3.63.0

### Minor Changes

- [#6522](https://github.azc.ext.hp.com/veneer/veneer/pull/6522) [`6cd8ed3`](https://github.azc.ext.hp.com/veneer/veneer/commit/6cd8ed39fd7cbb250e744bb8f85b115ace87d1a3) Thanks [@anderson-freitas](https://github.azc.ext.hp.com/anderson-freitas)! - [Chart] Improve Area Chart support and customization

## 3.62.1

### Patch Changes

- Updated dependencies [[`e0bfd76`](https://github.azc.ext.hp.com/veneer/veneer/commit/e0bfd76f1da8e9d01a11ac14046bd751448f8fc6)]:
  - @veneer/theme@3.80.0

## 3.62.0

### Minor Changes

- [#6448](https://github.azc.ext.hp.com/veneer/veneer/pull/6448) [`2ca77c0`](https://github.azc.ext.hp.com/veneer/veneer/commit/2ca77c0ba1efe9d8321e73c93994531f593f16ee) Thanks [@pedro-soares](https://github.azc.ext.hp.com/pedro-soares)! - [Foundation] Update @veneer/assets to 3.9.0, update @veneer/primitives to 3.61.1 and update @veneer/semantics to 3.7.0

- [#6128](https://github.azc.ext.hp.com/veneer/veneer/pull/6128) [`7939b5a`](https://github.azc.ext.hp.com/veneer/veneer/commit/7939b5a1521271ca61a0d7f4a255d42d002b1b09) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - [Infra] Update to emotion 11

  As part of the upgrade to emotion 11, two new peer dependencies have been added for `@veneer/core`:

  - `@emotion/react`: `^11.11.4`
  - `@emotion/cache`: `^11.11.0`

  This is to ensure that if you are already using emotion 11, only one version of each is used.

### Patch Changes

- Updated dependencies [[`2ca77c0`](https://github.azc.ext.hp.com/veneer/veneer/commit/2ca77c0ba1efe9d8321e73c93994531f593f16ee)]:
  - @veneer/theme@3.79.0

## 3.61.0

### Minor Changes

- [#6396](https://github.azc.ext.hp.com/veneer/veneer/pull/6396) [`aa84d22`](https://github.azc.ext.hp.com/veneer/veneer/commit/aa84d221a14b82cd929f71f4d596e033f1759180) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [Foundation] Update @veneer/assets to 3.8.0, update @veneer/primitives to 3.61.0 and update @veneer/semantics to 3.6.0

- [#6298](https://github.azc.ext.hp.com/veneer/veneer/pull/6298) [`a984c97`](https://github.azc.ext.hp.com/veneer/veneer/commit/a984c976285393889a3ba9c53ca312fb765b49dc) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - [React] Update minimum supported react to 16.14.0

  This is in preparation for a future update to React 17; it is strongly recommended to update to React 18.

- [#6289](https://github.azc.ext.hp.com/veneer/veneer/pull/6289) [`36e3acf`](https://github.azc.ext.hp.com/veneer/veneer/commit/36e3acf19b2224ae6eaf78a3f34569e7c2f6c2cf) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - [Chart] New Chart Theme Provider

  A new `useChartTheme` hook is now available from `@veneer/highcharts-interface` that provides colors and color utilities
  for your charts.

  As well as containing four status colors (`positive`, `caution`, `warning`, `negative`), there are two built-in color
  schemes (`gray`, `categories`) that can be used to generate a gradient of colors.

  ```tsx
  import { useChartTheme } from "@veneer/highcharts-interface";

  const chartTheme = useChartTheme();

  // Returns an array of length 5 with evenly spaced colors
  const categories = chartTheme.colorSchemes.categories.ofLength(5);

  // Returns an interpolation function that can be called with a number between 0 and 1
  const colorGradient = chartTheme.colorSchemes.categories;
  const val = colorGradient.interpolate(0.3);
  ```

  The `ColorGradient` class can also be used to help users provide their own color scheme:

  ```tsx
  import { ColorGradient } from "@veneer/highcharts-interface";

  // Creates a ColorGradient class to interpolate between red and blue
  const myColors = new ColorGradient("red", "blue");
  const probablyPurple = myColors.interpolate(0.5);
  ```

### Patch Changes

- Updated dependencies [[`aa84d22`](https://github.azc.ext.hp.com/veneer/veneer/commit/aa84d221a14b82cd929f71f4d596e033f1759180), [`a984c97`](https://github.azc.ext.hp.com/veneer/veneer/commit/a984c976285393889a3ba9c53ca312fb765b49dc)]:
  - @veneer/theme@3.78.0

## 3.60.1

### Patch Changes

- Updated dependencies [[`e4c6c7d`](https://github.azc.ext.hp.com/veneer/veneer/commit/e4c6c7dcffd168e43a487edd8a19e6a400bb5a07), [`3b5e8b3`](https://github.azc.ext.hp.com/veneer/veneer/commit/3b5e8b300e4875622d5c26a9cf9e73ddd8ca8ebd), [`e4c6c7d`](https://github.azc.ext.hp.com/veneer/veneer/commit/e4c6c7dcffd168e43a487edd8a19e6a400bb5a07), [`e4c6c7d`](https://github.azc.ext.hp.com/veneer/veneer/commit/e4c6c7dcffd168e43a487edd8a19e6a400bb5a07)]:
  - @veneer/theme@3.77.0

## 3.60.0

### Minor Changes

- [#6088](https://github.azc.ext.hp.com/veneer/veneer/pull/6088) [`8fa272d`](https://github.azc.ext.hp.com/veneer/veneer/commit/8fa272d76c16b0d17576c0cfcc6b42f33c5d4bcf) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - Veneer packages have moved to a new repository on Nexus.

  In order to simplify Veneer's release process, Veneer packages are only published to the GitHub repository (https://npm.github.azc.ext.hp.com).

  To support users who need to use Nexus, there is a new Nexus repository (https://nexus-int.corp.hpicloud.net/repository/veneer-proxy/) that mirrors the GitHub repository.

  If you are using Nexus, and are unable to switch to GitHub, please update your configuration to point at this new repository.

### Patch Changes

- [#6232](https://github.azc.ext.hp.com/veneer/veneer/pull/6232) [`b7231a6`](https://github.azc.ext.hp.com/veneer/veneer/commit/b7231a6f6c845dbc9fb7a421ea0c3a5aeda6900b) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - [Foundation] Update packages

- Updated dependencies [[`8fa272d`](https://github.azc.ext.hp.com/veneer/veneer/commit/8fa272d76c16b0d17576c0cfcc6b42f33c5d4bcf)]:
  - @veneer/theme@3.76.0

## 3.59.3

### Patch Changes

- Updated dependencies [[`6df1339`](https://github.azc.ext.hp.com/veneer/veneer/commit/6df133991ed07ebc73497ec6749374944d313fc0), [`ff06fd3`](https://github.azc.ext.hp.com/veneer/veneer/commit/ff06fd324e5fdd74155f0cb9f40636d319d1a179)]:
  - @veneer/theme@3.75.0

## 3.59.2

### Patch Changes

- Updated dependencies [[`8d2ffa0498`](https://github.azc.ext.hp.com/veneer/veneer/commit/8d2ffa0498a1f433144f68d1b399242b542f9ffb)]:
  - @veneer/theme@3.74.0

## 3.59.1

### Patch Changes

- Updated dependencies [[`122765e2b`](https://github.azc.ext.hp.com/veneer/veneer/commit/122765e2bbd057601597ea64b60c567901b2fcaf)]:
  - @veneer/theme@3.73.0

## 3.59.0

### Minor Changes

- [#5472](https://github.azc.ext.hp.com/veneer/veneer/pull/5472) [`f9aebab19c`](https://github.azc.ext.hp.com/veneer/veneer/commit/f9aebab19ca99145c8ea4362981dd8145d9d505d) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - [Charts] Conversion to typescript

  The Highcharts Interface package has now been fully converted to typescript.

  However, the provided highcharts typings are woefully inaccurate.

  Whilst every effort has been made to ensure correct typings, you may find that some suppression of typescript errors is necessary.

  We hope to upgrade highcharts to a newer version soon that will have better typings.

## 3.58.2

### Patch Changes

- Updated dependencies [[`ead2a3f60d`](https://github.azc.ext.hp.com/veneer/veneer/commit/ead2a3f60de18c41464293205c72ffd920a2bda0)]:
  - @veneer/theme@3.72.0

## 3.58.1

### Patch Changes

- [#5406](https://github.azc.ext.hp.com/veneer/veneer/pull/5406) [`a562b7b45a`](https://github.azc.ext.hp.com/veneer/veneer/commit/a562b7b45a2ba18779195ce4f0fa73187074c0c8) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - [Chart] Re-add missing useChartContext export

- Updated dependencies [[`2e2b4df516`](https://github.azc.ext.hp.com/veneer/veneer/commit/2e2b4df516f4782b373731eff02a705bc1d511d1)]:
  - @veneer/theme@3.71.1

## 3.58.0

### Minor Changes

- [#5397](https://github.azc.ext.hp.com/veneer/veneer/pull/5397) [`8f0286084`](https://github.azc.ext.hp.com/veneer/veneer/commit/8f0286084602e9c733d467f829d816ffed681dab) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [Tokens] Consume new tokens package. If your project use tokens outside components, [consider reading this how to migrate guide](https://stackoverflow.hp.dev/articles/6485).

### Patch Changes

- [#5341](https://github.azc.ext.hp.com/veneer/veneer/pull/5341) [`f09362b7e`](https://github.azc.ext.hp.com/veneer/veneer/commit/f09362b7e24f433c1d4a5217c23f71db78ad2a41) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - [Chart] Chart components moved to `@veneer/highcharts-interface` package

  Chart components can still be imported from `@veneer/core` but will be moved in a future release.

- Updated dependencies [[`8f0286084`](https://github.azc.ext.hp.com/veneer/veneer/commit/8f0286084602e9c733d467f829d816ffed681dab)]:
  - @veneer/theme@3.71.0

## 3.57.0

### Minor Changes

- [#5064](https://github.azc.ext.hp.com/veneer/veneer/pull/5064) [`956863031`](https://github.azc.ext.hp.com/veneer/veneer/commit/9568630315e1da960b9311afe8fca392a142111f) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [NotificationCenter] Update component to consume system palette.

## 3.56.0

### Minor Changes

- [#5052](https://github.azc.ext.hp.com/veneer/veneer/pull/5052) [`7c9933a90`](https://github.azc.ext.hp.com/veneer/veneer/commit/7c9933a903aba7142ab751a539d2d08559b8a0e7) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [Card] Update component to consume new system palette.

## 3.55.0

### Minor Changes

- [#4760](https://github.azc.ext.hp.com/veneer/veneer/pull/4760) [`cae21572e`](https://github.azc.ext.hp.com/veneer/veneer/commit/cae21572e750bb05a4f21b7f8faa3104e9dca331) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [Typography] Forma DJR UI update
  🆕 Additions:

  New className `.salt` which applies new high-legibility CSS.
  When using `<i>` or `.italic` className, `Forma DJR UI Italic` will be used.
  New token `fontTextItalic`.

  ❌ Removals:

  Specific font for bold tags `<strong>`, `<b>`. Now, Forma DJR UI is the deafult font for it.
  Removed `letter-spacing: 'normal'` from `ar, bg, el, he, ja, ko, ru, sr, th, uk, zh` languages. It will be handled by `Forma DJR UI`.

  ⭐ Changes:

  Tokens:

  `fontTextRegular` from `Forma DJR Display` to `Forma DJR UI`.
  `fontTitleRegular` from `Forma DJR Display` to `Forma DJR UI`.
  All `letterSpacing` tokens have a new value `0`.

## 3.54.1

### Patch Changes

- [#4573](https://github.azc.ext.hp.com/veneer/veneer/pull/4573) [`d46b70b7e`](https://github.azc.ext.hp.com/veneer/veneer/commit/d46b70b7e4b0cf064fee2d8fea7e3d65887eddd0) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - Added missing typings for highcharts interface

## 3.54.0

### Minor Changes

- [#4339](https://github.azc.ext.hp.com/veneer/veneer/pull/4339) [`e430ea1eb`](https://github.azc.ext.hp.com/veneer/veneer/commit/e430ea1eb366a7a70e65db0142d50098d0e73673) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [Charts] Update scroll style to match new `Scrollbar` component.

## 3.53.1

### Patch Changes

- [#4414](https://github.azc.ext.hp.com/veneer/veneer/pull/4414) [`2e9e8c527`](https://github.azc.ext.hp.com/veneer/veneer/commit/2e9e8c52798dc7da96cb994e5590f0fc277de6f2) Thanks [@pedro-henrique-passos-leite](https://github.azc.ext.hp.com/pedro-henrique-passos-leite)! - [Charts] Update charts font styles from new typography definitions

## 3.53.0

### Minor Changes

- [#4379](https://github.azc.ext.hp.com/veneer/veneer/pull/4379) [`d600198ee`](https://github.azc.ext.hp.com/veneer/veneer/commit/d600198eeefe728c314b74c0068dbdecab461f37) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [Infra] Support React 18

## 3.52.0

### Minor Changes

- [#4255](https://github.azc.ext.hp.com/veneer/veneer/pull/4255) [`122e3a6b2`](https://github.azc.ext.hp.com/veneer/veneer/commit/122e3a6b2b66a8c5fec47010233dd4fba0bbeb3c) Thanks [@bianca-camargo-machado1](https://github.azc.ext.hp.com/bianca-camargo-machado1)! - Update typography to Forma DJR

  ⚠ `title-large--light`, `title-medium--light`, `title-regular--light`, `title-small--light`, `subtitle-large--light`, and `subtitle-regular--light` styles have been deprecated and it'll be removed in the next major release.

  ⚠ `fontFamilyLight` and `fontFamilyRegular`tokens have been deprecated and it'll be removed in the next major release.

  ⚠ The current fallback font for Middle East is Arial.

  🆕 New tokens: `fontTextRegular`, `fontTextMedium`, and `fontTitleRegular`.

  🎨 Updates on: `letterSpacing1`, `letterSpacing2`, `letterSpacing3`, `letterSpacing4` and `letterSpacing5` tokens.

## 3.51.0

### Minor Changes

- [#4285](https://github.azc.ext.hp.com/veneer/veneer/pull/4285) [`de689b397`](https://github.azc.ext.hp.com/veneer/veneer/commit/de689b3972902912897b83300b16be260016843a) Thanks [@mateus-domingos](https://github.azc.ext.hp.com/mateus-domingos)! - [Chart] Add headerformat, pointFormat and footerFormat support

## 3.42.0

### Minor Changes

- [#4034](https://github.azc.ext.hp.com/veneer/veneer/pull/4034) [`77bee5473`](https://github.azc.ext.hp.com/veneer/veneer/commit/77bee5473467d568e7437373883326dd990014a8) Thanks [@bianca-camargo-machado1](https://github.azc.ext.hp.com/bianca-camargo-machado1)! - [Chart] Add itemDistance and itemMarginBottom on export options

* [#4028](https://github.azc.ext.hp.com/veneer/veneer/pull/4028) [`78c94228d`](https://github.azc.ext.hp.com/veneer/veneer/commit/78c94228de4bc2ce59030b496e2917bc663cb818) Thanks [@bianca-camargo-machado1](https://github.azc.ext.hp.com/bianca-camargo-machado1)! - [Chart] Add Donut example using beforePrint and afterPrint functions and export

## 3.41.0

### Minor Changes

- [#4013](https://github.azc.ext.hp.com/veneer/veneer/pull/4013) [`d74414fd6`](https://github.azc.ext.hp.com/veneer/veneer/commit/d74414fd65fece6c1afd76d46807d2cf2799b0fa) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [Chart] Create grouped Tooltip for stacked and donut charts. Also added an example in storybook to create a custom Tooltip
