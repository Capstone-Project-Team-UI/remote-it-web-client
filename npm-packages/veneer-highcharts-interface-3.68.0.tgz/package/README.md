# @veneer/highcharts-interface

> Interface between Veneer's chart and [Highcharts'](https://www.highcharts.com/) charts, in order to apply Veneer Design System to it.

## Installation

The `@veneer/highcharts-interface` package is available in a private NPM registry under the `@veneer` scope. For more details check the [documentation page](https://veneer.hp.com) to get started.

```bash
npm install --save @veneer/highcharts-interface
```

or

```bash
yarn add @veneer/highcharts-interface
```

Veneer sets `highcharts` as a peerDependency. Please, set your desired highcharts version under `dependencies` in your `package.json` from the available range.

```js
   "dependencies": {
    "highcharts": "11.4.8",
  },
```

## Usage

```js
// MyChart.js
import React from 'react';
import { ChartProvider, Chart } from '@veneer/core';
import highchartsInterface from '@veneer/highcharts-interface';

const data = {
  chart: {
    type: 'stackedbar',
  },
  title: {
    text: 'Stacked Bar Chart',
  },
  xAxis: {
    categories: ['Apples', 'Oranges', 'Pears', 'Grapes', 'Bananas'],
  },
  yAxis: {
    min: 0,
    title: {
      text: 'Total fruit consumption',
    },
  },
  series: [
    {
      type: 'bar',
      name: 'John',
      data: [5, 3, 4, 7, 2],
    },
    {
      type: 'bar',
      name: 'Jane',
      data: [2, 2, 3, 2, 1],
    },
    {
      type: 'bar',
      name: 'Joe',
      data: [3, 4, 4, 2, 5],
    },
  ],
};

<ChartProvider chartInterface={highchartsInterface}>
  <Chart options={data} />
</ChartProvider>;

export default MyChart;
```

## Documentation

If you're looking for `@veneer/highcharts-interface` documentation, check out:

- [Veneer](https://veneer.hp.com)
