# @veneer/analytics

## 3.3.1

### Patch Changes

- [#6978](https://github.azc.ext.hp.com/veneer/veneer/pull/6978) [`f3bf166`](https://github.azc.ext.hp.com/veneer/veneer/commit/f3bf166dff615e06e7514a1fd816c5b9d3ef8e61) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - [Infra] Ensure compatibility with React 19 types

## 3.3.0

### Minor Changes

- [#6396](https://github.azc.ext.hp.com/veneer/veneer/pull/6396) [`aa84d22`](https://github.azc.ext.hp.com/veneer/veneer/commit/aa84d221a14b82cd929f71f4d596e033f1759180) Thanks [@guilherme-rizzotto1](https://github.azc.ext.hp.com/guilherme-rizzotto1)! - [Foundation] Update @veneer/assets to 3.8.0, update @veneer/primitives to 3.61.0 and update @veneer/semantics to 3.6.0

- [#6298](https://github.azc.ext.hp.com/veneer/veneer/pull/6298) [`a984c97`](https://github.azc.ext.hp.com/veneer/veneer/commit/a984c976285393889a3ba9c53ca312fb765b49dc) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - [React] Update minimum supported react to 16.14.0

  This is in preparation for a future update to React 17; it is strongly recommended to update to React 18.

## 3.2.0

### Minor Changes

- [#6088](https://github.azc.ext.hp.com/veneer/veneer/pull/6088) [`8fa272d`](https://github.azc.ext.hp.com/veneer/veneer/commit/8fa272d76c16b0d17576c0cfcc6b42f33c5d4bcf) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - Veneer packages have moved to a new repository on Nexus.

  In order to simplify Veneer's release process, Veneer packages are only published to the GitHub repository (https://npm.github.azc.ext.hp.com).

  To support users who need to use Nexus, there is a new Nexus repository (https://nexus-int.corp.hpicloud.net/repository/veneer-proxy/) that mirrors the GitHub repository.

  If you are using Nexus, and are unable to switch to GitHub, please update your configuration to point at this new repository.

## 3.1.0

### Minor Changes

- [#5133](https://github.azc.ext.hp.com/veneer/veneer/pull/5133) [`07c69d2db`](https://github.azc.ext.hp.com/veneer/veneer/commit/07c69d2db819b6f12a58ac04a848e985599b8483) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - [Card] Update card sources to use typescript

* [#5203](https://github.azc.ext.hp.com/veneer/veneer/pull/5203) [`7958d389f`](https://github.azc.ext.hp.com/veneer/veneer/commit/7958d389f1db88fa52a8a44de746fc9e43d889b4) Thanks [@bill-collins](https://github.azc.ext.hp.com/bill-collins)! - Analytics components now forward refs correctly

## 3.0.1

### Patch Changes

- [#4553](https://github.azc.ext.hp.com/veneer/veneer/pull/4553) [`9fa72a955`](https://github.azc.ext.hp.com/veneer/veneer/commit/9fa72a95540c2c3209eb36b33a61659d587e6f59) Thanks [@pedro-henrique-passos-leite](https://github.azc.ext.hp.com/pedro-henrique-passos-leite)! - [@veneer/analytics][@veneer/core-analytics] Add packages' `module` export

## 3.0.0

### Minor Changes

- [#4428](https://github.azc.ext.hp.com/veneer/veneer/pull/4428) [`99b04f922`](https://github.azc.ext.hp.com/veneer/veneer/commit/99b04f9220ed3cbeff0d484edf091a5e1501dc0e) Thanks [@douglas-michaelsen](https://github.azc.ext.hp.com/douglas-michaelsen)! - [Infra] Add `@veneer/analytics` and `@veneer/core-analytics` packages.
