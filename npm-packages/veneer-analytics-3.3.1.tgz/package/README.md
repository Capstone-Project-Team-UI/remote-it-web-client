# @veneer/analytics

## Installation

The `@veneer/analytics` package is available in a private NPM registry under the `@veneer` scope. For more details check the [documentation page](http://veneer.design) to get started.

```bash
npm install --save @veneer/analytics
```

or

```bash
yarn add @veneer/analytics
```

## Analytics

This package provides helpers for instrumenting React components in order to capture analytics events. This allows applications to configure any analytics lib (i.e. Google Analytics, Adobe Analytics, Piwik, Kissmetrics, etc) in a centralized way. The helpers are:

### AnalyticsProvider

`AnalyticsProvider` is responsible for maintaining the tracking context throughout the solution. It has two props:

- `tracker`: the main analytics callback that will be fired for every handler being tracked. It is called with `({ trackCategory, trackId, handler, handlerParams })`. Check below it's definitions:
  - `trackCategory`: a string used to distinguish between categories / level of events.
  - `trackId`: the unique ID for the component being tracked.
  - `handler`: The current handler that is being fired.
  - `handlerParams`: The params returned by the handler.
- `logger`: a function to be passed as alternative to default `console` being used internally for messages about tracking warnings and errors. It is called with `(level, msg)` parameters.

### WithAnalytics()

A High Order Component (HOC) `withAnalytics` that will wrap the component being tracked and inject the tracker callback from the context. The wrapped component can receive as props:

- `canReturnParams`: a boolean or array prop. If `true` it will enable all handlers to return its params on the tracker callback. Or it can be passed a list of handlers to enable. The default is `false` for security assurance. The application must ensure that params being returned does not contain sensitive information (PII).
- `stopTracking`: a boolean prop passed to avoid tracker to be called. By default all `AnalyticsProvider` nested components on the application will try to call the analytics callback. If for some reason a component shouldn't be tracked this prop can be passed.
- `trackedHandlers`: an array with the names of handlers that must be tracked by the tracker. If this option is not passed to the wrapped component then all handlers will be tracked (excluding the untracked ones, if `untrackedHandlers` prop is present).
- `trackCategory`: an optional string used to distinguish between categories / level of events.
- `trackId`: the unique ID for the component being tracked. It is required since it is not possible to automatically generate an unique ID for generic components.
- `untrackedHandlers`: an array with the names of handlers that must not be tracked by the tracker. This is an utility prop and it is complementary to `trackedHandlers`, which means they are used exclusively and never together.

#### Usage

```js
const analyticsCallback = ({ trackCategory, trackId, handler, handlerParams }) => {
    ...
    analyticsLib("...whatever arguments it has mapped to trackCategory, trackId, handler and handlerParams")
};

const TrackedButton = withAnalytics(Button);

<AnalyticsProvider tracker={analyticsCallback} logger={myAppLogger}>
    <TrackedButton
        canReturnParams
        onClick={() => {}}
        onMouseEnter={() => {}}
        onMouseLeave={() => {}}
        trackCategory='PurchaseFlow'
        trackId='PurchaseButton123'
        untrackedHandlers=['onMouseEnter']
    />
</AnalyticsProvider>
```

## Documentation

If you're looking for `@veneer/analytics` documentation, check out:

- [Veneer](https://veneer.hp.com/)
