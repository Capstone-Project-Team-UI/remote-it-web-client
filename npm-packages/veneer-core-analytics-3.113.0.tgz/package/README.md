# @veneer/core-analytics

## Installation

The `@veneer/core-analytics` package is available in a private NPM registry under the `@veneer` scope. For more details check the [documentation page](http://veneer.design) to get started.

```bash
npm install --save @veneer/core-analytics
```

or

```bash
yarn add @veneer/core-analytics
```

## Core Analytics

This package provides all veneer core components wrapped inside `withAnalytics` HOC. When using this package, install `@veneer/analytics` as well to consume the `AnalyticsProvider`.

#### Usage

```js
import { Button } from '@veneer/core-analytics'

const analyticsCallback = ({ trackCategory, trackId, handler, handlerParams }) => {
    ...
    analyticsLib("...whatever arguments it has mapped to trackCategory, trackId, handler and handlerParams")
};

<AnalyticsProvider tracker={analyticsCallback} logger={myAppLogger}>
    <Button
        canReturnParams
        onClick={() => {}}
        onMouseEnter={() => {}}
        onMouseLeave={() => {}}
        trackCategory='PurchaseFlow'
        trackId='PurchaseButton123'
        untrackedHandlers=['onMouseEnter']
    />
</AnalyticsProvider>
```

## Documentation

If you're looking for `@veneer/core-analytics` documentation, check out:

- [Veneer](https://veneer.hp.com/)
